/*
 * (c) Copyright IBM Corp 2001, 2005 
 */

package com.ibm.tck;

import com.sun.javadoc.*;
import java.io.*;
import java.util.*;

/**
 * This class implements a Doclet that is used to generate TCK documentation
 * from JavaDoc comments.
 *
 * @author Matthew J. Duftler (duftler@us.ibm.com)
 */
public class TCKDoclet
{
  public static int optionLength(String option)
  {
    if (option.equals("-projectName"))
    {
      return 2;
    }
    else if (option.equals("-destinationFileName"))
    {
      return 2;
    }
    else if (option.equals("-footerFileName"))
    {
      return 2;
    }
    else
    {
      return 0;
    }
  }

  private static Map readOptions(String[][] options)
  {
    Map map = new HashMap();

    for (int i = 0; i < options.length; i++)
    {
      String[] option = options[i];

      map.put(option[0], option[1]);
    }

    return map;
  }

  public static boolean validOptions(String options[][],
                                     DocErrorReporter reporter)
  {
    boolean foundProjectNameOption = false;
    boolean foundDestinationFileNameOption = false;

    for (int i = 0; i < options.length; i++)
    {
      String[] opt = options[i];

      if (opt[0].equals("-projectName"))
      {
        foundProjectNameOption = true;
      }
      else if (opt[0].equals("-destinationFileName"))
      {
        foundDestinationFileNameOption = true;
      }
    }

    if (!foundProjectNameOption || !foundDestinationFileNameOption)
    {
      reporter.printError("Usage:\n\n" +
                          "  javadoc [args]\n\n" +
                          "    args:\n\n" +
                          "      -projectName          the name to use in " +
                          "the generated documentation\n" +
                          "      -destinationFileName  the name of the file " +
                          "to generate\n" +
                          "      [-footerFileName      the name of a file " +
                          "containing html to include just\n" +
                          "                            before the closing " +
                          "</body> tag]");
    }

    return foundProjectNameOption && foundDestinationFileNameOption;
  }

  public static boolean start(RootDoc root) throws IOException
  {
    Map options = readOptions(root.options());
    String projectName = (String)options.get("-projectName");
    String destinationFileName = (String)options.get("-destinationFileName");
    String footerFileName = (String)options.get("-footerFileName");
    FileWriter fw = new FileWriter(destinationFileName);
    PrintWriter pw = new PrintWriter(fw);
    ClassDoc[] classes = root.classes();
    Comparator comparator =
    new Comparator()
    {
      public int compare(Object o1, Object o2)
      {
        return ((ClassDoc)o1).typeName().compareTo(((ClassDoc)o2).typeName());
      }
    };

    Arrays.sort(classes, comparator);

    List missingCommentList = new Vector();

    pw.println("<html>");
    pw.println("  <head>");
    pw.println("    <style type=\"text/css\">");
    pw.println("      <!--");
    pw.println("        .javaClassName  " +
               "{ font-family: monospace; text-align: center }");
    pw.println("       -->");
    pw.println("    </style>");
    pw.println("  </head>");
    pw.println("  <body>");
    pw.println("  <title>" + projectName + " Tests</title>");
    pw.println("    <div align=center>");
    pw.println("      <table border=1>");
    pw.println("        <caption " +
               "style=\"font-size: large; font-weight: bold\">" +
               projectName + " Tests</caption>");
    pw.println("        <tr>");
    pw.println("          <th>Test Class</th>");
    pw.println("          <th>Performs Tests</th>");
    pw.println("        </tr>");

    for (int i = 0; i < classes.length; i++)
    {
      String qTypeName = classes[i].qualifiedTypeName();
      boolean foundMethodComments = false;

      if (qTypeName.indexOf(".tck.") != -1)
      {
        String typeName = classes[i].typeName();

        pw.println("        <tr>");
        pw.println("          <td " +
                   "class=\"javaClassName\">" +
                   typeName + "</td>");
        pw.println("          <td>");
        pw.println("            <ul>");

        MethodDoc[] methods = classes[i].methods();

        for (int j = 0; j < methods.length; j++)
        {
          String methodName = methods[j].name();
          String commentText = methods[j].commentText();

          if (methods[j].isPublic() && methodName.startsWith("test"))
          {
            foundMethodComments = true;

            if (commentText.length() > 0)
            {
              pw.println("              <li>" + commentText + "</li>");
            }
            else
            {
              missingCommentList.add(typeName + "." + methodName + "()");
            }
          }
        }

        if (!foundMethodComments)
        {
          String commentText = classes[i].commentText();

          if (commentText.length() > 0)
          {
            pw.println("              <li>" + commentText + "</li>");
          }
          else
          {
            missingCommentList.add(typeName);
          }
        }

        pw.println("            </ul>");
        pw.println("          </td>");
        pw.println("        </tr>");
      }
    }

    pw.println("      </table>");
    pw.println("      <br>");
    pw.println("    </div>");

    if (footerFileName != null)
    {
      FileReader fr = new FileReader(footerFileName);
      BufferedReader br = new BufferedReader(fr);
      String tempLine = null;

      while ((tempLine = br.readLine()) != null)
      {
        pw.println(tempLine);
      }

      br.close();
    }

    pw.println("  </body>");
    pw.println("</html>");
    pw.flush();
    fw.close();

    if (missingCommentList.size() > 0)
    {
      System.out.println("Missing comments for: ");

      Iterator methodList = missingCommentList.iterator();

      while (methodList.hasNext())
      {
        System.out.println("  " + methodList.next());
      }
    }

    return true;
  }
}
