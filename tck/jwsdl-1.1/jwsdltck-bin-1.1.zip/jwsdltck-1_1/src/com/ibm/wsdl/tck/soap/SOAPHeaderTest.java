/*
 * (c) Copyright IBM Corp 2001, 2005 
 */

package com.ibm.wsdl.tck.soap;

import com.ibm.wsdl.tck.util.*;
import java.io.*;
import java.util.*;
import javax.wsdl.*;
import javax.wsdl.extensions.*;
import javax.wsdl.extensions.soap.*;
import javax.wsdl.factory.*;
import javax.wsdl.xml.*;
import javax.xml.namespace.*;
import junit.framework.*;

/**
 * This class implements a series of tests used to check
 * javax.wsdl.extensions.soap.SOAPHeader implementations
 * for compliance with the JWSDL specification.
 *
 * @author Matthew J. Duftler (duftler@us.ibm.com)
 */
public class SOAPHeaderTest extends TestCase
{
  private static final String TEST_CANDIDATE_PROPERTY_NAME =
    "javax.wsdl.factory.WSDLFactoryCandidate";
  private static final String NS_URI_SOAP =
    "http://schemas.xmlsoap.org/wsdl/soap/";

  private WSDLFactory factory = null;
  private ExtensionRegistry extReg = null;
  private SOAPHeader soapHeader = null;

  protected void setUp() throws WSDLException, IOException
  {
    // Determine name of JWSDL factory implementation to test.
    String testCandidateName =
      System.getProperty(TEST_CANDIDATE_PROPERTY_NAME);

    if (testCandidateName == null)
    {
      throw new IllegalArgumentException("System property '" +
                                         TEST_CANDIDATE_PROPERTY_NAME +
                                         "' must be specified to run " +
                                         "test suite.");
    }

    factory = WSDLFactory.newInstance(testCandidateName);

    Assert.assertNotNull("WSDLFactory should not be null.", factory);

    extReg = factory.newPopulatedExtensionRegistry();

    Assert.assertNotNull("ExtensionRegistry should not be null.", extReg);

    QName soapHeaderQName = new QName(NS_URI_SOAP, "header");

    soapHeader = (SOAPHeader)TCKUtils.createExtension(extReg,
                                                      BindingInput.class,
                                                      soapHeaderQName,
                                                      SOAPHeader.class);
  }

  /**
   * Test SOAPHeader.addSOAPHeaderFault(...) and
   * SOAPHeader.getSOAPHeaderFaults().
   */
  public void testAddGetSOAPHeaderFault()
  {
    QName soapHeaderFaultQName = new QName(NS_URI_SOAP, "headerfault");
    SOAPHeaderFault soapHeaderFault1 =
      (SOAPHeaderFault)TCKUtils.createExtension(
        extReg,
        SOAPHeader.class,
        soapHeaderFaultQName,
        SOAPHeaderFault.class);
    SOAPHeaderFault soapHeaderFault2 =
      (SOAPHeaderFault)TCKUtils.createExtension(
        extReg,
        SOAPHeader.class,
        soapHeaderFaultQName,
        SOAPHeaderFault.class);
    SOAPHeaderFault soapHeaderFault3 =
      (SOAPHeaderFault)TCKUtils.createExtension(
        extReg,
        SOAPHeader.class,
        soapHeaderFaultQName,
        SOAPHeaderFault.class);

    soapHeader.addSOAPHeaderFault(soapHeaderFault2);
    soapHeader.addSOAPHeaderFault(soapHeaderFault3);
    soapHeader.addSOAPHeaderFault(soapHeaderFault1);

    List expectedParts = Arrays.asList(new Object[]{soapHeaderFault2,
                                                    soapHeaderFault3,
                                                    soapHeaderFault1});
    List actualParts = soapHeader.getSOAPHeaderFaults();

    Assert.assertTrue("SOAPHeader.getSOAPHeaderFaults() did not return " +
                      "the correct list of SOAPHeaderFaults.",
                      expectedParts.equals(actualParts));
  }

  /**
   * Test SOAPHeader.setEncodingStyles(...) and SOAPHeader.getEncodingStyles().
   */
  public void testSetGetEncodingStyles()
  {
    List encodingStyles = new Vector();

    soapHeader.setEncodingStyles(encodingStyles);

    List encodingStyles2 = soapHeader.getEncodingStyles();

    Assert.assertTrue("SOAPHeader.getEncodingStyles() did not return " +
                      "the same list that was set using " +
                      "SOAPHeader.setEncodingStyles(...).",
                      encodingStyles == encodingStyles2);
  }

  /**
   * Test SOAPHeader.setMessage(...) and SOAPHeader.getMessage().
   */
  public void testSetGetMessage()
  {
    QName message = new QName("urn:abc", "defghi");

    soapHeader.setMessage(message);

    QName message2 = soapHeader.getMessage();

    Assert.assertTrue("SOAPHeader.getMessage() did not return " +
                      "the same message that was set using " +
                      "SOAPHeader.setMessage(...).",
                      message.equals(message2));
  }

  /**
   * Test SOAPHeader.setNamespaceURI(...) and SOAPHeader.getNamespaceURI().
   */
  public void testSetGetNamespaceURI()
  {
    String namespaceURI = "urn:abcdef";

    soapHeader.setNamespaceURI(namespaceURI);

    String namespaceURI2 = soapHeader.getNamespaceURI();

    Assert.assertTrue("SOAPHeader.getNamespaceURI() did not return " +
                      "the same namespace URI that was set using " +
                      "SOAPHeader.setNamespaceURI(...).",
                      namespaceURI.equals(namespaceURI2));
  }

  /**
   * Test SOAPHeader.setPart(...) and SOAPHeader.getPart().
   */
  public void testSetGetPart()
  {
    String part = "abcdef";

    soapHeader.setPart(part);

    String part2 = soapHeader.getPart();

    Assert.assertTrue("SOAPHeader.getPart() did not return " +
                      "the same part that was set using " +
                      "SOAPHeader.setPart(...).",
                      part.equals(part2));
  }

  /**
   * Test SOAPHeader.setUse(...) and SOAPHeader.getUse().
   */
  public void testSetGetUse()
  {
    String use = "encoded";

    soapHeader.setUse(use);

    String use2 = soapHeader.getUse();

    Assert.assertTrue("SOAPHeader.getUse() did not return " +
                      "the same use that was set using " +
                      "SOAPHeader.setUse(...).",
                      use.equals(use2));
  }
}