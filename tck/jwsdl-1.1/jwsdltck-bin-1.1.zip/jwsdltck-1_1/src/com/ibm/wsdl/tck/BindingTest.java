/*
 * (c) Copyright IBM Corp 2001, 2005 
 */

package com.ibm.wsdl.tck;

import javax.wsdl.*;
import javax.wsdl.extensions.*;
import javax.wsdl.factory.*;
import javax.wsdl.xml.*;
import javax.xml.namespace.*;
import javax.xml.parsers.*;
import junit.framework.*;
import org.w3c.dom.*;

/**
 * This class implements a series of tests used to check
 * javax.wsdl.Binding implementations for compliance
 * with the JWSDL specification.
 *
 * @author Matthew J. Duftler (duftler@us.ibm.com)
 */
public class BindingTest extends TestCase
{
  private static final String TEST_CANDIDATE_PROPERTY_NAME =
    "javax.wsdl.factory.WSDLFactoryCandidate";
  private static final String NS_URI_WSDL =
    "http://schemas.xmlsoap.org/wsdl/";

  private Definition definition = null;
  private Binding binding = null;

  protected void setUp() throws WSDLException
  {
    // Determine name of JWSDL factory implementation to test.
    String testCandidateName =
      System.getProperty(TEST_CANDIDATE_PROPERTY_NAME);

    if (testCandidateName == null)
    {
      throw new IllegalArgumentException("System property '" +
                                         TEST_CANDIDATE_PROPERTY_NAME +
                                         "' must be specified to run " +
                                         "test suite.");
    }

    WSDLFactory factory = WSDLFactory.newInstance(testCandidateName);

    Assert.assertNotNull("WSDLFactory should not be null.", factory);

    definition = factory.newDefinition();

    Assert.assertNotNull("Definition should not be null.", definition);

    binding = definition.createBinding();

    Assert.assertNotNull("Binding should not be null.", binding);
  }

  /**
   * Test Binding.addBindingOperation(...) and
   * Binding.getBindingOperation(...).
   */
  public void testAddGetBindingOperation()
  {
    BindingOperation bindingOp = definition.createBindingOperation();

    Assert.assertNotNull("BindingOperation should not be null.", bindingOp);

    bindingOp.setName("abcdef");
    binding.addBindingOperation(bindingOp);

    BindingOperation bindingOp2 = binding.getBindingOperation("abcdef",
                                                              null,
                                                              null);

    Assert.assertTrue("Binding.getBindingOperation(...) did not return " +
                      "the same BindingOperation that was added using " +
                      "Binding.addBindingOperation(...).",
                      bindingOp == bindingOp2);
  }

  /**
   * Test Binding.setDocumentationElement(...) and
   * Binding.getDocumentationElement().
   */
  public void testSetGetDocumentationElement()
    throws ParserConfigurationException
  {
    DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();

    factory.setNamespaceAware(true);
    factory.setValidating(false);

    DocumentBuilder builder = factory.newDocumentBuilder();
    Document doc = builder.newDocument();
    Element el = doc.createElementNS(NS_URI_WSDL,
                                     "wsdl:documentation");

    binding.setDocumentationElement(el);

    Element el2 = binding.getDocumentationElement();

    Assert.assertTrue("Binding.getDocumentationElement() did not return " +
                      "the same Element that was set using " +
                      "Binding.setDocumentationElement(...).",
                      el == el2);
  }

  /**
   * Test Binding.setPortType(...) andBinding.getPortType().
   */
  public void testSetGetPortType()
  {
    PortType portType = definition.createPortType();

    Assert.assertNotNull("PortType should not be null.", portType);

    binding.setPortType(portType);

    PortType portType2 = binding.getPortType();

    Assert.assertTrue("Binding.getPortType() did not return " +
                      "the same PortType that was set using " +
                      "Binding.setPortType(...).",
                      portType == portType2);
  }

  /**
   * Test Binding.setQName(...) andBinding.getQName().
   */
  public void testSetGetQName()
  {
    QName qname = new QName("urn:abc", "def");

    binding.setQName(qname);

    QName qname2 = binding.getQName();

    Assert.assertTrue("Binding.getQName() did not return " +
                      "the same QName that was set using " +
                      "Binding.setQName(...).",
                      qname.equals(qname2));
  }

  /**
   * Test Binding.setUndefined(...) andBinding.isUndefined().
   */
  public void testIsSetUndefined()
  {
    Assert.assertTrue("The default value of the undefined property " +
                      "of a newly created Binding should be " +
                      "true.",
                      binding.isUndefined());

    binding.setUndefined(false);

    Assert.assertFalse("Binding.isUndefined() returned " +
                       "true even though Binding.setUndefined(false) " +
                       "was called.",
                       binding.isUndefined());
  } 
}