/*
 * (c) Copyright IBM Corp 2001, 2005 
 */

package com.ibm.wsdl.tck;

import java.util.*;
import javax.wsdl.*;
import javax.wsdl.extensions.*;
import javax.wsdl.factory.*;
import javax.wsdl.xml.*;
import javax.xml.namespace.*;
import javax.xml.parsers.*;
import junit.framework.*;
import org.w3c.dom.*;

/**
 * This class implements a series of tests used to check
 * javax.wsdl.Message implementations for compliance
 * with the JWSDL specification.
 *
 * @author Matthew J. Duftler (duftler@us.ibm.com)
 */
public class MessageTest extends TestCase
{
  private static final String TEST_CANDIDATE_PROPERTY_NAME =
    "javax.wsdl.factory.WSDLFactoryCandidate";
  private static final String NS_URI_WSDL =
    "http://schemas.xmlsoap.org/wsdl/";

  private Definition definition = null;
  private Message message = null;

  protected void setUp() throws WSDLException
  {
    // Determine name of JWSDL factory implementation to test.
    String testCandidateName =
      System.getProperty(TEST_CANDIDATE_PROPERTY_NAME);

    if (testCandidateName == null)
    {
      throw new IllegalArgumentException("System property '" +
                                         TEST_CANDIDATE_PROPERTY_NAME +
                                         "' must be specified to run " +
                                         "test suite.");
    }

    WSDLFactory factory = WSDLFactory.newInstance(testCandidateName);

    Assert.assertNotNull("WSDLFactory should not be null.", factory);

    definition = factory.newDefinition();

    Assert.assertNotNull("Definition should not be null.", definition);

    message = definition.createMessage();

    Assert.assertNotNull("Message should not be null.", message);
  }

  /**
   * Test Message.addPart(...) and Message.getPart(...).
   */
  public void testAddGetPart()
  {
    Part part = definition.createPart();

    Assert.assertNotNull("Part should not be null.", part);

    part.setName("abcdef");
    message.addPart(part);

    Part part2 = message.getPart("abcdef");

    Assert.assertTrue("Message.getPart(...) did not return " +
                      "the same Part that was added using " +
                      "Message.addPart(...).",
                      part == part2);

    Part part3 = definition.createPart();
    Part part4 = definition.createPart();
    Part part5 = definition.createPart();

    Assert.assertNotNull("Part should not be null.", part3);
    Assert.assertNotNull("Part should not be null.", part4);
    Assert.assertNotNull("Part should not be null.", part5);

    part3.setName("part3");
    part4.setName("part4");
    part5.setName("part5");

    message.addPart(part3);
    message.addPart(part4);
    message.addPart(part5);

    List expectedParts =
      Arrays.asList(new Object[]{part5, part3, part, part4});
    List orderedParts =
      message.getOrderedParts(
        Arrays.asList(new String[]{"part5", "part3", "abcdef", "part4"}));

    Assert.assertTrue("Message.getOrderedParts(...) did not return " +
                      "the correct list of parts, even though a list " +
                      "of part names was specified.",
                      expectedParts.equals(orderedParts));

    List expectedParts2 =
      Arrays.asList(new Object[]{part, part3, part4, part5});
    List orderedParts2 = message.getOrderedParts(null);

    Assert.assertTrue("Message.getOrderedParts(null) did not return " +
                      "the parts in the order in which they were added " +
                      "to the message.",
                      expectedParts2.equals(orderedParts2));
  }

  /**
   * Test Message.setDocumentationElement(...) and
   * Message.getDocumentationElement().
   */
  public void testSetGetDocumentationElement()
    throws ParserConfigurationException
  {
    DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();

    factory.setNamespaceAware(true);
    factory.setValidating(false);

    DocumentBuilder builder = factory.newDocumentBuilder();
    Document doc = builder.newDocument();
    Element el = doc.createElementNS(NS_URI_WSDL,
                                     "wsdl:documentation");

    message.setDocumentationElement(el);

    Element el2 = message.getDocumentationElement();

    Assert.assertTrue("Message.getDocumentationElement() did not " +
                      "return the same Element that was set using " +
                      "Message.setDocumentationElement(...).",
                      el == el2);
  }

  /**
   * Test Message.setQName(...) and Message.getQName().
   */
  public void testSetGetQName()
  {
    QName qname = new QName("urn:abc", "def");

    message.setQName(qname);

    QName qname2 = message.getQName();

    Assert.assertTrue("Definition.getQName() did not return " +
                      "the same QName that was set using " +
                      "Definition.setQName(...).",
                      qname.equals(qname2));
  }

  /**
   * Test Message.setUndefined(...) and Message.isUndefined().
   */
  public void testIsSetUndefined()
  {
    Assert.assertTrue("The default value of the undefined property " +
                      "of a newly created Message should be " +
                      "true.",
                      message.isUndefined());

    message.setUndefined(false);

    Assert.assertFalse("Message.isUndefined() returned " +
                       "true even though Message.setUndefined(false) " +
                       "was called.",
                       message.isUndefined());
  } 
}