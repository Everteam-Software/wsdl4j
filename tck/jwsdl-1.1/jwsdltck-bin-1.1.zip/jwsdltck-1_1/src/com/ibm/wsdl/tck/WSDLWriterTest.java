/*
 * (c) Copyright IBM Corp 2001, 2005 
 */

package com.ibm.wsdl.tck;

import com.ibm.wsdl.tck.util.*;
import java.io.*;
import javax.wsdl.*;
import javax.wsdl.extensions.*;
import javax.wsdl.extensions.soap.*;
import javax.wsdl.factory.*;
import javax.wsdl.xml.*;
import junit.framework.*;
import org.w3c.dom.*;
import org.xml.sax.*;

/**
 * This class implements a series of tests used to check
 * javax.wsdl.xml.WSDLWriter implementations for compliance
 * with the JWSDL specification.
 *
 * @author Matthew J. Duftler (duftler@us.ibm.com)
 */
public class WSDLWriterTest extends TestCase
{
  private static final String TEST_CANDIDATE_PROPERTY_NAME =
    "javax.wsdl.factory.WSDLFactoryCandidate";
  private static final String NS_URI_WSDL =
    "http://schemas.xmlsoap.org/wsdl/";

  private WSDLFactory factory = null;
  private WSDLReader wsdlReader = null;
  private Definition definition = null;
  private Definition definitionWithSchemas = null;
  private WSDLWriter wsdlWriter = null;

  protected void setUp() throws WSDLException
  {
    // Determine name of JWSDL factory implementation to test.
    String testCandidateName =
      System.getProperty(TEST_CANDIDATE_PROPERTY_NAME);

    if (testCandidateName == null)
    {
      throw new IllegalArgumentException("System property '" +
                                         TEST_CANDIDATE_PROPERTY_NAME +
                                         "' must be specified to run " +
                                         "test suite.");
    }

    factory = WSDLFactory.newInstance(testCandidateName);

    Assert.assertNotNull("WSDLFactory should not be null.", factory);

    wsdlReader = factory.newWSDLReader();

    Assert.assertNotNull("WSDLReader should not be null.", wsdlReader);

    String jwsdltck_home =
      System.getProperty("jwsdltck_home", System.getProperty("user.dir"));
    File dir = new File(jwsdltck_home, "resources");
    File file = new File(dir, "AddressBook.wsdl");
    String fileName = file.toString();

    wsdlReader.setFeature("javax.wsdl.verbose", false);

    definition = wsdlReader.readWSDL(fileName);

    Assert.assertNotNull("WSDLReader.readWSDL(\"" + fileName + "\") " +
                         "should not return null.",
                         definition);

    wsdlWriter = factory.newWSDLWriter();

    Assert.assertNotNull("WSDLWriter should not be null.", wsdlWriter);
    
    //Added for JWSDL 1.1 Maintenance Release.
    //Read in a wsdl definition that contains xml schemas for use
    //in the write-wsdl-with-schemas testing.
    
    File dir2 = new File(dir, "schemas");
    File file2 = new File(dir2, "TravelCo.wsdl");
    String fileNameWithSchemas = file2.toString();

    wsdlReader.setFeature("javax.wsdl.verbose", false);
    
    definitionWithSchemas = wsdlReader.readWSDL(fileNameWithSchemas);
  }

  /**
   * Test each variation of WSDLWriter.writeWSDL(...), and
   * WSDLWriter.getDocument(...), to ensure that round-tripped
   * definitions still contain the same information.
   */
  public void testWriteWSDL() throws WSDLException
  {
    _testWriteWSDL();

    setUp();
    _testWriteWSDL2();

    setUp();
    _testGetDocument();
  }

  private void _testWriteWSDL() throws WSDLException
  {
    ByteArrayOutputStream baos = new ByteArrayOutputStream();

    wsdlWriter.writeWSDL(definition, baos);

    byte[] bytes = baos.toByteArray();
    ByteArrayInputStream bais = new ByteArrayInputStream(bytes);
    InputSource inputSource = new InputSource(bais);
    Definition definition2 = wsdlReader.readWSDL(null, inputSource);

    TCKUtils.walkDefinition(definition2);
  }

  private void _testWriteWSDL2() throws WSDLException
  {
    StringWriter sw = new StringWriter();

    wsdlWriter.writeWSDL(definition, sw);

    String str = sw.toString();
    StringReader sr = new StringReader(str);
    InputSource inputSource = new InputSource(sr);
    Definition definition2 = wsdlReader.readWSDL(null, inputSource);

    TCKUtils.walkDefinition(definition2);
  }

  private void _testGetDocument() throws WSDLException
  {
    Document doc = wsdlWriter.getDocument(definition);
    Definition definition2 = wsdlReader.readWSDL(null, doc);

    TCKUtils.walkDefinition(definition2);
  }
  
  /** Added for the JWSDL 1.1 Maintenance Release.
   * 
   * Test writing a wsdl definition that has imported, included
   * and redefined schemas.
   * 
   * @author John Kaputin
   */
  public void testWriteWSDLWithSchemas() throws WSDLException
  {
    _testWriteWSDLWithSchemas();

    setUp();
    _testGetDocumentWithSchemas();
  }

  private void _testWriteWSDLWithSchemas() throws WSDLException
  {
    StringWriter sw = new StringWriter();

    wsdlWriter.writeWSDL(definitionWithSchemas, sw);

    String str = sw.toString();
    StringReader sr = new StringReader(str);
    InputSource inputSource = new InputSource(sr);
    Definition definition2 = wsdlReader.readWSDL(
        definitionWithSchemas.getDocumentBaseURI(), inputSource);

    TCKUtils.walkDefinitionWithSchemas(definition2);
  }
  
  private void _testGetDocumentWithSchemas() throws WSDLException
  {
    Document doc = wsdlWriter.getDocument(definitionWithSchemas);
    Definition definition2 = wsdlReader.readWSDL(
        definitionWithSchemas.getDocumentBaseURI(), doc);

    TCKUtils.walkDefinitionWithSchemas(definition2);
  }
}