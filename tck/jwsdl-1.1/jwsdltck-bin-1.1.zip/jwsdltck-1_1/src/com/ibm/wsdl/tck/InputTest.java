/*
 * (c) Copyright IBM Corp 2001, 2005 
 */

package com.ibm.wsdl.tck;

import javax.wsdl.*;
import javax.wsdl.extensions.*;
import javax.wsdl.factory.*;
import javax.wsdl.xml.*;
import javax.xml.namespace.*;
import javax.xml.parsers.*;
import junit.framework.*;
import org.w3c.dom.*;

/**
 * This class implements a series of tests used to check
 * javax.wsdl.Input implementations for compliance
 * with the JWSDL specification.
 *
 * @author Matthew J. Duftler (duftler@us.ibm.com)
 */
public class InputTest extends TestCase
{
  private static final String TEST_CANDIDATE_PROPERTY_NAME =
    "javax.wsdl.factory.WSDLFactoryCandidate";
  private static final String NS_URI_WSDL =
    "http://schemas.xmlsoap.org/wsdl/";

  private Definition definition = null;
  private Input input = null;

  protected void setUp() throws WSDLException
  {
    // Determine name of JWSDL factory implementation to test.
    String testCandidateName =
      System.getProperty(TEST_CANDIDATE_PROPERTY_NAME);

    if (testCandidateName == null)
    {
      throw new IllegalArgumentException("System property '" +
                                         TEST_CANDIDATE_PROPERTY_NAME +
                                         "' must be specified to run " +
                                         "test suite.");
    }

    WSDLFactory factory = WSDLFactory.newInstance(testCandidateName);

    Assert.assertNotNull("WSDLFactory should not be null.", factory);

    definition = factory.newDefinition();

    Assert.assertNotNull("Definition should not be null.", definition);

    input = definition.createInput();

    Assert.assertNotNull("Input should not be null.", input);
  }

  /**
   * Test Input.setDocumentationElement(...) and
   * Input.getDocumentationElement().
   */
  public void testSetGetDocumentationElement()
    throws ParserConfigurationException
  {
    DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();

    factory.setNamespaceAware(true);
    factory.setValidating(false);

    DocumentBuilder builder = factory.newDocumentBuilder();
    Document doc = builder.newDocument();
    Element el = doc.createElementNS(NS_URI_WSDL,
                                     "wsdl:documentation");

    input.setDocumentationElement(el);

    Element el2 = input.getDocumentationElement();

    Assert.assertTrue("Input.getDocumentationElement() did not " +
                      "return the same Element that was set using " +
                      "Input.setDocumentationElement(...).",
                      el == el2);
  }

  /**
   * Test Input.setMessage(...) and Input.getMessage().
   */
  public void testSetGetMessage()
  {
    Message message = definition.createMessage();

    Assert.assertNotNull("Message should not be null.", message);

    input.setMessage(message);

    Message message2 = input.getMessage();

    Assert.assertTrue("Input.getMessage() did not return " +
                      "the same Message that was set using " +
                      "Input.setMessage(...).",
                      message == message2);
  }

  /**
   * Test Input.setName(...) and Input.getName().
   */
  public void testSetGetName()
  {
    String name = "abcdef";

    input.setName(name);

    String name2 = input.getName();

    Assert.assertTrue("Input.getName() did not return " +
                      "the same name that was set using " +
                      "Input.setName(...).",
                      name.equals(name2));
  }
}