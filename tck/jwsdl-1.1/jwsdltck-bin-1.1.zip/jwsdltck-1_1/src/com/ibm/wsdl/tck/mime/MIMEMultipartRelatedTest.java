/*
 * (c) Copyright IBM Corp 2001, 2005 
 */

package com.ibm.wsdl.tck.mime;

import com.ibm.wsdl.tck.util.*;
import java.io.*;
import java.util.*;
import javax.wsdl.*;
import javax.wsdl.extensions.*;
import javax.wsdl.extensions.mime.*;
import javax.wsdl.factory.*;
import javax.wsdl.xml.*;
import javax.xml.namespace.*;
import junit.framework.*;

/**
 * This class implements a series of tests used to check
 * javax.wsdl.extensions.mime.MIMEMultipartRelated implementations
 * for compliance with the JWSDL specification.
 *
 * @author Matthew J. Duftler (duftler@us.ibm.com)
 */
public class MIMEMultipartRelatedTest extends TestCase
{
  private static final String TEST_CANDIDATE_PROPERTY_NAME =
    "javax.wsdl.factory.WSDLFactoryCandidate";
  private static final String NS_URI_MIME =
    "http://schemas.xmlsoap.org/wsdl/mime/";

  private WSDLFactory factory = null;
  private ExtensionRegistry extReg = null;
  private MIMEMultipartRelated mimeMultipartRelated = null;

  protected void setUp() throws WSDLException, IOException
  {
    // Determine name of JWSDL factory implementation to test.
    String testCandidateName =
      System.getProperty(TEST_CANDIDATE_PROPERTY_NAME);

    if (testCandidateName == null)
    {
      throw new IllegalArgumentException("System property '" +
                                         TEST_CANDIDATE_PROPERTY_NAME +
                                         "' must be specified to run " +
                                         "test suite.");
    }

    factory = WSDLFactory.newInstance(testCandidateName);

    Assert.assertNotNull("WSDLFactory should not be null.", factory);

    extReg = factory.newPopulatedExtensionRegistry();

    Assert.assertNotNull("ExtensionRegistry should not be null.", extReg);

    QName mimeMultipartRelatedQName = new QName(NS_URI_MIME,
                                                "multipartRelated");

    mimeMultipartRelated =
      (MIMEMultipartRelated)TCKUtils.createExtension(
        extReg,
        BindingInput.class,
        mimeMultipartRelatedQName,
        MIMEMultipartRelated.class);
  }

  /**
   * Test MIMEMultipartRelated.addMIMEPart(...) and
   * MIMEMultipartRelated.getMIMEParts().
   */
  public void testAddGetMIMEPart()
  {
    QName mimePartQName = new QName(NS_URI_MIME, "part");
    MIMEPart mimePart1 =
      (MIMEPart)TCKUtils.createExtension(
        extReg,
        MIMEMultipartRelated.class,
        mimePartQName,
        MIMEPart.class);
    MIMEPart mimePart2 =
      (MIMEPart)TCKUtils.createExtension(
        extReg,
        MIMEMultipartRelated.class,
        mimePartQName,
        MIMEPart.class);
    MIMEPart mimePart3 =
      (MIMEPart)TCKUtils.createExtension(
        extReg,
        MIMEMultipartRelated.class,
        mimePartQName,
        MIMEPart.class);

    mimeMultipartRelated.addMIMEPart(mimePart2);
    mimeMultipartRelated.addMIMEPart(mimePart3);
    mimeMultipartRelated.addMIMEPart(mimePart1);

    List expectedParts =
      Arrays.asList(new Object[]{mimePart2, mimePart3, mimePart1});
    List actualParts = mimeMultipartRelated.getMIMEParts();

    Assert.assertTrue("MIMEMultipartRelated.getMIMEParts() did not return " +
                      "the correct list of MIMEParts.",
                      expectedParts.equals(actualParts));
  }
}