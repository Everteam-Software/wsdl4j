/*
 * (c) Copyright IBM Corp 2001, 2005 
 */

package com.ibm.wsdl.tck;

import java.io.*;
import java.util.*;
import javax.wsdl.*;
import javax.wsdl.extensions.*;
import javax.wsdl.factory.*;
import junit.framework.*;

/**
 * This class implements a series of tests used to check
 * javax.wsdl.factory.WSDLFactory implementations for compliance
 * with the JWSDL specification.
 *
 * @author Matthew J. Duftler (duftler@us.ibm.com)
 */
public class FactoryTest extends TestCase
{
  private static final String TEST_CANDIDATE_PROPERTY_NAME =
    "javax.wsdl.factory.WSDLFactoryCandidate";
  private static final String PROPERTY_NAME =
    "javax.wsdl.factory.WSDLFactory";
  private static final String PROPERTY_FILE_NAME =
    "wsdl.properties";
  private static final String FULL_PROPERTY_FILE_NAME =
    new File(new File(System.getProperty("java.home"), "lib"),
             PROPERTY_FILE_NAME).toString();

  private String testCandidateName = null;
  private File origPropFile = null;
  private Properties origProps = null;

  protected void setUp() throws IOException
  {
    // Determine name of JWSDL factory implementation to test.
    testCandidateName = System.getProperty(TEST_CANDIDATE_PROPERTY_NAME);

    if (testCandidateName == null)
    {
      throw new IllegalArgumentException("System property '" +
                                         TEST_CANDIDATE_PROPERTY_NAME +
                                         "' must be specified to run " +
                                         "test suite.");
    }

    // Clear JWSDL system property.
    System.getProperties().remove(PROPERTY_NAME);

    /*
      Hold onto the contents of the original JWSDL properties file and
      delete the actual file.
    */
    origPropFile = new File(FULL_PROPERTY_FILE_NAME);
    origProps = loadPropFile(origPropFile);

    if (origPropFile.exists())
    {
      origPropFile.delete();
    }
  }

  protected void tearDown() throws IOException
  {
    /*
      Restore the JWSDL properties file if it originally existed,
      otherwise make sure it does not exist now.
    */
    if (origProps != null)
    {
      storePropFile(origProps, origPropFile);
    }
    else if (origPropFile.exists())
    {
      origPropFile.delete();
    }
  }

  /**
   * Test WSDLFactory.newInstance() to ensure that factory instances
   * can be retrieved by specifying the
   * <code>javax.wsdl.factory.WSDLFactory</code> system property.
   */
  public void testNewInstance() throws WSDLException
  {
    System.setProperty(PROPERTY_NAME, testCandidateName);

    WSDLFactory factory = WSDLFactory.newInstance();

    Assert.assertNotNull("WSDLFactory should not be null.", factory);
  }

  /**
   * Test WSDLFactory.newInstance() to ensure that factory instances
   * can be retrieved by providing a lib/wsdl.properties file in the
   * JRE directory.
   */
  public void testNewInstance2() throws WSDLException, IOException
  {
    Properties props = new Properties();

    props.setProperty(PROPERTY_NAME, testCandidateName);

    storePropFile(props, origPropFile);

    WSDLFactory factory = WSDLFactory.newInstance();

    Assert.assertNotNull("WSDLFactory should not be null.", factory);
  }

  /**
   * Test WSDLFactory.newInstance() to ensure that factory instances
   * can be retrieved by relying on a platform default.
   */
  public void testNewInstance3() throws WSDLException
  {
    WSDLFactory factory = WSDLFactory.newInstance();

    Assert.assertNotNull("WSDLFactory should not be null.", factory);
  }

  /**
   * Test WSDLFactory.newInstance(...) to ensure that factory instances
   * can be retrieved by specifying an explicit factory implementation
   * to use.
   */
  public void testNewInstance4() throws WSDLException
  {
    WSDLFactory factory = WSDLFactory.newInstance(testCandidateName);

    Assert.assertNotNull("WSDLFactory should not be null.", factory);
  }

  private static Properties loadPropFile(File propFile) throws IOException
  {
    Properties properties = null;

    if (propFile.exists())
    {
      FileInputStream fis = new FileInputStream(propFile);

      properties = new Properties();
      properties.load(fis);
      fis.close();
    }

    return properties;
  }

  public static void storePropFile(Properties properties,
                                   File propFile) throws IOException
  {
    FileOutputStream fos = new FileOutputStream(propFile);

    properties.store(fos, null);

    fos.close();
  }
}