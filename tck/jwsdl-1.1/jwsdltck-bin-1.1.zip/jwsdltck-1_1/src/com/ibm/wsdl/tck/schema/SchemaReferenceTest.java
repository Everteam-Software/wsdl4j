/*
 * (c) Copyright IBM Corp 2005 
 */

package com.ibm.wsdl.tck.schema;

import com.ibm.wsdl.tck.util.*;
import java.io.*;
import javax.wsdl.*;
import javax.wsdl.extensions.*;
import javax.wsdl.extensions.schema.*;
import javax.wsdl.factory.*;
import javax.xml.namespace.*;
import junit.framework.*;

/**
 * This class implements a series of tests used to check
 * javax.wsdl.extensions.schema.SchemaReference implementations
 * for compliance with the JWSDL specification.
 *
 * @author John Kaputin (kaputin@uk.ibm.com)
 */
public class SchemaReferenceTest extends TestCase
{
  private static final String TEST_CANDIDATE_PROPERTY_NAME =
    "javax.wsdl.factory.WSDLFactoryCandidate";
  private static final String NS_URI_XSD_2001 =
      "http://www.w3.org/2001/XMLSchema";

  private WSDLFactory factory = null;
  private ExtensionRegistry extReg = null;
  private Schema schema = null;
  private Schema referencedSchema = null;

  protected void setUp() throws WSDLException, IOException
  {
    // Determine name of JWSDL factory implementation to test.
    String testCandidateName =
      System.getProperty(TEST_CANDIDATE_PROPERTY_NAME);

    if (testCandidateName == null)
    {
      throw new IllegalArgumentException("System property '" +
                                         TEST_CANDIDATE_PROPERTY_NAME +
                                         "' must be specified to run " +
                                         "test suite.");
    }

    factory = WSDLFactory.newInstance(testCandidateName);

    Assert.assertNotNull("WSDLFactory should not be null.", factory);

    extReg = factory.newPopulatedExtensionRegistry();

    Assert.assertNotNull("ExtensionRegistry should not be null.", extReg);

    QName schemaQName = new QName(NS_URI_XSD_2001, "schema");

    schema = (Schema)TCKUtils.createExtension(extReg,
                                              Types.class,
                                              schemaQName,
                                              Schema.class);

    referencedSchema = (Schema)TCKUtils.createExtension(extReg,
                                              Types.class,
                                              schemaQName,
                                              Schema.class);
  }

  /**
   * Test SchemaReference.setId(...) and SchemaReference.getId().
   */
  public void testSetGetId()
  {
    String id = "abcdef";
    SchemaReference sr = schema.createInclude();

    sr.setId(id);

    String id2 = sr.getId();

    Assert.assertTrue("SchemaReference.getId() did not return " +
                      "the same id that was set using " +
                      "SchemaReference.setId(...).",
                      id.equals(id2));
  }

  /**
   * Test SchemaReference.setReferencedSchema(...)  
   * and SchemaReference.getReferencedSchema().
   */
  public void testSetGetReferencedSchema()
  {
    SchemaReference sr = schema.createInclude();

    sr.setReferencedSchema(referencedSchema);

    Schema referencedSchema2 = sr.getReferencedSchema();

    Assert.assertTrue("SchemaReference.getReferencedSchema() did not return " +
                      "the same Schema object that was set using " +
                      "SchemaReference.setReferencedSchema(...).",
                      referencedSchema.equals(referencedSchema2));
  }

  /**
   * Test SchemaReference.setSchemaLocationURI(...)  
   * and SchemaReference.getSchemaLocationURI().
   */
  public void testSetGetSchemaLocationURI()
  {
    String loc = "urn:abcdef";
    SchemaReference sr = schema.createInclude();

    sr.setSchemaLocationURI(loc);

    String loc2 = sr.getSchemaLocationURI();

    Assert.assertTrue("SchemaReference.getSchemaLocationURI() did not return " +
                      "the same location that was set using " +
                      "SchemaReference.setSchemaLocationURI(...).",
                      loc.equals(loc2));
  }

}
