/*
 * (c) Copyright IBM Corp 2001, 2005 
 */

package com.ibm.sigtest;

import java.io.*;

/**
 * This class compares a project file to either the classes currently
 * available on the classpath, or another project file.
 *
 * @author Matthew J. Duftler (duftler@us.ibm.com)
 */
public class TestSignatures
{
  private static void printUsage()
  {
    System.err.println("Usage:\n\n" +
                       "  java " + TestSignatures.class.getName() +
                       " [args]\n\n" +
                       "    args:\n\n" +
                       "      -projectFile1   name of file containing " +
                       "signatures\n" +
                       "      [-projectFile2  name of file to compare " +
                       "projectFile1 to]\n" +
                       "                      If this argument is not " +
                       "specified, projectFile1 is\n" +
                       "                      compared to the classes " +
                       "currently available on the\n" +
                       "                      classpath.");
    System.exit(1);
  }

  public static void main(String[] argv) throws Exception
  {
    if (argv.length % 2 != 0)
    {
      printUsage();
    }

    File projectFile1 = null;
    File projectFile2 = null;

    for (int i = 0; i < argv.length; i += 2)
    {
      String option = argv[i];
      String value = argv[i + 1];

      if (option.equals("-projectFile1"))
      {
        projectFile1 = new File(value);
      }
      else if (option.equals("-projectFile2"))
      {
        projectFile2 = new File(value);
      }
      else
      {
        printUsage();
      }
    }

    if (projectFile1 == null)
    {
      printUsage();
    }

    String result = null;

    if (projectFile2 == null)
    {
      result = ProjectDesc.compareProjectFile(projectFile1);
    }
    else
    {
      ProjectDesc pd1 =
        ProjectDesc.readProjectFile("Project 1", projectFile1);
      ProjectDesc pd2 =
        ProjectDesc.readProjectFile("Project 2", projectFile2);

      result = pd1.compare(pd2);
    }

    System.out.println(result != null
                       ? result
                       : "They match perfectly.");
  }
}

