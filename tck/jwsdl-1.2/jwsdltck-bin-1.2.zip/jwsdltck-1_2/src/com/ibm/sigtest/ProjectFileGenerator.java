/*
 * (c) Copyright IBM Corp 2001, 2005 
 */

package com.ibm.sigtest;

/**
 * This class generates a project file which contains a snapshot
 * of the current signatures of the specified classes.
 *
 * @author Matthew J. Duftler (duftler@us.ibm.com)
 */
public class ProjectFileGenerator
{
  private static void printUsage()
  {
    System.err.println("Usage:\n\n" +
                       "  java " + ProjectFileGenerator.class.getName() +
                       " [args]\n\n" +
                       "    args:\n\n" +
                       "      -classListFile  name of file containing " +
                       "CR-separated list of classes\n" +
                       "                      to include\n" +
                       "      -projectFile    name of file to generate\n" +
                       "      [-overwrite     (on|off)]   default: off" +
                       "   (Overwrite existing files?)");
    System.exit(1);
  }

  public static void main(String[] argv) throws Exception
  {
    long startTime = System.currentTimeMillis();

    if (argv.length % 2 != 0)
    {
      printUsage();
    }

    String classListFile = null;
    String projectFile = null;
    boolean overwrite = false;

    for (int i = 0; i < argv.length; i += 2)
    {
      String option = argv[i];
      String value = argv[i + 1];

      if (option.equals("-classListFile"))
      {
        classListFile = value;
      }
      else if (option.equals("-projectFile"))
      {
        projectFile = value;
      }
      else if (option.equals("-overwrite"))
      {
        overwrite = value.equals("on");
      }
      else
      {
        printUsage();
      }
    }

    if (classListFile == null || projectFile == null)
    {
      printUsage();
    }

    SigTestUtils.generateProjectFile(classListFile, projectFile, overwrite);

    long endTime = System.currentTimeMillis();

    System.out.println("Done.\n" +
                       "Elapsed time: " + (endTime - startTime) + "ms");
  }
}

