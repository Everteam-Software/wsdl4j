/*
 * (c) Copyright IBM Corp 2006 
 */

package com.ibm.sigtest;

/**
 * This class generates a project file which contains a snapshot
 * of the current signatures of the specified classes.
 */
public class ProjectFileGenerator2
{
  public static void main(String[] argv) throws Exception
  {
    SigTestUtils.generateProjectFileFromPackage("javax.wsdl", "resources/ri.sig", true);
  }
}

