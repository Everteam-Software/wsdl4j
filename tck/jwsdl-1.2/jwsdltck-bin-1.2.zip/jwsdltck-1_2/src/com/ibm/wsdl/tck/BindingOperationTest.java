/*
 * (c) Copyright IBM Corp 2001, 2006 
 */

package com.ibm.wsdl.tck;

import javax.wsdl.*;
import javax.wsdl.factory.*;
import javax.xml.parsers.*;
import junit.framework.*;
import org.w3c.dom.*;

/**
 * This class implements a series of tests used to check
 * javax.wsdl.BindingOperation implementations for compliance
 * with the JWSDL specification.
 *
 * @author Matthew J. Duftler (duftler@us.ibm.com)
 */
public class BindingOperationTest extends TestCase
{
  private static final String TEST_CANDIDATE_PROPERTY_NAME =
    "javax.wsdl.factory.WSDLFactoryCandidate";
  private static final String NS_URI_WSDL =
    "http://schemas.xmlsoap.org/wsdl/";

  private Definition definition = null;
  private BindingOperation bindingOperation = null;

  protected void setUp() throws WSDLException
  {
    // Determine name of JWSDL factory implementation to test.
    String testCandidateName =
      System.getProperty(TEST_CANDIDATE_PROPERTY_NAME);

    if (testCandidateName == null)
    {
      throw new IllegalArgumentException("System property '" +
                                         TEST_CANDIDATE_PROPERTY_NAME +
                                         "' must be specified to run " +
                                         "test suite.");
    }

    WSDLFactory factory = WSDLFactory.newInstance(testCandidateName);

    Assert.assertNotNull("WSDLFactory should not be null.", factory);

    definition = factory.newDefinition();

    Assert.assertNotNull("Definition should not be null.", definition);

    bindingOperation = definition.createBindingOperation();

    Assert.assertNotNull("BindingOperation should not be null.",
                         bindingOperation);
  }

  /**
   * Test BindingOperation.addBindingFault(...),
   * BindingOperation.getBindingFault(...) and
   * BindingOperation.removeBindingFault(...).
   */
  public void testAddGetRemoveBindingFault()
  {
    BindingFault bindingFault = definition.createBindingFault();

    Assert.assertNotNull("BindingFault should not be null.", bindingFault);

    bindingFault.setName("abcdef");
    bindingOperation.addBindingFault(bindingFault);

    BindingFault bindingFault2 = bindingOperation.getBindingFault("abcdef");

    Assert.assertTrue("BindingOperation.getBindingFault(...) did not return " +
                      "the same BindingFault that was added using " +
                      "BindingOperation.addBindingFault(...).",
                      bindingFault == bindingFault2);
    
    BindingFault bindingFault3 = bindingOperation.removeBindingFault("abcdef");
    
    Assert.assertTrue("BindingOperation.removeBindingFault(...) did not return " +
                      "the same BindingFault that was added using " +
                      "BindingOperation.addBindingFault(...).",
                      bindingFault == bindingFault3);
  }

  /**
   * Test BindingOperation.setBindingInput(...) and
   * BindingOperation.getBindingInput().
   */
  public void testSetGetBindingInput()
  {
    BindingInput bindingInput = definition.createBindingInput();

    Assert.assertNotNull("BindingInput should not be null.", bindingInput);

    bindingOperation.setBindingInput(bindingInput);

    BindingInput bindingInput2 = bindingOperation.getBindingInput();

    Assert.assertTrue("BindingOperation.getBindingInput() did not return " +
                      "the same BindingInput that was set using " +
                      "BindingOperation.setBindingInput(...).",
                      bindingInput == bindingInput2);
  }

  /**
   * Test BindingOperation.setBindingOutput(...) and
   * BindingOperation.getBindingOutput().
   */
  public void testSetGetBindingOutput()
  {
    BindingOutput bindingOutput = definition.createBindingOutput();

    Assert.assertNotNull("BindingOutput should not be null.", bindingOutput);

    bindingOperation.setBindingOutput(bindingOutput);

    BindingOutput bindingOutput2 = bindingOperation.getBindingOutput();

    Assert.assertTrue("BindingOperation.getBindingOutput() did not return " +
                      "the same BindingOutput that was set using " +
                      "BindingOperation.setBindingOutput(...).",
                      bindingOutput == bindingOutput2);
  }

  /**
   * Test BindingOperation.setDocumentationElement(...) and
   * BindingOperation.getDocumentationElement().
   */
  public void testSetGetDocumentationElement()
    throws ParserConfigurationException
  {
    DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();

    factory.setNamespaceAware(true);
    factory.setValidating(false);

    DocumentBuilder builder = factory.newDocumentBuilder();
    Document doc = builder.newDocument();
    Element el = doc.createElementNS(NS_URI_WSDL,
                                     "wsdl:documentation");

    bindingOperation.setDocumentationElement(el);

    Element el2 = bindingOperation.getDocumentationElement();

    Assert.assertTrue("BindingOperation.getDocumentationElement() did not " +
                      "return the same Element that was set using " +
                      "BindingOperation.setDocumentationElement(...).",
                      el == el2);
  }

  /**
   * Test BindingOperation.setName(...) and
   * BindingOperation.getName().
   */
  public void testSetGetName()
  {
    String name = "abcdef";

    bindingOperation.setName(name);

    String name2 = bindingOperation.getName();

    Assert.assertTrue("BindingOperation.getName() did not return " +
                      "the same name that was set using " +
                      "BindingOperation.setName(...).",
                      name.equals(name2));
  }

  /**
   * Test BindingOperation.setOperation(...) and
   * BindingOperation.getOperation().
   */
  public void testSetGetOperation()
  {
    Operation operation = definition.createOperation();

    Assert.assertNotNull("Operation should not be null.", operation);

    bindingOperation.setOperation(operation);

    Operation operation2 = bindingOperation.getOperation();

    Assert.assertTrue("BindingOperation.getOperation() did not return " +
                      "the same Operation that was set using " +
                      "BindingOperation.setOperation(...).",
                      operation == operation2);
  }
}