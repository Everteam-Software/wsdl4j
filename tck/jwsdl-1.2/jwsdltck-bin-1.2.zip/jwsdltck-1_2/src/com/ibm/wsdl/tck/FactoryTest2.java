/*
 * (c) Copyright IBM Corp 2001, 2006 
 */

package com.ibm.wsdl.tck;

import javax.wsdl.*;
import javax.wsdl.extensions.*;
import javax.wsdl.factory.*;
import javax.wsdl.xml.*;
import junit.framework.*;

/**
 * This class implements a series of tests used to check
 * javax.wsdl.factory.WSDLFactory implementations for compliance
 * with the JWSDL specification.
 *
 * @author Matthew J. Duftler (duftler@us.ibm.com)
 */
public class FactoryTest2 extends TestCase
{
  private static final String TEST_CANDIDATE_PROPERTY_NAME =
    "javax.wsdl.factory.WSDLFactoryCandidate";

  private WSDLFactory factory = null;

  protected void setUp() throws WSDLException
  {
    // Determine name of JWSDL factory implementation to test.
    String testCandidateName =
      System.getProperty(TEST_CANDIDATE_PROPERTY_NAME);

    if (testCandidateName == null)
    {
      throw new IllegalArgumentException("System property '" +
                                         TEST_CANDIDATE_PROPERTY_NAME +
                                         "' must be specified to run " +
                                         "test suite.");
    }

    factory = WSDLFactory.newInstance(testCandidateName);

    Assert.assertNotNull("WSDLFactory should not be null.", factory);
  }

  /**
   * Test WSDLFactory.newDefinition() to ensure that definitions
   * can be created using a newly created factory.
   */
  public void testNewDefinition()
  {
    Definition definition = factory.newDefinition();

    Assert.assertNotNull("Definition should not be null.", definition);
  }

  /**
   * Test WSDLFactory.newWSDLReader() to ensure that WSDLReaders
   * can be created using a newly created factory.
   */
  public void testNewWSDLReader()
  {
    WSDLReader reader = factory.newWSDLReader();

    Assert.assertNotNull("WSDLReader should not be null.", reader);
  }

  /**
   * Test WSDLFactory.newWSDLWriter() to ensure that WSDLWriters
   * can be created using a newly created factory.
   */
  public void testNewWSDLWriter()
  {
    WSDLWriter writer = factory.newWSDLWriter();

    Assert.assertNotNull("WSDLWriter should not be null.", writer);
  }

  /**
   * Test WSDLFactory.newPopulatedExtensionRegistry() to ensure that
   * populated ExtensionRegistries can be created using a newly created
   * factory.
   */
  public void testNewPopulatedExtensionRegistry()
  {
    ExtensionRegistry extReg = factory.newPopulatedExtensionRegistry();

    Assert.assertNotNull("ExtensionRegistry should not be null.", extReg);
  }
}