/*
 * (c) Copyright IBM Corp 2005 
 */

package com.ibm.wsdl.tck.schema;

import com.ibm.wsdl.tck.util.*;
import java.io.*;
import javax.wsdl.*;
import javax.wsdl.extensions.*;
import javax.wsdl.extensions.schema.*;
import javax.wsdl.factory.*;
import javax.xml.namespace.*;
import junit.framework.*;

/**
 * This class implements a series of tests used to check
 * javax.wsdl.extensions.schema.SchemaImport implementations
 * for compliance with the JWSDL specification.
 *
 * @author John Kaputin (kaputin@uk.ibm.com)
 */
public class SchemaImportTest extends TestCase
{
  private static final String TEST_CANDIDATE_PROPERTY_NAME =
    "javax.wsdl.factory.WSDLFactoryCandidate";
  private static final String NS_URI_XSD_2001 =
      "http://www.w3.org/2001/XMLSchema";

  private WSDLFactory factory = null;
  private ExtensionRegistry extReg = null;
  private Schema schema = null;
  private Schema referencedSchema = null;

  protected void setUp() throws WSDLException, IOException
  {
    // Determine name of JWSDL factory implementation to test.
    String testCandidateName =
      System.getProperty(TEST_CANDIDATE_PROPERTY_NAME);

    if (testCandidateName == null)
    {
      throw new IllegalArgumentException("System property '" +
                                         TEST_CANDIDATE_PROPERTY_NAME +
                                         "' must be specified to run " +
                                         "test suite.");
    }

    factory = WSDLFactory.newInstance(testCandidateName);

    Assert.assertNotNull("WSDLFactory should not be null.", factory);

    extReg = factory.newPopulatedExtensionRegistry();

    Assert.assertNotNull("ExtensionRegistry should not be null.", extReg);

    QName schemaQName = new QName(NS_URI_XSD_2001, "schema");

    schema = (Schema)TCKUtils.createExtension(extReg,
                                              Types.class,
                                              schemaQName,
                                              Schema.class);
  }

  /**
   * Test SchemaImport.setNamespaceURI(...)  
   * and SchemaImport.getNamespaceURI().
   */
  public void testSetGetNamespaceURI()
  {
    String uri = "urn";
    SchemaImport si = schema.createImport();

    si.setNamespaceURI(uri);

    String uri2 = si.getNamespaceURI();

    Assert.assertTrue("SchemaImport.getNamespaceURI() did not return " +
                      "the same namespace that was set using " +
                      "SchemaImport.setNamespaceURI(...).",
                      uri.equals(uri2));
  }

}
