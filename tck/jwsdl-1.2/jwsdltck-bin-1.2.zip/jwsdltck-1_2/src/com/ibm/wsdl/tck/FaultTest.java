/*
 * (c) Copyright IBM Corp 2001, 2006 
 */

package com.ibm.wsdl.tck;

import javax.wsdl.*;
import javax.wsdl.factory.*;
import javax.xml.parsers.*;
import junit.framework.*;
import org.w3c.dom.*;

/**
 * This class implements a series of tests used to check
 * javax.wsdl.Fault implementations for compliance
 * with the JWSDL specification.
 *
 * @author Matthew J. Duftler (duftler@us.ibm.com)
 */
public class FaultTest extends TestCase
{
  private static final String TEST_CANDIDATE_PROPERTY_NAME =
    "javax.wsdl.factory.WSDLFactoryCandidate";
  private static final String NS_URI_WSDL =
    "http://schemas.xmlsoap.org/wsdl/";

  private Definition definition = null;
  private Fault fault = null;

  protected void setUp() throws WSDLException
  {
    // Determine name of JWSDL factory implementation to test.
    String testCandidateName =
      System.getProperty(TEST_CANDIDATE_PROPERTY_NAME);

    if (testCandidateName == null)
    {
      throw new IllegalArgumentException("System property '" +
                                         TEST_CANDIDATE_PROPERTY_NAME +
                                         "' must be specified to run " +
                                         "test suite.");
    }

    WSDLFactory factory = WSDLFactory.newInstance(testCandidateName);

    Assert.assertNotNull("WSDLFactory should not be null.", factory);

    definition = factory.newDefinition();

    Assert.assertNotNull("Definition should not be null.", definition);

    fault = definition.createFault();

    Assert.assertNotNull("Fault should not be null.", fault);
  }

  /**
   * Test Fault.setDocumentationElement(...) and
   * Fault.getDocumentationElement().
   */
  public void testSetGetDocumentationElement()
    throws ParserConfigurationException
  {
    DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();

    factory.setNamespaceAware(true);
    factory.setValidating(false);

    DocumentBuilder builder = factory.newDocumentBuilder();
    Document doc = builder.newDocument();
    Element el = doc.createElementNS(NS_URI_WSDL,
                                     "wsdl:documentation");

    fault.setDocumentationElement(el);

    Element el2 = fault.getDocumentationElement();

    Assert.assertTrue("Fault.getDocumentationElement() did not " +
                      "return the same Element that was set using " +
                      "Fault.setDocumentationElement(...).",
                      el == el2);
  }

  /**
   * Test Fault.setMessage(...) and Fault.getMessage().
   */
  public void testSetGetMessage()
  {
    Message message = definition.createMessage();

    Assert.assertNotNull("Message should not be null.", message);

    fault.setMessage(message);

    Message message2 = fault.getMessage();

    Assert.assertTrue("Fault.getMessage() did not return " +
                      "the same Message that was set using " +
                      "Fault.setMessage(...).",
                      message == message2);
  }

  /**
   * Test Fault.setName(...) and Fault.getName().
   */
  public void testSetGetName()
  {
    String name = "abcdef";

    fault.setName(name);

    String name2 = fault.getName();

    Assert.assertTrue("Fault.getName() did not return " +
                      "the same name that was set using " +
                      "Fault.setName(...).",
                      name.equals(name2));
  }
}