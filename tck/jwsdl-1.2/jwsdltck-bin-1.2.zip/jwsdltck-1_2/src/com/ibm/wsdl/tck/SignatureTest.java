/*
 * (c) Copyright IBM Corp 2001, 2006 
 */

package com.ibm.wsdl.tck;

import com.ibm.sigtest.*;
import java.io.*;
import junit.framework.*;

/**
 * This class implements a series of tests used to check the
 * signatures of all the classes and methods of a JWSDL implementation
 * for compliance with the JWSDL specification.
 *
 * @author Matthew J. Duftler (duftler@us.ibm.com)
 */
public class SignatureTest extends TestCase
{
  /**
   * Test the signatures of all the classes and methods for compliance
   * with the JWSDL specification.
   */
  public void testSignatures() throws IOException
  {
    String jwsdltck_home =
      System.getProperty("jwsdltck_home", System.getProperty("user.dir"));
    File dir = new File(jwsdltck_home, "resources");
    File file = new File(dir, "ri.sig");
    String result = ProjectDesc.compareProjectFile(file);

    Assert.assertNull(result, result);
  }
}