/*
 * (c) Copyright IBM Corp 2006 
 */

package com.ibm.wsdl.tck.soap12;

import java.io.IOException;

import javax.wsdl.Binding;
import javax.wsdl.WSDLException;
import javax.wsdl.extensions.ExtensionRegistry;
import javax.wsdl.extensions.soap12.SOAP12Binding;
import javax.wsdl.factory.WSDLFactory;
import javax.xml.namespace.QName;

import junit.framework.Assert;
import junit.framework.TestCase;

import com.ibm.wsdl.tck.util.TCKUtils;

/**
 * This class implements a series of tests used to check
 * javax.wsdl.extensions.soap12.SOAP12Binding implementations
 * for compliance with the JWSDL specification.
 *
 * @author Matthew J. Duftler (duftler@us.ibm.com)
 */
public class SOAP12BindingTest extends TestCase
{
  private static final String TEST_CANDIDATE_PROPERTY_NAME =
    "javax.wsdl.factory.WSDLFactoryCandidate";
  private static final String NS_URI_SOAP12 =
    "http://schemas.xmlsoap.org/wsdl/soap12/";

  private WSDLFactory factory = null;
  private ExtensionRegistry extReg = null;
  private SOAP12Binding soapBinding = null;

  protected void setUp() throws WSDLException, IOException
  {
    // Determine name of JWSDL factory implementation to test.
    String testCandidateName =
      System.getProperty(TEST_CANDIDATE_PROPERTY_NAME);

    if (testCandidateName == null)
    {
      throw new IllegalArgumentException("System property '" +
                                         TEST_CANDIDATE_PROPERTY_NAME +
                                         "' must be specified to run " +
                                         "test suite.");
    }

    factory = WSDLFactory.newInstance(testCandidateName);

    Assert.assertNotNull("WSDLFactory should not be null.", factory);

    extReg = factory.newPopulatedExtensionRegistry();

    Assert.assertNotNull("ExtensionRegistry should not be null.", extReg);

    QName soapBindingQName = new QName(NS_URI_SOAP12, "binding");

    soapBinding = (SOAP12Binding)TCKUtils.createExtension(extReg,
                                                        Binding.class,
                                                        soapBindingQName,
                                                        SOAP12Binding.class);
  }

  /**
   * Test SOAP12Binding.setStyle(...) and SOAP12Binding.getStyle().
   */
  public void testSetGetStyle()
  {
    String style = "abcdef";

    soapBinding.setStyle(style);

    String style2 = soapBinding.getStyle();

    Assert.assertTrue("SOAP12Binding.getStyle() did not return " +
                      "the same style that was set using " +
                      "SOAP12Binding.setStyle(...).",
                      style.equals(style2));
  }

  /**
   * Test SOAP12Binding.setTransportURI(...) and SOAP12Binding.getTransportURI().
   */
  public void testSetGetTransportURI()
  {
    String transportURI = "urn:abcdef";

    soapBinding.setTransportURI(transportURI);

    String transportURI2 = soapBinding.getTransportURI();

    Assert.assertTrue("SOAP12Binding.getTransportURI() did not return " +
                      "the same transport URI that was set using " +
                      "SOAP12Binding.setTransportURI(...).",
                      transportURI.equals(transportURI2));
  }
}