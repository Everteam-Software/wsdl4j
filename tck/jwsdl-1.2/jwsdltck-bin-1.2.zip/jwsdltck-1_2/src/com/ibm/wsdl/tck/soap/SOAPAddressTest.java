/*
 * (c) Copyright IBM Corp 2001, 2006 
 */

package com.ibm.wsdl.tck.soap;

import com.ibm.wsdl.tck.util.*;
import java.io.*;
import javax.wsdl.*;
import javax.wsdl.extensions.*;
import javax.wsdl.extensions.soap.*;
import javax.wsdl.factory.*;
import javax.xml.namespace.*;
import junit.framework.*;

/**
 * This class implements a series of tests used to check
 * javax.wsdl.extensions.soap.SOAPAddress implementations
 * for compliance with the JWSDL specification.
 *
 * @author Matthew J. Duftler (duftler@us.ibm.com)
 */
public class SOAPAddressTest extends TestCase
{
  private static final String TEST_CANDIDATE_PROPERTY_NAME =
    "javax.wsdl.factory.WSDLFactoryCandidate";
  private static final String NS_URI_SOAP =
    "http://schemas.xmlsoap.org/wsdl/soap/";

  private WSDLFactory factory = null;
  private ExtensionRegistry extReg = null;
  private SOAPAddress soapAddress = null;

  protected void setUp() throws WSDLException, IOException
  {
    // Determine name of JWSDL factory implementation to test.
    String testCandidateName =
      System.getProperty(TEST_CANDIDATE_PROPERTY_NAME);

    if (testCandidateName == null)
    {
      throw new IllegalArgumentException("System property '" +
                                         TEST_CANDIDATE_PROPERTY_NAME +
                                         "' must be specified to run " +
                                         "test suite.");
    }

    factory = WSDLFactory.newInstance(testCandidateName);

    Assert.assertNotNull("WSDLFactory should not be null.", factory);

    extReg = factory.newPopulatedExtensionRegistry();

    Assert.assertNotNull("ExtensionRegistry should not be null.", extReg);

    QName soapAddressQName = new QName(NS_URI_SOAP, "address");

    soapAddress = (SOAPAddress)TCKUtils.createExtension(extReg,
                                                        Port.class,
                                                        soapAddressQName,
                                                        SOAPAddress.class);
  }

  /**
   * Test SOAPAddress.setLocationURI(...) and SOAPAddress.getLocationURI().
   */
  public void testSetGetLocationURI()
  {
    String locationURI = "urn:abcdef";

    soapAddress.setLocationURI(locationURI);

    String locationURI2 = soapAddress.getLocationURI();

    Assert.assertTrue("SOAPAddress.getLocationURI() did not return " +
                      "the same location URI that was set using " +
                      "SOAPAddress.setLocationURI(...).",
                      locationURI.equals(locationURI2));
  }
}