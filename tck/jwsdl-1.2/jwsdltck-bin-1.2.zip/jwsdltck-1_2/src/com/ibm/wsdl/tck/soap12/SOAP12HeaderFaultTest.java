/*
 * (c) Copyright IBM Corp 2006 
 */

package com.ibm.wsdl.tck.soap12;

import java.io.IOException;

import javax.wsdl.WSDLException;
import javax.wsdl.extensions.ExtensionRegistry;
import javax.wsdl.extensions.soap12.SOAP12Header;
import javax.wsdl.extensions.soap12.SOAP12HeaderFault;
import javax.wsdl.factory.WSDLFactory;
import javax.xml.namespace.QName;

import junit.framework.Assert;
import junit.framework.TestCase;

import com.ibm.wsdl.tck.util.TCKUtils;

/**
 * This class implements a series of tests used to check
 * javax.wsdl.extensions.soap12.SOAP12HeaderFault implementations
 * for compliance with the JWSDL specification.
 *
 * @author Matthew J. Duftler (duftler@us.ibm.com)
 */
public class SOAP12HeaderFaultTest extends TestCase
{
  private static final String TEST_CANDIDATE_PROPERTY_NAME =
    "javax.wsdl.factory.WSDLFactoryCandidate";
  private static final String NS_URI_SOAP12 =
    "http://schemas.xmlsoap.org/wsdl/soap12/";

  private WSDLFactory factory = null;
  private ExtensionRegistry extReg = null;
  private SOAP12HeaderFault soapHeaderFault = null;

  protected void setUp() throws WSDLException, IOException
  {
    // Determine name of JWSDL factory implementation to test.
    String testCandidateName =
      System.getProperty(TEST_CANDIDATE_PROPERTY_NAME);

    if (testCandidateName == null)
    {
      throw new IllegalArgumentException("System property '" +
                                         TEST_CANDIDATE_PROPERTY_NAME +
                                         "' must be specified to run " +
                                         "test suite.");
    }

    factory = WSDLFactory.newInstance(testCandidateName);

    Assert.assertNotNull("WSDLFactory should not be null.", factory);

    extReg = factory.newPopulatedExtensionRegistry();

    Assert.assertNotNull("ExtensionRegistry should not be null.", extReg);

    QName soapHeaderFaultQName = new QName(NS_URI_SOAP12, "headerfault");

    soapHeaderFault =
      (SOAP12HeaderFault)TCKUtils.createExtension(extReg,
                                                SOAP12Header.class,
                                                soapHeaderFaultQName,
                                                SOAP12HeaderFault.class);
  }

  /**
   * Test SOAP12HeaderFault.setEncodingStyle(...) and
   * SOAP12HeaderFault.getEncodingStyle().
   */
  public void testSetGetEncodingStyle()
  {
    String encodingStyle = "Style1";

    soapHeaderFault.setEncodingStyle(encodingStyle);

    String encodingStyle2 = soapHeaderFault.getEncodingStyle();

    Assert.assertTrue("SOAP12HeaderFault.getEncodingStyle() did not return " +
                      "the same list that was set using " +
                      "SOAP12HeaderFault.setEncodingStyle(...).",
                      encodingStyle.equals(encodingStyle2));
  }

  /**
   * Test SOAP12HeaderFault.setMessage(...) and SOAP12HeaderFault.getMessage().
   */
  public void testSetGetMessage()
  {
    QName message = new QName("urn:abc", "defghi");

    soapHeaderFault.setMessage(message);

    QName message2 = soapHeaderFault.getMessage();

    Assert.assertTrue("SOAP12HeaderFault.getMessage() did not return " +
                      "the same message that was set using " +
                      "SOAP12HeaderFault.setMessage(...).",
                      message.equals(message2));
  }

  /**
   * Test SOAP12HeaderFault.setNamespaceURI(...) and
   * SOAP12HeaderFault.getNamespaceURI().
   */
  public void testSetGetNamespaceURI()
  {
    String namespaceURI = "urn:abcdef";

    soapHeaderFault.setNamespaceURI(namespaceURI);

    String namespaceURI2 = soapHeaderFault.getNamespaceURI();

    Assert.assertTrue("SOAP12HeaderFault.getNamespaceURI() did not return " +
                      "the same namespace URI that was set using " +
                      "SOAP12HeaderFault.setNamespaceURI(...).",
                      namespaceURI.equals(namespaceURI2));
  }

  /**
   * Test SOAP12HeaderFault.setPart(...) and SOAP12HeaderFault.getPart().
   */
  public void testSetGetPart()
  {
    String part = "abcdef";

    soapHeaderFault.setPart(part);

    String part2 = soapHeaderFault.getPart();

    Assert.assertTrue("SOAP12HeaderFault.getPart() did not return " +
                      "the same part that was set using " +
                      "SOAP12HeaderFault.setPart(...).",
                      part.equals(part2));
  }

  /**
   * Test SOAP12HeaderFault.setUse(...) and SOAP12HeaderFault.getUse().
   */
  public void testSetGetUse()
  {
    String use = "encoded";

    soapHeaderFault.setUse(use);

    String use2 = soapHeaderFault.getUse();

    Assert.assertTrue("SOAP12HeaderFault.getUse() did not return " +
                      "the same use that was set using " +
                      "SOAP12HeaderFault.setUse(...).",
                      use.equals(use2));
  }
}