/*
 * (c) Copyright IBM Corp 2001, 2006 
 */

package com.ibm.wsdl.tck;

import com.ibm.wsdl.tck.util.*;
import java.io.*;
import javax.wsdl.*;
import javax.wsdl.extensions.*;
import javax.wsdl.factory.*;
import javax.wsdl.xml.*;
import javax.xml.parsers.*;
import junit.framework.*;
import org.w3c.dom.*;
import org.xml.sax.*;

/**
 * This class implements a series of tests used to check
 * javax.wsdl.xml.WSDLReader implementations for compliance
 * with the JWSDL specification.
 *
 * @author Matthew J. Duftler (duftler@us.ibm.com)
 */
public class WSDLReaderTest extends TestCase
{
  private static final String TEST_CANDIDATE_PROPERTY_NAME =
    "javax.wsdl.factory.WSDLFactoryCandidate";
  private static final String NS_URI_WSDL =
    "http://schemas.xmlsoap.org/wsdl/";

  private WSDLFactory factory = null;
  private WSDLReader wsdlReader = null;

  protected void setUp() throws WSDLException
  {
    // Determine name of JWSDL factory implementation to test.
    String testCandidateName =
      System.getProperty(TEST_CANDIDATE_PROPERTY_NAME);

    if (testCandidateName == null)
    {
      throw new IllegalArgumentException("System property '" +
                                         TEST_CANDIDATE_PROPERTY_NAME +
                                         "' must be specified to run " +
                                         "test suite.");
    }

    factory = WSDLFactory.newInstance(testCandidateName);

    Assert.assertNotNull("WSDLFactory should not be null.", factory);

    wsdlReader = factory.newWSDLReader();

    Assert.assertNotNull("WSDLReader should not be null.", wsdlReader);
  }

  /**
   * Test WSDLReader.setExtensionRegistry(...) and
   * WSDLReader.getExtensionRegistry().
   */
  public void testSetGetExtensionRegistry()
  {
    Assert.assertNull("The default value of " +
                      "WSDLReader.getExtensionRegistry() should be null.",
                      wsdlReader.getExtensionRegistry());

    ExtensionRegistry extReg = new ExtensionRegistry();

    wsdlReader.setExtensionRegistry(extReg);

    ExtensionRegistry extReg2 = wsdlReader.getExtensionRegistry();

    Assert.assertTrue("WSDLReader.getExtensionRegistry() did not return " +
                      "the same ExtensionRegistry that was set using " +
                      "WSDLReader.setExtensionRegistry(...).",
                      extReg == extReg2);
  }

  /**
   * Test WSDLReader.setFeature(...) and WSDLReader.getFeature(...). Test
   * for recognition of both specification-mandated features.
   */
  public void testSetGetFeature()
  {
    Assert.assertTrue("The default value of " +
                      "WSDLReader.getFeature(\"javax.wsdl.verbose\") " +
                      "should be true.",
                      wsdlReader.getFeature("javax.wsdl.verbose"));

    wsdlReader.setFeature("javax.wsdl.verbose", false);

    Assert.assertFalse("WSDLReader.getFeature(\"javax.wsdl.verbose\") " +
                       "did not return false, even though " +
                       "WSDLReader.setFeature(" +
                       "\"javax.wsdl.verbose\", false) was called.",
                       wsdlReader.getFeature("javax.wsdl.verbose"));

    Assert.assertTrue("The default value of " +
                      "WSDLReader.getFeature(" +
                      "\"javax.wsdl.importDocuments\") should be true.",
                      wsdlReader.getFeature("javax.wsdl.importDocuments"));

    wsdlReader.setFeature("javax.wsdl.importDocuments", false);

    Assert.assertFalse("WSDLReader.getFeature(" +
                       "\"javax.wsdl.importDocuments\") " +
                       "did not return false, even though " +
                       "WSDLReader.setFeature(" +
                       "\"javax.wsdl.importDocuments\", false) was called.",
                       wsdlReader.getFeature("javax.wsdl.importDocuments"));
  }

  /**
   * Test each variation of WSDLReader.readWSDL(...) to ensure that
   * definitions can be retrieved and parsed. Test navigating the
   * definition by starting with the port and walking all the way
   * back to the message parts. Test retrieving a document that contains
   * an &lt;import&gt;.
   */
  public void testReadWSDL() throws WSDLException,
                                    IOException,
                                    ParserConfigurationException,
                                    SAXException
  {
    String jwsdltck_home =
      System.getProperty("jwsdltck_home", System.getProperty("user.dir"));
    File dir = new File(jwsdltck_home, "resources");
    File file = new File(dir, "AddressBook.wsdl");
    String fileName = file.toString();
    File dir2 = new File(dir, "subdir");
    File file2 = new File(dir2, "AddressBook_2.wsdl");
    String fileNameWithImport = file2.toString();

    wsdlReader.setFeature("javax.wsdl.verbose", false);
    testReadWSDL1(fileName);

    setUp();
    testReadWSDL2(fileName);

    setUp();
    testReadWSDL3(fileName);

    setUp();
    testReadWSDL4(fileName);

    setUp();
    wsdlReader.setFeature("javax.wsdl.verbose", false);
    testReadWSDLWithImport(fileNameWithImport);
  }

  private void testReadWSDL1(String fileName) throws WSDLException
  {
    Definition definition = wsdlReader.readWSDL(fileName);

    Assert.assertNotNull("WSDLReader.readWSDL(\"" + fileName + "\") " +
                         "should not return null.",
                         definition);

    TCKUtils.walkDefinition(definition);
  }

  private void testReadWSDL2(String fileName) throws WSDLException, IOException
  {
    FileReader fileReader = new FileReader(fileName);
    InputSource inputSource = new InputSource(fileReader);
    Definition definition = wsdlReader.readWSDL(null, inputSource);

    Assert.assertNotNull("WSDLReader.readWSDL(null, " +
                         "new InputSource(" +
                         "new FileReader(\"" + fileName + "\"))) " +
                         "should not return null.",
                         definition);

    fileReader.close();

    TCKUtils.walkDefinition(definition);
  }

  private void testReadWSDL3(String fileName)
    throws WSDLException,
           IOException,
           ParserConfigurationException,
           SAXException
  {
    Document doc = TCKUtils.getDocument(fileName);
    Definition definition = wsdlReader.readWSDL(null, doc);

    Assert.assertNotNull("WSDLReader.readWSDL(null, Document) " +
                         "should not return null.",
                         definition);

    TCKUtils.walkDefinition(definition);
  }

  private void testReadWSDL4(String fileName)
    throws WSDLException,
           IOException,
           ParserConfigurationException,
           SAXException
  {
    Document doc = TCKUtils.getDocument(fileName);
    Element docEl = doc.getDocumentElement();
    Definition definition = wsdlReader.readWSDL((String) null, docEl);

    Assert.assertNotNull("WSDLReader.readWSDL(null, Element) " +
                         "should not return null.",
                         definition);

    TCKUtils.walkDefinition(definition);
  }

  private void testReadWSDLWithImport(String fileName) throws WSDLException
  {
    Definition definition = wsdlReader.readWSDL(fileName);

    Assert.assertNotNull("WSDLReader.readWSDL(\"" + fileName + "\") " +
                         "should not return null.",
                         definition);

    TCKUtils.walkDefinition(definition);
  }

  /** Added for the JWSDL 1.1 Maintenance Release.
   * 
   * Test that WSDLReader will correctly parse wsdl that has 
   * xml schema &lt;import&gt;, &lt;include&gt; and &lt;redefine&gt;
   * elements.
   * The schema fragments should be stored as DOM elements within
   * Schema objects linked together with SchemaReference objects
   * to mirror the nested schemas. Test navigating the
   * definition by starting with the top level schema and walking
   * all the way down the imported, included and redefined schemas.
   * 
   * @author John Kaputin
   * 
   */
  public void testReadWSDLwithSchemas() throws WSDLException,
                                               IOException,
                                               ParserConfigurationException,
                                               SAXException
  {
    String jwsdltck_home =
      System.getProperty("jwsdltck_home", System.getProperty("user.dir"));
    File dir = new File(jwsdltck_home, "resources");
    File dir2 = new File(dir, "schemas");
    File file = new File(dir2, "TravelCo.wsdl");
    String fileNameWithSchemas = file.toString();

    wsdlReader.setFeature("javax.wsdl.verbose", false);
    testReadWSDLWithSchemas1(fileNameWithSchemas);
  }

  private void testReadWSDLWithSchemas1(String fileName) throws WSDLException
  {
    Definition definition = wsdlReader.readWSDL(fileName);

    Assert.assertNotNull("WSDLReader.readWSDL(\"" + fileName + "\") " +
                         "should not return null.",
                         definition);

    TCKUtils.walkDefinitionWithSchemas(definition);
  }
}