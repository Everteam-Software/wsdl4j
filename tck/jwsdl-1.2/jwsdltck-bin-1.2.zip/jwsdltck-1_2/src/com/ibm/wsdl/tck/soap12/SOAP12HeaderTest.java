/*
 * (c) Copyright IBM Corp 2006 
 */

package com.ibm.wsdl.tck.soap12;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import javax.wsdl.BindingInput;
import javax.wsdl.WSDLException;
import javax.wsdl.extensions.ExtensionRegistry;
import javax.wsdl.extensions.soap12.SOAP12Header;
import javax.wsdl.extensions.soap12.SOAP12HeaderFault;
import javax.wsdl.factory.WSDLFactory;
import javax.xml.namespace.QName;

import junit.framework.Assert;
import junit.framework.TestCase;

import com.ibm.wsdl.tck.util.TCKUtils;

/**
 * This class implements a series of tests used to check
 * javax.wsdl.extensions.soap12.SOAP12Header implementations
 * for compliance with the JWSDL specification.
 *
 * @author Matthew J. Duftler (duftler@us.ibm.com)
 */
public class SOAP12HeaderTest extends TestCase
{
  private static final String TEST_CANDIDATE_PROPERTY_NAME =
    "javax.wsdl.factory.WSDLFactoryCandidate";
  private static final String NS_URI_SOAP12 =
    "http://schemas.xmlsoap.org/wsdl/soap12/";

  private WSDLFactory factory = null;
  private ExtensionRegistry extReg = null;
  private SOAP12Header soapHeader = null;

  protected void setUp() throws WSDLException, IOException
  {
    // Determine name of JWSDL factory implementation to test.
    String testCandidateName =
      System.getProperty(TEST_CANDIDATE_PROPERTY_NAME);

    if (testCandidateName == null)
    {
      throw new IllegalArgumentException("System property '" +
                                         TEST_CANDIDATE_PROPERTY_NAME +
                                         "' must be specified to run " +
                                         "test suite.");
    }

    factory = WSDLFactory.newInstance(testCandidateName);

    Assert.assertNotNull("WSDLFactory should not be null.", factory);

    extReg = factory.newPopulatedExtensionRegistry();

    Assert.assertNotNull("ExtensionRegistry should not be null.", extReg);

    QName soapHeaderQName = new QName(NS_URI_SOAP12, "header");

    soapHeader = (SOAP12Header)TCKUtils.createExtension(extReg,
                                                      BindingInput.class,
                                                      soapHeaderQName,
                                                      SOAP12Header.class);
  }

  /**
   * Test SOAP12Header.addSOAP12HeaderFault(...),
   * SOAP12Header.getSOAP12HeaderFaults() and
   * SOAP12Header.removeSOAP12HeaderFault(...)
   */
  public void testAddGetRemoveSOAP12HeaderFault()
  {
    QName soapHeaderFaultQName = new QName(NS_URI_SOAP12, "headerfault");
    SOAP12HeaderFault soapHeaderFault1 =
      (SOAP12HeaderFault)TCKUtils.createExtension(
        extReg,
        SOAP12Header.class,
        soapHeaderFaultQName,
        SOAP12HeaderFault.class);
    SOAP12HeaderFault soapHeaderFault2 =
      (SOAP12HeaderFault)TCKUtils.createExtension(
        extReg,
        SOAP12Header.class,
        soapHeaderFaultQName,
        SOAP12HeaderFault.class);
    SOAP12HeaderFault soapHeaderFault3 =
      (SOAP12HeaderFault)TCKUtils.createExtension(
        extReg,
        SOAP12Header.class,
        soapHeaderFaultQName,
        SOAP12HeaderFault.class);

    soapHeader.addSOAP12HeaderFault(soapHeaderFault2);
    soapHeader.addSOAP12HeaderFault(soapHeaderFault3);
    soapHeader.addSOAP12HeaderFault(soapHeaderFault1);

    List expectedParts = Arrays.asList(new Object[]{soapHeaderFault2,
                                                    soapHeaderFault3,
                                                    soapHeaderFault1});
    List actualParts = soapHeader.getSOAP12HeaderFaults();

    Assert.assertTrue("SOAP12Header.getSOAP12HeaderFaults() did not return " +
                      "the correct list of SOAP12HeaderFaults.",
                      expectedParts.equals(actualParts));
    
    SOAP12HeaderFault removedSoapHeaderFault1 = soapHeader.removeSOAP12HeaderFault(soapHeaderFault1);
    
    assertEquals("SOAP12Header.removeSOAP12HeaderFault(soapHeaderFault) did not return "+
                 "the correct SOAP12HeaderFault", removedSoapHeaderFault1, soapHeaderFault1);
    
    SOAP12HeaderFault removedSoapHeaderFault2 = soapHeader.removeSOAP12HeaderFault(soapHeaderFault2);
    
    assertEquals("SOAP12Header.removeSOAP12HeaderFault(soapHeaderFault) did not return "+
                 "the correct SOAP12HeaderFault", removedSoapHeaderFault2, soapHeaderFault2);
    
    SOAP12HeaderFault removedSoapHeaderFault3 = soapHeader.removeSOAP12HeaderFault(soapHeaderFault3);
    
    assertEquals("SOAP12Header.removeSOAP12HeaderFault(soapHeaderFault) did not return "+
                 "the correct SOAP12HeaderFault", removedSoapHeaderFault3, soapHeaderFault3);
    
    expectedParts =
      Arrays.asList(new Object[]{});
    actualParts = soapHeader.getSOAP12HeaderFaults();

    Assert.assertTrue("SOAP12Header.getSOAP12HeaderFaults() did not return " +
                      "the correct list of SOAP12HeaderFaults.",
                      expectedParts.equals(actualParts));
  }

  /**
   * Test SOAP12Header.setEncodingStyle(...) and SOAP12Header.getEncodingStyle().
   */
  public void testSetGetEncodingStyle()
  {
    String encodingStyle = "Style1";

    soapHeader.setEncodingStyle(encodingStyle);

    String encodingStyle2 = soapHeader.getEncodingStyle();

    Assert.assertTrue("SOAP12Header.getEncodingStyle() did not return " +
                      "the same list that was set using " +
                      "SOAP12Header.setEncodingStyle(...).",
                      encodingStyle == encodingStyle2);
  }

  /**
   * Test SOAP12Header.setMessage(...) and SOAP12Header.getMessage().
   */
  public void testSetGetMessage()
  {
    QName message = new QName("urn:abc", "defghi");

    soapHeader.setMessage(message);

    QName message2 = soapHeader.getMessage();

    Assert.assertTrue("SOAP12Header.getMessage() did not return " +
                      "the same message that was set using " +
                      "SOAP12Header.setMessage(...).",
                      message.equals(message2));
  }

  /**
   * Test SOAP12Header.setNamespaceURI(...) and SOAP12Header.getNamespaceURI().
   */
  public void testSetGetNamespaceURI()
  {
    String namespaceURI = "urn:abcdef";

    soapHeader.setNamespaceURI(namespaceURI);

    String namespaceURI2 = soapHeader.getNamespaceURI();

    Assert.assertTrue("SOAP12Header.getNamespaceURI() did not return " +
                      "the same namespace URI that was set using " +
                      "SOAP12Header.setNamespaceURI(...).",
                      namespaceURI.equals(namespaceURI2));
  }

  /**
   * Test SOAP12Header.setPart(...) and SOAP12Header.getPart().
   */
  public void testSetGetPart()
  {
    String part = "abcdef";

    soapHeader.setPart(part);

    String part2 = soapHeader.getPart();

    Assert.assertTrue("SOAP12Header.getPart() did not return " +
                      "the same part that was set using " +
                      "SOAP12Header.setPart(...).",
                      part.equals(part2));
  }

  /**
   * Test SOAP12Header.setUse(...) and SOAP12Header.getUse().
   */
  public void testSetGetUse()
  {
    String use = "encoded";

    soapHeader.setUse(use);

    String use2 = soapHeader.getUse();

    Assert.assertTrue("SOAP12Header.getUse() did not return " +
                      "the same use that was set using " +
                      "SOAP12Header.setUse(...).",
                      use.equals(use2));
  }
}