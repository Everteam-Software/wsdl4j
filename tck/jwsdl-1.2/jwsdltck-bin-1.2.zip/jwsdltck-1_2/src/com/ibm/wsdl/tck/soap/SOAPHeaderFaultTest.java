/*
 * (c) Copyright IBM Corp 2001, 2006 
 */

package com.ibm.wsdl.tck.soap;

import com.ibm.wsdl.tck.util.*;
import java.io.*;
import java.util.*;
import javax.wsdl.*;
import javax.wsdl.extensions.*;
import javax.wsdl.extensions.soap.*;
import javax.wsdl.factory.*;
import javax.xml.namespace.*;
import junit.framework.*;

/**
 * This class implements a series of tests used to check
 * javax.wsdl.extensions.soap.SOAPHeaderFault implementations
 * for compliance with the JWSDL specification.
 *
 * @author Matthew J. Duftler (duftler@us.ibm.com)
 */
public class SOAPHeaderFaultTest extends TestCase
{
  private static final String TEST_CANDIDATE_PROPERTY_NAME =
    "javax.wsdl.factory.WSDLFactoryCandidate";
  private static final String NS_URI_SOAP =
    "http://schemas.xmlsoap.org/wsdl/soap/";

  private WSDLFactory factory = null;
  private ExtensionRegistry extReg = null;
  private SOAPHeaderFault soapHeaderFault = null;

  protected void setUp() throws WSDLException, IOException
  {
    // Determine name of JWSDL factory implementation to test.
    String testCandidateName =
      System.getProperty(TEST_CANDIDATE_PROPERTY_NAME);

    if (testCandidateName == null)
    {
      throw new IllegalArgumentException("System property '" +
                                         TEST_CANDIDATE_PROPERTY_NAME +
                                         "' must be specified to run " +
                                         "test suite.");
    }

    factory = WSDLFactory.newInstance(testCandidateName);

    Assert.assertNotNull("WSDLFactory should not be null.", factory);

    extReg = factory.newPopulatedExtensionRegistry();

    Assert.assertNotNull("ExtensionRegistry should not be null.", extReg);

    QName soapHeaderFaultQName = new QName(NS_URI_SOAP, "headerfault");

    soapHeaderFault =
      (SOAPHeaderFault)TCKUtils.createExtension(extReg,
                                                SOAPHeader.class,
                                                soapHeaderFaultQName,
                                                SOAPHeaderFault.class);
  }

  /**
   * Test SOAPHeaderFault.setEncodingStyles(...) and
   * SOAPHeaderFault.getEncodingStyles().
   */
  public void testSetGetEncodingStyles()
  {
    List encodingStyles = new Vector();

    soapHeaderFault.setEncodingStyles(encodingStyles);

    List encodingStyles2 = soapHeaderFault.getEncodingStyles();

    Assert.assertTrue("SOAPHeaderFault.getEncodingStyles() did not return " +
                      "the same list that was set using " +
                      "SOAPHeaderFault.setEncodingStyles(...).",
                      encodingStyles == encodingStyles2);
  }

  /**
   * Test SOAPHeaderFault.setMessage(...) and SOAPHeaderFault.getMessage().
   */
  public void testSetGetMessage()
  {
    QName message = new QName("urn:abc", "defghi");

    soapHeaderFault.setMessage(message);

    QName message2 = soapHeaderFault.getMessage();

    Assert.assertTrue("SOAPHeaderFault.getMessage() did not return " +
                      "the same message that was set using " +
                      "SOAPHeaderFault.setMessage(...).",
                      message.equals(message2));
  }

  /**
   * Test SOAPHeaderFault.setNamespaceURI(...) and
   * SOAPHeaderFault.getNamespaceURI().
   */
  public void testSetGetNamespaceURI()
  {
    String namespaceURI = "urn:abcdef";

    soapHeaderFault.setNamespaceURI(namespaceURI);

    String namespaceURI2 = soapHeaderFault.getNamespaceURI();

    Assert.assertTrue("SOAPHeaderFault.getNamespaceURI() did not return " +
                      "the same namespace URI that was set using " +
                      "SOAPHeaderFault.setNamespaceURI(...).",
                      namespaceURI.equals(namespaceURI2));
  }

  /**
   * Test SOAPHeaderFault.setPart(...) and SOAPHeaderFault.getPart().
   */
  public void testSetGetPart()
  {
    String part = "abcdef";

    soapHeaderFault.setPart(part);

    String part2 = soapHeaderFault.getPart();

    Assert.assertTrue("SOAPHeaderFault.getPart() did not return " +
                      "the same part that was set using " +
                      "SOAPHeaderFault.setPart(...).",
                      part.equals(part2));
  }

  /**
   * Test SOAPHeaderFault.setUse(...) and SOAPHeaderFault.getUse().
   */
  public void testSetGetUse()
  {
    String use = "encoded";

    soapHeaderFault.setUse(use);

    String use2 = soapHeaderFault.getUse();

    Assert.assertTrue("SOAPHeaderFault.getUse() did not return " +
                      "the same use that was set using " +
                      "SOAPHeaderFault.setUse(...).",
                      use.equals(use2));
  }
}