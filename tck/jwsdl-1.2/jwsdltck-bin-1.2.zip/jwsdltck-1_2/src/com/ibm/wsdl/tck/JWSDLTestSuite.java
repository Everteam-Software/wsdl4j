/*
 * (c) Copyright IBM Corp 2001, 2006 
 */

package com.ibm.wsdl.tck;

import com.ibm.wsdl.tck.http.*;
import com.ibm.wsdl.tck.mime.*;
import com.ibm.wsdl.tck.soap.*;
import com.ibm.wsdl.tck.soap12.SOAP12AddressTest;
import com.ibm.wsdl.tck.soap12.SOAP12BindingTest;
import com.ibm.wsdl.tck.soap12.SOAP12BodyTest;
import com.ibm.wsdl.tck.soap12.SOAP12FaultTest;
import com.ibm.wsdl.tck.soap12.SOAP12HeaderFaultTest;
import com.ibm.wsdl.tck.soap12.SOAP12HeaderTest;
import com.ibm.wsdl.tck.soap12.SOAP12OperationTest;
import com.ibm.wsdl.tck.schema.*;
import com.ibm.wsdl.tck.BindingFaultTest;
import com.ibm.wsdl.tck.BindingInputTest;
import com.ibm.wsdl.tck.BindingOperationTest;
import com.ibm.wsdl.tck.BindingOutputTest;
import com.ibm.wsdl.tck.BindingTest;
import com.ibm.wsdl.tck.DefinitionTest;
import com.ibm.wsdl.tck.ExtensionRegistryTest;
import com.ibm.wsdl.tck.FactoryTest;
import com.ibm.wsdl.tck.FactoryTest2;
import com.ibm.wsdl.tck.FaultTest;
import com.ibm.wsdl.tck.ImportTest;
import com.ibm.wsdl.tck.InputTest;
import com.ibm.wsdl.tck.MessageTest;
import com.ibm.wsdl.tck.OperationTest;
import com.ibm.wsdl.tck.OutputTest;
import com.ibm.wsdl.tck.PartTest;
import com.ibm.wsdl.tck.PortTest;
import com.ibm.wsdl.tck.PortTypeTest;
import com.ibm.wsdl.tck.ServiceTest;
import com.ibm.wsdl.tck.TypesTest;
import com.ibm.wsdl.tck.WSDLExceptionTest;
import com.ibm.wsdl.tck.WSDLWriterTest;

import junit.framework.*;
import junit.textui.*;

/**
 * This class combines all the tests contained in the JWSDL TCK
 * into one JUnit test suite.
 *
 * @author Matthew J. Duftler (duftler@us.ibm.com)
 */
public class JWSDLTestSuite extends TestCase
{
  public static Test suite()
  {
    TestSuite testSuite = new TestSuite();

    testSuite.addTestSuite(SignatureTest.class);
    testSuite.addTestSuite(FactoryTest.class);
    testSuite.addTestSuite(FactoryTest2.class);
    testSuite.addTestSuite(DefinitionTest.class);
    testSuite.addTestSuite(ExtensionRegistryTest.class);
    testSuite.addTestSuite(BindingTest.class);
    testSuite.addTestSuite(BindingFaultTest.class);
    testSuite.addTestSuite(BindingInputTest.class);
    testSuite.addTestSuite(BindingOperationTest.class);
    testSuite.addTestSuite(BindingOutputTest.class);
    testSuite.addTestSuite(FaultTest.class);
    testSuite.addTestSuite(ImportTest.class);
    testSuite.addTestSuite(InputTest.class);
    testSuite.addTestSuite(MessageTest.class);
    testSuite.addTestSuite(OperationTest.class);
    testSuite.addTestSuite(OutputTest.class);
    testSuite.addTestSuite(PartTest.class);
    testSuite.addTestSuite(PortTest.class);
    testSuite.addTestSuite(PortTypeTest.class);
    testSuite.addTestSuite(ServiceTest.class);
    testSuite.addTestSuite(TypesTest.class);
    testSuite.addTestSuite(WSDLExceptionTest.class);
    testSuite.addTestSuite(WSDLReaderTest.class);
    testSuite.addTestSuite(WSDLWriterTest.class);
    testSuite.addTestSuite(HTTPAddressTest.class);
    testSuite.addTestSuite(HTTPBindingTest.class);
    testSuite.addTestSuite(HTTPOperationTest.class);
    testSuite.addTestSuite(MIMEContentTest.class);
    testSuite.addTestSuite(MIMEMimeXmlTest.class);
    testSuite.addTestSuite(MIMEMultipartRelatedTest.class);
    testSuite.addTestSuite(SOAPAddressTest.class);
    testSuite.addTestSuite(SOAPBindingTest.class);
    testSuite.addTestSuite(SOAPBodyTest.class);
    testSuite.addTestSuite(SOAPFaultTest.class);
    testSuite.addTestSuite(SOAPHeaderTest.class);
    testSuite.addTestSuite(SOAPHeaderFaultTest.class);
    testSuite.addTestSuite(SOAPOperationTest.class);
    testSuite.addTestSuite(SOAP12AddressTest.class);
    testSuite.addTestSuite(SOAP12BindingTest.class);
    testSuite.addTestSuite(SOAP12BodyTest.class);
    testSuite.addTestSuite(SOAP12FaultTest.class);
    testSuite.addTestSuite(SOAP12HeaderTest.class);
    testSuite.addTestSuite(SOAP12HeaderFaultTest.class);
    testSuite.addTestSuite(SOAP12OperationTest.class);
    testSuite.addTestSuite(SchemaTest.class);
    testSuite.addTestSuite(SchemaReferenceTest.class);
    testSuite.addTestSuite(SchemaImportTest.class);

    return testSuite;
  }

  public static void main(String[] argv)
  {
    TestResult testResult = new TestResult();
    TestSuite suite1 = new TestSuite(FactoryTest.class);

    suite1.run(testResult);

    if (testResult.errorCount() > 0)
    {
      TestFailure testFailure =
        (TestFailure)testResult.errors().nextElement();

      System.err.println("Error: " + testFailure.failedTest() + ": " +
                         testFailure.thrownException());
    }
    else if (testResult.failureCount() > 0)
    {
      TestFailure testFailure =
        (TestFailure)testResult.failures().nextElement();

      System.err.println("Failure: " + testResult.failures().nextElement());
    }
    else
    {
      TestRunner.run(suite());
    }
  }
}