/*
 * (c) Copyright IBM Corp 2005 
 */

package com.ibm.wsdl.tck.schema;

import com.ibm.wsdl.tck.util.*;
import java.io.*;
import javax.wsdl.*;
import javax.wsdl.extensions.*;
import javax.wsdl.extensions.schema.*;
import javax.wsdl.factory.*;
import javax.xml.namespace.*;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import junit.framework.*;

/**
 * This class implements a series of tests used to check
 * javax.wsdl.extensions.schema.Schema implementations
 * for compliance with the JWSDL specification.
 *
 * @author John Kaputin (kaputin@uk.ibm.com)
 */
public class SchemaTest extends TestCase
{
  private static final String TEST_CANDIDATE_PROPERTY_NAME =
    "javax.wsdl.factory.WSDLFactoryCandidate";
  private static final String NS_URI_XSD_2001 =
      "http://www.w3.org/2001/XMLSchema";

  private WSDLFactory factory = null;
  private ExtensionRegistry extReg = null;
  private Schema schema = null;

  protected void setUp() throws WSDLException, IOException
  {
    // Determine name of JWSDL factory implementation to test.
    String testCandidateName =
      System.getProperty(TEST_CANDIDATE_PROPERTY_NAME);

    if (testCandidateName == null)
    {
      throw new IllegalArgumentException("System property '" +
                                         TEST_CANDIDATE_PROPERTY_NAME +
                                         "' must be specified to run " +
                                         "test suite.");
    }

    factory = WSDLFactory.newInstance(testCandidateName);

    Assert.assertNotNull("WSDLFactory should not be null.", factory);

    extReg = factory.newPopulatedExtensionRegistry();

    Assert.assertNotNull("ExtensionRegistry should not be null.", extReg);

    QName schemaQName = new QName(NS_URI_XSD_2001, "schema");

    schema = (Schema)TCKUtils.createExtension(extReg,
                                              Types.class,
                                              schemaQName,
                                              Schema.class);
  }

  /**
   * Test Schema.setDocumentBaseURI(...) and Schema.getDocumentBaseURI().
   */
  public void testSetGetDocumentBaseURI()
  {
    String locationURI = "urn:abcdef";

    schema.setDocumentBaseURI(locationURI);

    String locationURI2 = schema.getDocumentBaseURI();

    Assert.assertTrue("Schema.getDocumentBaseURI() did not return " +
                      "the same URI that was set using " +
                      "Schema.setDocumentBaseURI(...).",
                      locationURI.equals(locationURI2));
  }

  /**
   * Test Schema.setElement(...) and Schema.getElement().
   */
  public void testSetGetElement() throws WSDLException
  {
    //First, get a DOM Document to create an Element from.
      
    Document doc = null;
    DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
    factory.setNamespaceAware(true);
    factory.setValidating(false);
    try
    {
      DocumentBuilder builder = factory.newDocumentBuilder();
      doc = builder.newDocument();
    }
    catch (Throwable t)
    {
      throw new WSDLException(WSDLException.PARSER_ERROR,
                              "Problem creating an empty Document.",
                              t);
    }
    
    //Then create a dummy element and set/get it on the Schema
    
    Element el = doc.createElement("dummyElement");

    schema.setElement(el);

    Element el2 = schema.getElement();

    Assert.assertTrue("Schema.getElement() did not return " +
                      "the same Element that was set using " +
                      "Schema.setElement(...).",
                      el.equals(el2));
  }

  /**
   * Test Schema.createImport(), Schema.addImport(...) and Schema.getImports().
   */
  public void testCreateAddGetImport() throws WSDLException
  {
    SchemaImport si = schema.createImport();
    schema.addImport(si);
    int size = (schema.getImports()).size();
    
    Assert.assertTrue("Schema.getImports() did not return " +
                      "the same number of SchemaImport objects that were " +
                      "created with Schema.createImport() and " +
                      "added with Schema.addImport(...).",
                      size == 1);
  }
  
  /**
   * Test Schema.createInclude(), Schema.addInclude(...) and Schema.getIncludes().
   */
  public void testCreateAddGetInclude() throws WSDLException
  {
    SchemaReference sr = schema.createInclude();
    schema.addInclude(sr);
    int size = (schema.getIncludes()).size();
    
    Assert.assertTrue("Schema.getIncludes() did not return " +
                      "the same number of SchemaReference objects that were " +
                      "created with Schema.createInclude() and " +
                      "added with Schema.addInclude(...).",
                      size == 1);
  }

  /**
   * Test Schema.createRedefine(), Schema.addRedefine(...) and Schema.getRedefines().
   */
  public void testCreateAddGetRedefine() throws WSDLException
  {
    SchemaReference sr = schema.createRedefine();
    schema.addRedefine(sr);
    int size = (schema.getRedefines()).size();
    
    Assert.assertTrue("Schema.getRedefines() did not return " +
                      "the same number of SchemaReference objects that were " +
                      "created with Schema.createRedefine() and " +
                      "added with Schema.addRedefine(...).",
                      size == 1);
  }
  
}
