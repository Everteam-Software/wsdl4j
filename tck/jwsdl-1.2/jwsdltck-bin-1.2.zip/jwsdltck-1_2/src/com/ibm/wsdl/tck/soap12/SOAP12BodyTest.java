/*
 * (c) Copyright IBM Corp 2006 
 */

package com.ibm.wsdl.tck.soap12;

import java.io.IOException;
import java.util.List;
import java.util.Vector;

import javax.wsdl.BindingInput;
import javax.wsdl.WSDLException;
import javax.wsdl.extensions.ExtensionRegistry;
import javax.wsdl.extensions.soap12.SOAP12Body;
import javax.wsdl.factory.WSDLFactory;
import javax.xml.namespace.QName;

import junit.framework.Assert;
import junit.framework.TestCase;

import com.ibm.wsdl.tck.util.TCKUtils;

/**
 * This class implements a series of tests used to check
 * javax.wsdl.extensions.soap.SOAP12Body implementations
 * for compliance with the JWSDL specification.
 *
 * @author Matthew J. Duftler (duftler@us.ibm.com)
 */
public class SOAP12BodyTest extends TestCase
{
  private static final String TEST_CANDIDATE_PROPERTY_NAME =
    "javax.wsdl.factory.WSDLFactoryCandidate";
  private static final String NS_URI_SOAP12 =
    "http://schemas.xmlsoap.org/wsdl/soap12/";

  private WSDLFactory factory = null;
  private ExtensionRegistry extReg = null;
  private SOAP12Body soapBody = null;

  protected void setUp() throws WSDLException, IOException
  {
    // Determine name of JWSDL factory implementation to test.
    String testCandidateName =
      System.getProperty(TEST_CANDIDATE_PROPERTY_NAME);

    if (testCandidateName == null)
    {
      throw new IllegalArgumentException("System property '" +
                                         TEST_CANDIDATE_PROPERTY_NAME +
                                         "' must be specified to run " +
                                         "test suite.");
    }

    factory = WSDLFactory.newInstance(testCandidateName);

    Assert.assertNotNull("WSDLFactory should not be null.", factory);

    extReg = factory.newPopulatedExtensionRegistry();

    Assert.assertNotNull("ExtensionRegistry should not be null.", extReg);

    QName soapBodyQName = new QName(NS_URI_SOAP12, "body");

    soapBody = (SOAP12Body)TCKUtils.createExtension(extReg,
                                                  BindingInput.class,
                                                  soapBodyQName,
                                                  SOAP12Body.class);
  }

  /**
   * Test SOAP12Body.setEncodingStyle(...) and SOAP12Body.getEncodingStyle().
   */
  public void testSetGetEncodingStyle()
  {
    String encodingStyle = "Style1";

    soapBody.setEncodingStyle(encodingStyle);

    String encodingStyle2 = soapBody.getEncodingStyle();

    Assert.assertTrue("SOAP12Body.getEncodingStyle() did not return " +
                      "the same style that was set using " +
                      "SOAP12Body.setEncodingStyle(...).",
                      encodingStyle.equals(encodingStyle2));
  }

  /**
   * Test SOAP12Body.setNamespaceURI(...) and SOAP12Body.getNamespaceURI().
   */
  public void testSetGetNamespaceURI()
  {
    String namespaceURI = "urn:abcdef";

    soapBody.setNamespaceURI(namespaceURI);

    String namespaceURI2 = soapBody.getNamespaceURI();

    Assert.assertTrue("SOAP12Body.getNamespaceURI() did not return " +
                      "the same namespace URI that was set using " +
                      "SOAP12Body.setNamespaceURI(...).",
                      namespaceURI.equals(namespaceURI2));
  }

  /**
   * Test SOAP12Body.setParts(...) and SOAP12Body.getParts().
   */
  public void testSetGetParts()
  {
    List parts = new Vector();

    soapBody.setParts(parts);

    List parts2 = soapBody.getParts();

    Assert.assertTrue("SOAP12Body.getParts() did not return " +
                      "the same list that was set using " +
                      "SOAP12Body.setParts(...).",
                      parts == parts2);
  }

  /**
   * Test SOAP12Body.setUse(...) and SOAP12Body.getUse().
   */
  public void testSetGetUse()
  {
    String use = "encoded";

    soapBody.setUse(use);

    String use2 = soapBody.getUse();

    Assert.assertTrue("SOAP12Body.getUse() did not return " +
                      "the same use that was set using " +
                      "SOAP12Body.setUse(...).",
                      use.equals(use2));
  }
}