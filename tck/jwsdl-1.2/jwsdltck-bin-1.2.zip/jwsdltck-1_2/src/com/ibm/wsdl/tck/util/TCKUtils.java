/*
 * (c) Copyright IBM Corp 2001, 2005 
 */

package com.ibm.wsdl.tck.util;

import java.io.*;
import java.util.*;
import javax.wsdl.*;
import javax.wsdl.extensions.*;
import javax.wsdl.extensions.soap.*;
import javax.wsdl.extensions.schema.*;
import javax.xml.namespace.*;
import javax.xml.parsers.*;
import junit.framework.*;
import org.w3c.dom.*;
import org.xml.sax.*;

/**
 * This class implements static utility methods for use by the various
 * TCK tests.
 *
 * @author Matthew J. Duftler (duftler@us.ibm.com)
 */
public class TCKUtils
{
  public static void walkDefinition(Definition definition) throws WSDLException
  {
    String targetNamespace = "http://www.ibm.com/namespace/wsif/samples/ab";

    Assert.assertTrue("Definition.getTargetNamespace() did not return '" +
                      targetNamespace + "'.",
                      targetNamespace.equals(definition.getTargetNamespace()));

    Service service = definition.getService(new QName(targetNamespace,
                                                      "AddressBookService"));

    Assert.assertNotNull("Definition.getService(new QName(\"" +
                         targetNamespace + "\", \"AddressBookService\")) " +
                         "should not return null.",
                         service);

    Port port = service.getPort("SOAPPort");

    Assert.assertNotNull("Service.getPort(\"SOAPPort\") should not " +
                         "return null.",
                         port);

    SOAPAddress soapAddress =
      (SOAPAddress)checkExtensibilityElements(
        "Port",
        port.getExtensibilityElements());
    Binding binding = port.getBinding();

    Assert.assertNotNull("Port.getBinding() should not return null.",
                         binding);

    Assert.assertFalse("Binding.isUndefined() should return false.",
                       binding.isUndefined());

    Binding binding2 = definition.getBinding(new QName(targetNamespace,
                                                       "SOAPBinding"));

    Assert.assertTrue("Definition.getBinding(new QName(\"" +
                      targetNamespace + "\", \"SOAPBinding\")) did not " +
                      "return the same binding as port.getBinding().",
                      binding == binding2);

    SOAPBinding soapBinding =
      (SOAPBinding)checkExtensibilityElements(
        "Binding",
        binding.getExtensibilityElements());
    BindingOperation bindingOperation =
      binding.getBindingOperation("addEntry", null, null);

    Assert.assertNotNull("Binding.getBindingOperation(\"addEntry\", " +
                         "null, null) should not return null.",
                         bindingOperation);

    SOAPOperation soapOperation =
      (SOAPOperation)checkExtensibilityElements(
        "BindingOperation",
        bindingOperation.getExtensibilityElements());

    BindingInput bindingInput = bindingOperation.getBindingInput();

    Assert.assertNotNull("BindingOperation.getBindingInput() should not " +
                         "return null.",
                         bindingInput);

    SOAPBody soapBody =
      (SOAPBody)checkExtensibilityElements(
        "BindingInput",
        bindingInput.getExtensibilityElements());

    BindingOutput bindingOutput = bindingOperation.getBindingOutput();

    Assert.assertNotNull("BindingOperation.getBindingOutput() should not " +
                         "return null.",
                         bindingOutput);

    soapBody =
      (SOAPBody)checkExtensibilityElements(
        "BindingOutput",
        bindingOutput.getExtensibilityElements());

    BindingOperation bindingOperation2 =
      binding.getBindingOperation("getAddressFromName", null, null);

    Assert.assertNotNull("Binding.getBindingOperation(" +
                         "\"getAddressFromName\", null, null) " +
                         "should not return null.",
                         bindingOperation2);

    SOAPOperation soapOperation2 =
      (SOAPOperation)checkExtensibilityElements(
        "BindingOperation",
        bindingOperation2.getExtensibilityElements());

    BindingInput bindingInput2 = bindingOperation2.getBindingInput();

    Assert.assertNotNull("BindingOperation.getBindingInput() should not " +
                         "return null.",
                         bindingInput2);

    SOAPBody soapBody2 =
      (SOAPBody)checkExtensibilityElements(
        "BindingInput",
        bindingInput2.getExtensibilityElements());

    BindingOutput bindingOutput2 = bindingOperation2.getBindingOutput();

    Assert.assertNotNull("BindingOperation.getBindingOutput() should not " +
                         "return null.",
                         bindingOutput2);

    soapBody2 =
      (SOAPBody)checkExtensibilityElements(
        "BindingOutput",
        bindingOutput2.getExtensibilityElements());

    PortType portType = binding.getPortType();

    Assert.assertNotNull("Binding.getPortType() should not return null.",
                         portType);

    Assert.assertFalse("PortType.isUndefined() should return false.",
                       portType.isUndefined());

    PortType portType2 = definition.getPortType(new QName(targetNamespace,
                                                          "AddressBook"));

    Assert.assertTrue("Definition.getPortType(new QName(\"" +
                      targetNamespace + "\", \"AddressBook\")) did not " +
                      "return the same portType as binding.getPortType().",
                      portType == portType2);

    Operation operation = portType.getOperation("addEntry", null, null);

    Assert.assertNotNull("PortType.getOperation(\"addEntry\", null, null) " +
                         "should not return null.",
                         operation);

    Assert.assertFalse("Operation.isUndefined() should return false.",
                       operation.isUndefined());

    Assert.assertTrue("PortType.getOperation(\"addEntry\", null, null) " +
                      "did not return the same operation as " +
                      "bindingOperation.getOperation().",
                      operation == bindingOperation.getOperation());

    OperationType style = operation.getStyle();

    Assert.assertTrue("Operation.getStyle() did not return " +
                      "OperationType.REQUEST_RESPONSE.",
                      style == OperationType.REQUEST_RESPONSE);

    Input input = operation.getInput();

    Assert.assertNotNull("Operation.getInput() should not return null.",
                         input);

    Message message = input.getMessage();

    Assert.assertNotNull("Input.getMessage() should not return null.",
                         message);

    Assert.assertFalse("Message.isUndefined() should return false.",
                       message.isUndefined());

    Message message2 = definition.getMessage(new QName(targetNamespace,
                                                       "AddEntryRequest"));

    Assert.assertTrue("Definition.getMessage(new QName(\"" +
                      targetNamespace + "\", \"AddEntryRequest\")) did not " +
                      "return the same message as input.getMessage().",
                      message == message2);

    Part part = message.getPart("name");

    Assert.assertNotNull("Message.getPart(\"name\") should not return null.",
                         part);

    part = message.getPart("address");

    Assert.assertNotNull("Message.getPart(\"address\") should not return " +
                         "null.",
                         part);

    Output output = operation.getOutput();

    Assert.assertNotNull("Operation.getOutput() should not return null.",
                         output);

    message = output.getMessage();

    Assert.assertNotNull("Output.getMessage() should not return null.",
                         message);

    Assert.assertFalse("Message.isUndefined() should return false.",
                       message.isUndefined());

    message2 = definition.getMessage(new QName(targetNamespace,
                                               "AddEntryResponse"));

    Assert.assertTrue("Definition.getMessage(new QName(\"" +
                      targetNamespace + "\", \"AddEntryResponse\")) did not " +
                      "return the same message as output.getMessage().",
                      message == message2);

    Operation operation2 = portType.getOperation("getAddressFromName",
                                                 null,
                                                 null);

    Assert.assertNotNull("PortType.getOperation(\"getAddressFromName\", " +
                         "null, null) should not return null.",
                         operation2);

    Assert.assertFalse("Operation.isUndefined() should return false.",
                       operation2.isUndefined());

    Assert.assertTrue("PortType.getOperation(\"getAddressFromName\", " +
                      "null, null) did not return the same operation as " +
                      "bindingOperation.getOperation().",
                      operation2 == bindingOperation2.getOperation());

    OperationType style2 = operation2.getStyle();

    Assert.assertTrue("Operation.getStyle() did not return " +
                      "OperationType.REQUEST_RESPONSE.",
                      style2 == OperationType.REQUEST_RESPONSE);

    Input input2 = operation2.getInput();

    Assert.assertNotNull("Operation.getInput() should not return null.",
                         input2);

    message = input2.getMessage();

    Assert.assertNotNull("Input.getMessage() should not return null.",
                         message);

    Assert.assertFalse("Message.isUndefined() should return false.",
                       message.isUndefined());

    message2 = definition.getMessage(new QName(targetNamespace,
                                               "GetAddressFromNameRequest"));

    Assert.assertTrue("Definition.getMessage(new QName(\"" + targetNamespace +
                      "\", \"GetAddressFromNameRequest\")) did not " +
                      "return the same message as input.getMessage().",
                      message == message2);

    part = message.getPart("name");

    Assert.assertNotNull("Message.getPart(\"name\") should not return null.",
                         part);

    Output output2 = operation2.getOutput();

    Assert.assertNotNull("Operation.getOutput() should not return null.",
                         output2);

    message = output2.getMessage();

    Assert.assertNotNull("Output.getMessage() should not return null.",
                         message);

    Assert.assertFalse("Message.isUndefined() should return false.",
                       message.isUndefined());

    message2 = definition.getMessage(new QName(targetNamespace,
                                               "GetAddressFromNameResponse"));

    Assert.assertTrue("Definition.getMessage(new QName(\"" +
                      targetNamespace + "\", \"GetAddressFromNameResponse\")) did not " +
                      "return the same message as output.getMessage().",
                      message == message2);

    part = message.getPart("address");

    Assert.assertNotNull("Message.getPart(\"address\") should not return " +
                         "null.",
                         part);

    Types types = definition.getTypes();

    if (types == null)
    {
      List imports = definition.getImports(targetNamespace);

      if (imports != null && imports.size() == 1)
      {
        Import theImport = (Import)imports.get(0);

        Assert.assertNotNull("imports.get(0) should not return null.",
                             theImport);

        Definition importedDef = theImport.getDefinition();

        Assert.assertNotNull("theImport.getDefinition() should not return " +
                             "null.",
                             importedDef);

        types = importedDef.getTypes();

        Assert.assertNotNull("importedDefinition.getTypes() should not " +
                             "return null.",
                             types);
      }
    }

    Assert.assertNotNull("Definition.getTypes() should not return null.",
                         types);

    ExtensibilityElement extElement =
      checkExtensibilityElements("Types", types.getExtensibilityElements());
    QName schemaQName = new QName("http://www.w3.org/2001/XMLSchema",
                                  "schema");

    Assert.assertTrue("The extensibility element contained within the " +
                      "types should return '" + schemaQName + "' when " +
                      "ExtensibilityElement.getElementType() is called.",
                      schemaQName.equals(extElement.getElementType()));

    if (extElement instanceof UnknownExtensibilityElement)
    {
      UnknownExtensibilityElement unkExtElment =
        (UnknownExtensibilityElement)extElement;
      Element schemaEl = unkExtElment.getElement();

      Assert.assertNotNull("UnknownExtensibilityElement.getElement() should " +
                           "not return null.",
                           schemaEl);

      QName schemaQName2 = new QName(schemaEl.getNamespaceURI(),
                                     schemaEl.getLocalName());
      Assert.assertTrue("The unknown extensibility element contained within " +
                        "the types should return a '" + schemaQName +
                        "' Element when " +
                        "UnknownExtensibilityElement.getElement() is called.",
                        schemaQName.equals(schemaQName2));
    }
  }
  
  /******************************************************************************
   * Added for the JWSDL 1.1 Maintenance Release.
   * This method walks a wsdl definition that includes nested xml schemas to
   * verify that the schema nesting is represented correctly in the object graph.
   * The numbering used to represent the schema nesting is as follows:
   * 
   *                  Top-level, inline <schema> within TravelCo.wsdl
   *                                    "schema1"
   *                                       �
   *                                       �
   *         ------------------------------------------------------
   *         �                         �                          �
   *         �                         �                          �
   *      <import>Flight.xsd       <include>Hotel.xsd       <redefine>Address.xsd 
   *      "schema11"               "schema12"               "schema13"
   *         �                        �
   *         �                        �
   *      <include>Address.xsd     <import>Address.xsd
   *      "schema111"              "schema121"
   *  
   * Note: In the case where a schema does not contain any further nested schemas
   * JWSDL does not specify whether the getImports(), getIncludes() or 
   * getRedefines() methods should return null or an empty set, so we should 
   * allow for both in these tests.
   * 
   * @author John Kaputin
   * 
   *****************************************************************************/
  public static void walkDefinitionWithSchemas(Definition definition) throws WSDLException
  {
    int actualSize = 0;
    Element domEl = null;
    String actualNS, actualLoc = null;
    String importNS, importLoc, includeLoc, redefineLoc = null;
    Map schemaImportsMap = null;
    List schemaImports, schemaIncludes, schemaRedefines = null;
    
    /************************************************************
     * Check that <types> contains the top level, inline <schema>
     ************************************************************/
    
    Types types = definition.getTypes();
 
    Assert.assertNotNull("Definition.getTypes() " +
            "should not return null.",
            types);

    Schema schema1 = (Schema) checkExtensibilityElements(
                                "Types", 
                                types.getExtensibilityElements());
    
    /************************************************************
     * Check that the top level schema imports one schema,
     * which in turn includes one schema.
     * 
     * schema1 <import> schema11 <include> schema111
     ************************************************************/

    //check that the schema DOM element is present
    domEl = schema1.getElement();
    Assert.assertNotNull("schema1.getElement() " +
            "should not return null.",
            domEl);
    
    schemaImportsMap = schema1.getImports();
    Assert.assertNotNull("schema1.getImports() " +
            "should not return null.",
            schemaImportsMap);
    
    actualSize = schemaImportsMap.size();
    Assert.assertTrue("schema1.getImports() " +
            "returned a map containing " + actualSize +
            " items, instead of 1.",
            actualSize == 1);
    
    importNS = "http://travelco.com/schema/Flight";
    schemaImports = (List) schemaImportsMap.get(importNS);
    SchemaImport schemaImport11 = (SchemaImport) schemaImports.iterator().next();
    
    actualNS = schemaImport11.getNamespaceURI();
    Assert.assertTrue("schemaImport11.getNamespaceURI() " +
            "returned " + actualNS +
            " instead of " + importNS + ".",
            importNS.equals(actualNS));
    
    importLoc = "Flight.xsd";
    actualLoc = schemaImport11.getSchemaLocationURI();
    Assert.assertTrue("schemaImport11.getSchemaLocationURI() " +
            "returned " + actualLoc +
            " instead of " + importLoc + ".",
            importLoc.equals(actualLoc));
    
    Schema schema11 = schemaImport11.getReferencedSchema();
    Assert.assertNotNull("schemaImport11.getReferencedSchema() " +
            "should not return null.",
            schema11);

    //check that the schema DOM element is present
    domEl = schema11.getElement();
    Assert.assertNotNull("schema11.getElement() " +
            "should not return null.",
            domEl);
    
    //The imported schema should not import any further schemas.
    schemaImportsMap = schema11.getImports();
    if(schemaImportsMap != null) {
        actualSize = schemaImportsMap.size();
        Assert.assertTrue("schema11.getImports() " +
                "returned a map containing " + actualSize +
                " items, instead of 0.",
                actualSize == 0);
    }

    //The imported schema should not redefine any further schemas.
    schemaRedefines = schema11.getRedefines();
    if(schemaRedefines != null) {
        actualSize = schemaRedefines.size();
        Assert.assertTrue("schema11.getRedefines() " +
                "returned a list containing " + actualSize +
                " items, instead of 0.",
                actualSize == 0);
    }

    //The imported schema should include one schema.
    schemaIncludes = schema11.getIncludes();
    Assert.assertNotNull("schema11.getIncludes() " +
            "should not return null.",
            schemaIncludes);

    actualSize = schemaIncludes.size();
    Assert.assertTrue("schema11.getIncludes() " +
            "returned a list containing " + actualSize +
            " items, instead of 1.",
            actualSize == 1);
    
    SchemaReference schemaRef111 = 
        (SchemaReference) schemaIncludes.iterator().next();
    
    includeLoc = "Address.xsd";
    actualLoc = schemaRef111.getSchemaLocationURI();
    Assert.assertTrue("schemaRef111.getSchemaLocationURI() " +
            "returned " + actualLoc +
            " instead of " + includeLoc + ".",
            includeLoc.equals(actualLoc));
    
    
    Schema schema111 = schemaRef111.getReferencedSchema();
    Assert.assertNotNull("schemaRef111.getReferencedSchema() " +
            "should not return null.",
            schema111);
    
    //check that the schema DOM element is present
    domEl = schema111.getElement();
    Assert.assertNotNull("schema111.getElement() " +
            "should not return null.",
            domEl);
    
    //The included schema should not import, include or redefine
    //any further schemas.
    
    schemaImportsMap = schema111.getImports();
    if(schemaImportsMap != null) {
        actualSize = schemaImportsMap.size();
        Assert.assertTrue("schema111.getImports() " +
                "returned a map containing " + actualSize +
                " items, instead of 0.",
                actualSize == 0);
    }

    schemaIncludes = schema111.getIncludes();
    if(schemaIncludes != null) {
        actualSize = schemaIncludes.size();
        Assert.assertTrue("schema111.getIncludes() " +
                "returned a list containing " + actualSize +
                " items, instead of 0.",
                actualSize == 0);
    }

    schemaRedefines = schema111.getRedefines();
    if(schemaRedefines != null) {
        actualSize = schemaRedefines.size();
        Assert.assertTrue("schema111.getRedefines() " +
                "returned a list containing " + actualSize +
                " items, instead of 0.",
                actualSize == 0);
    }

    /************************************************************
     * Check that the top level schema includes one schema,
     * which in turn imports one schema.
     * 
     * schema1 <include> schema12 <import> schema121
     ************************************************************/
   
    schemaIncludes = schema1.getIncludes();
    Assert.assertNotNull("schema1.getIncludes() " +
            "should not return null.",
            schemaIncludes);

    actualSize = schemaIncludes.size();
    Assert.assertTrue("schema1.getIncludes() " +
            "returned a list containing " + actualSize +
            " items, instead of 1.",
            actualSize == 1);
    
    SchemaReference schemaRef12 = 
        (SchemaReference) schemaIncludes.iterator().next();
    
    includeLoc = "Hotel.xsd";
    actualLoc = schemaRef12.getSchemaLocationURI();
    Assert.assertTrue("schemaRef12.getSchemaLocationURI() " +
            "returned " + actualLoc +
            " instead of " + includeLoc + ".",
            includeLoc.equals(actualLoc));
    
    Schema schema12 = schemaRef12.getReferencedSchema();
    Assert.assertNotNull("schemaRef12.getReferencedSchema() " +
            "should not return null.",
            schema12);
    
    //check that the schema DOM element is present
    domEl = schema12.getElement();
    Assert.assertNotNull("schema12.getElement() " +
            "should not return null.",
            domEl);
    
    //The included schema should not include any further schemas
    schemaIncludes = schema12.getIncludes();
    if(schemaIncludes != null) {
        actualSize = schemaIncludes.size();
        Assert.assertTrue("schema12.getIncludes() " +
                "returned a list containing " + actualSize +
                " items, instead of 0.",
                actualSize == 0);
    }

    //The included schema should not redefine any further schemas
    schemaRedefines = schema12.getRedefines();
    if(schemaRedefines != null) {
        actualSize = schemaRedefines.size();
        Assert.assertTrue("schema12.getRedefines() " +
                "returned a list containing " + actualSize +
                " items, instead of 0.",
                actualSize == 0);
    }
    
    //The included schema should import one schema
    
    schemaImportsMap = schema12.getImports();
    Assert.assertNotNull("schema12.getImports() " +
            "should not return null.",
            schemaImportsMap);
    
    actualSize = schemaImportsMap.size();
    Assert.assertTrue("schema12.getImports() " +
            "returned a map containing " + actualSize +
            " items, instead of 1.",
            actualSize == 1);
    
    importNS = "http://travelco.com/schema/Address";
    schemaImports = (List) schemaImportsMap.get(importNS);
    SchemaImport schemaImport121 = (SchemaImport) schemaImports.iterator().next();
    
    actualNS = schemaImport121.getNamespaceURI();
    Assert.assertTrue("schemaImport121.getNamespaceURI() " +
            "returned " + actualNS +
            " instead of " + importNS + ".",
            importNS.equals(actualNS));
    
    importLoc = "Address.xsd";
    actualLoc = schemaImport121.getSchemaLocationURI();
    Assert.assertTrue("schemaImport121.getSchemaLocationURI() " +
            "returned " + actualLoc +
            " instead of " + importLoc + ".",
            importLoc.equals(actualLoc));
    
    Schema schema121 = schemaImport121.getReferencedSchema();
    Assert.assertNotNull("schemaImport121.getReferencedSchema() " +
            "should not return null.",
            schema121);

    //check that the schema DOM element is present
    domEl = schema121.getElement();
    Assert.assertNotNull("schema121.getElement() " +
            "should not return null.",
            domEl);
    
    //The imported schema should not import, include or redefine
    //any further schemas.
    
    schemaImportsMap = schema121.getImports();
    if(schemaImportsMap != null) {
        actualSize = schemaImportsMap.size();
        Assert.assertTrue("schema121.getImports() " +
                "returned a map containing " + actualSize +
                " items, instead of 0.",
                actualSize == 0);
    }

    schemaIncludes = schema121.getIncludes();
    if(schemaIncludes != null) {
        actualSize = schemaIncludes.size();
        Assert.assertTrue("schema121.getIncludes() " +
                "returned a list containing " + actualSize +
                " items, instead of 0.",
                actualSize == 0);
    }

    schemaRedefines = schema121.getRedefines();
    if(schemaRedefines != null) {
        actualSize = schemaRedefines.size();
        Assert.assertTrue("schema121.getRedefines() " +
                "returned a list containing " + actualSize +
                " items, instead of 0.",
                actualSize == 0);
    }
    
    /************************************************************
     * Check that the top level schema redefines one schema.
     * 
     * schema1 <redefine> schema13
     ************************************************************/
   
    schemaRedefines = schema1.getRedefines();
    Assert.assertNotNull("schema1.getRedefines() " +
            "should not return null.",
            schemaRedefines);

    actualSize = schemaRedefines.size();
    Assert.assertTrue("schema1.getRedefines() " +
            "returned a list containing " + actualSize +
            " items, instead of 1.",
            actualSize == 1);
    
    SchemaReference schemaRef13 = 
        (SchemaReference) schemaRedefines.iterator().next();
    
    includeLoc = "Address.xsd";
    actualLoc = schemaRef13.getSchemaLocationURI();
    Assert.assertTrue("schemaRef13.getSchemaLocationURI() " +
            "returned " + actualLoc +
            " instead of " + includeLoc + ".",
            includeLoc.equals(actualLoc));
    
    Schema schema13 = schemaRef13.getReferencedSchema();
    Assert.assertNotNull("schemaRef13.getReferencedSchema() " +
            "should not return null.",
            schema13);
    
    //check that the schema DOM element is present
    domEl = schema13.getElement();
    Assert.assertNotNull("schema13.getElement() " +
            "should not return null.",
            domEl);
    
    //The redefined schema should not import, include or redefine
    //any further schemas.
    
    schemaImportsMap = schema13.getImports();
    if(schemaImportsMap != null) {
        actualSize = schemaImportsMap.size();
        Assert.assertTrue("schema13.getImports() " +
                "returned a map containing " + actualSize +
                " items, instead of 0.",
                actualSize == 0);
    }

    schemaIncludes = schema13.getIncludes();
    if(schemaIncludes != null) {
        actualSize = schemaIncludes.size();
        Assert.assertTrue("schema13.getIncludes() " +
                "returned a list containing " + actualSize +
                " items, instead of 0.",
                actualSize == 0);
    }

    schemaRedefines = schema13.getRedefines();
    if(schemaRedefines != null) {
        actualSize = schemaRedefines.size();
        Assert.assertTrue("schema13.getRedefines() " +
                "returned a list containing " + actualSize +
                " items, instead of 0.",
                actualSize == 0);
    }
    
  }
  
  private static ExtensibilityElement checkExtensibilityElements(
    String parentTypeName,
    List extElements)
  {
    Assert.assertNotNull(parentTypeName + ".getExtensibilityElements() " +
                         "should not return null.",
                         extElements);

    int size = extElements.size();

    Assert.assertTrue(parentTypeName + ".getExtensibilityElements() " +
                      "returned a list containing " + size +
                      " items, instead of 1.",
                      size == 1);

    return (ExtensibilityElement)extElements.get(0);
  }

  public static Document getDocument(String fileName)
    throws IOException,
           ParserConfigurationException,
           SAXException
  {
    FileReader fileReader = new FileReader(fileName);
    InputSource inputSource = new InputSource(fileReader);
    DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();

    factory.setNamespaceAware(true);
    factory.setValidating(false);

    DocumentBuilder builder = factory.newDocumentBuilder();
    Document doc = builder.parse(inputSource);

    fileReader.close();

    return doc;
  }

  public static ExtensibilityElement createExtension(ExtensionRegistry extReg,
                                                     Class parentType,
                                                     QName elementType,
                                                     Class extType)
  {
    try
    {
      ExtensibilityElement ext = extReg.createExtension(parentType,
                                                        elementType);

      Assert.assertNotNull("No Java extensionType found " +
                           "to represent a '" + elementType +
                           "' element in the context of a '" +
                           parentType.getName() + "'.",
                           ext);

      Assert.assertTrue("The Java extensionType '" +
                        ext.getClass().getName() + "' does " +
                        "not implement the '" + extType.getName() +
                        "' interface.",
                        extType.isAssignableFrom(ext.getClass()));

      Assert.assertTrue("The extensibility element should return '" +
                        elementType + "' when " +
                        "ExtensibilityElement.getElementType() is called.",
                        elementType.equals(ext.getElementType()));

      return ext;
    }
    catch (WSDLException e)
    {
      Assert.fail(e.getMessage());

      return null;
    }
  }
}