/*
 * (c) Copyright IBM Corp 2001, 2006 
 */

package com.ibm.wsdl.tck;

import javax.wsdl.*;
import javax.wsdl.factory.*;
import javax.xml.namespace.*;
import javax.xml.parsers.*;
import junit.framework.*;
import org.w3c.dom.*;

/**
 * This class implements a series of tests used to check
 * javax.wsdl.Binding implementations for compliance
 * with the JWSDL specification.
 *
 * @author Matthew J. Duftler (duftler@us.ibm.com)
 */
public class BindingTest extends TestCase
{
  private static final String TEST_CANDIDATE_PROPERTY_NAME =
    "javax.wsdl.factory.WSDLFactoryCandidate";
  private static final String NS_URI_WSDL =
    "http://schemas.xmlsoap.org/wsdl/";

  private Definition definition = null;
  private Binding binding = null;

  protected void setUp() throws WSDLException
  {
    // Determine name of JWSDL factory implementation to test.
    String testCandidateName =
      System.getProperty(TEST_CANDIDATE_PROPERTY_NAME);

    if (testCandidateName == null)
    {
      throw new IllegalArgumentException("System property '" +
                                         TEST_CANDIDATE_PROPERTY_NAME +
                                         "' must be specified to run " +
                                         "test suite.");
    }

    WSDLFactory factory = WSDLFactory.newInstance(testCandidateName);

    Assert.assertNotNull("WSDLFactory should not be null.", factory);

    definition = factory.newDefinition();

    Assert.assertNotNull("Definition should not be null.", definition);

    binding = definition.createBinding();

    Assert.assertNotNull("Binding should not be null.", binding);
  }

  /**
   * Test Binding.addBindingOperation(...),
   * Binding.getBindingOperation(...) and
   * Binding.removeBindingOperation(...)
   * specifying the operation name and null for the input and output message names.
   */
  public void testAddGetRemoveBindingOperation()
  {
    BindingOperation bindingOp = definition.createBindingOperation();
    Assert.assertNotNull("BindingOperation should not be null.", bindingOp);
    bindingOp.setName("abcdef");
    
    BindingInput in = definition.createBindingInput();
    Assert.assertNotNull("BindingInput should not be null.", in);
    in.setName("inMsg");
    
    BindingOutput out = definition.createBindingOutput();
    Assert.assertNotNull("BindingOutput should not be null.", out);
    out.setName("outMsg");
    
    bindingOp.setBindingInput(in);
    bindingOp.setBindingOutput(out);
    binding.addBindingOperation(bindingOp);

    //Manipulate the named operation, ignoring the input and output message names.

    BindingOperation bindingOp2 = binding.getBindingOperation("abcdef",
                                                              null,
                                                              null);

    Assert.assertTrue("Binding.getBindingOperation(...) did not return " +
                      "the same BindingOperation that was added using " +
                      "Binding.addBindingOperation(...).",
                      bindingOp == bindingOp2);
    
    BindingOperation bindingOp3 = binding.removeBindingOperation("abcdef",
                                                                 null,
                                                                 null);

    Assert.assertTrue("Binding.removeBindingOperation(...) did not return " +
                      "the same BindingOperation that was added using " +
                      "Binding.addBindingOperation(...).",
                      bindingOp == bindingOp3);
  
    Assert.assertNull("Binding.removeOperation(...) did not remove " +
                      "the same BindingOperation that was added using " +
                      "Binding.addBindingOperation(...).",
                      binding.removeBindingOperation("abcdef", null, null));
  }

  /**
   * Test Binding.addBindingOperation(...),
   * Binding.getBindingOperation(...) and
   * Binding.removeBindingOperation(...)
   * specifying the operation name and the input and output message names.
   */
  public void testAddGetRemoveBindingOperation2()
  {
    //Create an operation with named input and output messages.
      
    BindingOperation bindingOp = definition.createBindingOperation();
    Assert.assertNotNull("BindingOperation should not be null.", bindingOp);
    bindingOp.setName("abcdef");
    
    BindingInput in = definition.createBindingInput();
    Assert.assertNotNull("BindingInput should not be null.", in);
    in.setName("inMsg");
    
    BindingOutput out = definition.createBindingOutput();
    Assert.assertNotNull("BindingOutput should not be null.", out);
    out.setName("outMsg");
    
    bindingOp.setBindingInput(in);
    bindingOp.setBindingOutput(out);
    binding.addBindingOperation(bindingOp);

    //Create an operation with unnamed input and output messages
    
    BindingOperation bindingOp1 = definition.createBindingOperation();
    Assert.assertNotNull("BindingOperation should not be null.", bindingOp1);
    bindingOp1.setName("abcdef");
    
    BindingInput in1 = definition.createBindingInput();
    Assert.assertNotNull("BindingInput should not be null.", in1);
    
    BindingOutput out1 = definition.createBindingOutput();
    Assert.assertNotNull("BindingOutput should not be null.", out1);
    
    bindingOp1.setBindingInput(in1);
    bindingOp1.setBindingOutput(out1);
    binding.addBindingOperation(bindingOp1);

    //Manipulate the named operation with the named input and output messages

    BindingOperation bindingOp2 = binding.getBindingOperation("abcdef",
                                                              "inMsg",
                                                              "outMsg");

    Assert.assertTrue("Binding.getBindingOperation(...) did not return " +
                      "the same BindingOperation that was added using " +
                      "Binding.addBindingOperation(...).",
                      bindingOp == bindingOp2);
    
    BindingOperation bindingOp3 = binding.removeBindingOperation("abcdef",
                                                                 "inMsg",
                                                                 "outMsg");

    Assert.assertTrue("Binding.removeBindingOperation(...) did not return " +
                      "the same BindingOperation that was added using " +
                      "Binding.addBindingOperation(...).",
                      bindingOp == bindingOp3);
  
    Assert.assertNull("Binding.removeOperation(...) did not remove " +
                      "the same BindingOperation that was added using " +
                      "Binding.addBindingOperation(...).",
                      binding.removeBindingOperation("abcdef", "inMsg", "outMsg"));
  }

  /**
   * Test Binding.addBindingOperation(...),
   * Binding.getBindingOperation(...) and
   * Binding.removeBindingOperation(...)
   * specifying the operation name and ":none" for the input and output message names.
   */
  public void testAddGetRemoveBindingOperation3()
  {
    //Create an operation with named input and output messages.
      
    BindingOperation bindingOp = definition.createBindingOperation();
    Assert.assertNotNull("BindingOperation should not be null.", bindingOp);
    bindingOp.setName("abcdef");
    
    BindingInput in = definition.createBindingInput();
    Assert.assertNotNull("BindingInput should not be null.", in);
    in.setName("inMsg");
    
    BindingOutput out = definition.createBindingOutput();
    Assert.assertNotNull("BindingOutput should not be null.", out);
    out.setName("outMsg");
    
    bindingOp.setBindingInput(in);
    bindingOp.setBindingOutput(out);
    binding.addBindingOperation(bindingOp);

    //Create an operation with unnamed input and output messages
    
    BindingOperation bindingOp1 = definition.createBindingOperation();
    Assert.assertNotNull("BindingOperation should not be null.", bindingOp1);
    bindingOp1.setName("abcdef");
    
    BindingInput in1 = definition.createBindingInput();
    Assert.assertNotNull("BindingInput should not be null.", in1);
    
    BindingOutput out1 = definition.createBindingOutput();
    Assert.assertNotNull("BindingOutput should not be null.", out1);
    
    bindingOp1.setBindingInput(in1);
    bindingOp1.setBindingOutput(out1);
    binding.addBindingOperation(bindingOp1);

    //Manipulate the named operation with the unnamed input and output messages

    BindingOperation bindingOp2 = binding.getBindingOperation("abcdef",
                                                              ":none",
                                                              ":none");

    Assert.assertTrue("Binding.getBindingOperation(...) did not return " +
                      "the same BindingOperation that was added using " +
                      "Binding.addBindingOperation(...).",
                      bindingOp1 == bindingOp2);
    
    BindingOperation bindingOp3 = binding.removeBindingOperation("abcdef",
                                                                 ":none",
                                                                 ":none");

    Assert.assertTrue("Binding.removeBindingOperation(...) did not return " +
                      "the same BindingOperation that was added using " +
                      "Binding.addBindingOperation(...).",
                      bindingOp1 == bindingOp3);
  
    Assert.assertNull("Binding.removeOperation(...) did not remove " +
                      "the same BindingOperation that was added using " +
                      "Binding.addBindingOperation(...).",
                      binding.removeBindingOperation("abcdef", ":none", ":none"));
  }

  /**
   * Test Binding.setDocumentationElement(...) and
   * Binding.getDocumentationElement().
   */
  public void testSetGetDocumentationElement()
    throws ParserConfigurationException
  {
    DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();

    factory.setNamespaceAware(true);
    factory.setValidating(false);

    DocumentBuilder builder = factory.newDocumentBuilder();
    Document doc = builder.newDocument();
    Element el = doc.createElementNS(NS_URI_WSDL,
                                     "wsdl:documentation");

    binding.setDocumentationElement(el);

    Element el2 = binding.getDocumentationElement();

    Assert.assertTrue("Binding.getDocumentationElement() did not return " +
                      "the same Element that was set using " +
                      "Binding.setDocumentationElement(...).",
                      el == el2);
  }

  /**
   * Test Binding.setPortType(...) andBinding.getPortType().
   */
  public void testSetGetPortType()
  {
    PortType portType = definition.createPortType();

    Assert.assertNotNull("PortType should not be null.", portType);

    binding.setPortType(portType);

    PortType portType2 = binding.getPortType();

    Assert.assertTrue("Binding.getPortType() did not return " +
                      "the same PortType that was set using " +
                      "Binding.setPortType(...).",
                      portType == portType2);
  }

  /**
   * Test Binding.setQName(...) andBinding.getQName().
   */
  public void testSetGetQName()
  {
    QName qname = new QName("urn:abc", "def");

    binding.setQName(qname);

    QName qname2 = binding.getQName();

    Assert.assertTrue("Binding.getQName() did not return " +
                      "the same QName that was set using " +
                      "Binding.setQName(...).",
                      qname.equals(qname2));
  }

  /**
   * Test Binding.setUndefined(...) andBinding.isUndefined().
   */
  public void testIsSetUndefined()
  {
    Assert.assertTrue("The default value of the undefined property " +
                      "of a newly created Binding should be " +
                      "true.",
                      binding.isUndefined());

    binding.setUndefined(false);

    Assert.assertFalse("Binding.isUndefined() returned " +
                       "true even though Binding.setUndefined(false) " +
                       "was called.",
                       binding.isUndefined());
  } 
}