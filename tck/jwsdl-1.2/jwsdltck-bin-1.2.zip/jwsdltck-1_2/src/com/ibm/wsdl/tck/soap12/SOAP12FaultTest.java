/*
 * (c) Copyright IBM Corp 2006 
 */

package com.ibm.wsdl.tck.soap12;

import java.io.IOException;

import javax.wsdl.BindingFault;
import javax.wsdl.WSDLException;
import javax.wsdl.extensions.ExtensionRegistry;
import javax.wsdl.extensions.soap12.SOAP12Fault;
import javax.wsdl.factory.WSDLFactory;
import javax.xml.namespace.QName;

import junit.framework.Assert;
import junit.framework.TestCase;

import com.ibm.wsdl.tck.util.TCKUtils;

/**
 * This class implements a series of tests used to check
 * javax.wsdl.extensions.soap12.SOAP12Fault implementations
 * for compliance with the JWSDL specification.
 *
 * @author Matthew J. Duftler (duftler@us.ibm.com)
 */
public class SOAP12FaultTest extends TestCase
{
  private static final String TEST_CANDIDATE_PROPERTY_NAME =
    "javax.wsdl.factory.WSDLFactoryCandidate";
  private static final String NS_URI_SOAP12 =
    "http://schemas.xmlsoap.org/wsdl/soap12/";

  private WSDLFactory factory = null;
  private ExtensionRegistry extReg = null;
  private SOAP12Fault soapFault = null;

  protected void setUp() throws WSDLException, IOException
  {
    // Determine name of JWSDL factory implementation to test.
    String testCandidateName =
      System.getProperty(TEST_CANDIDATE_PROPERTY_NAME);

    if (testCandidateName == null)
    {
      throw new IllegalArgumentException("System property '" +
                                         TEST_CANDIDATE_PROPERTY_NAME +
                                         "' must be specified to run " +
                                         "test suite.");
    }

    factory = WSDLFactory.newInstance(testCandidateName);

    Assert.assertNotNull("WSDLFactory should not be null.", factory);

    extReg = factory.newPopulatedExtensionRegistry();

    Assert.assertNotNull("ExtensionRegistry should not be null.", extReg);

    QName soapFaultQName = new QName(NS_URI_SOAP12, "fault");

    soapFault = (SOAP12Fault)TCKUtils.createExtension(extReg,
                                                    BindingFault.class,
                                                    soapFaultQName,
                                                    SOAP12Fault.class);
  }

  /**
   * Test SOAP12Fault.setEncodingStyle(...) and SOAP12Fault.getEncodingStyle().
   */
  public void testSetGetEncodingStyle()
  {
    String encodingStyle = "Style1";

    soapFault.setEncodingStyle(encodingStyle);

    String encodingStyle2 = soapFault.getEncodingStyle();

    Assert.assertTrue("SOAP12Fault.getEncodingStyle() did not return " +
                      "the same style that was set using " +
                      "SOAP12Fault.setEncodingStyle(...).",
                      encodingStyle.equals(encodingStyle2));
  }

  /**
   * Test SOAP12Fault.setName(...) and SOAP12Fault.getName().
   */
  public void testSetGetName()
  {
    String name = "abcdef";

    soapFault.setName(name);

    String name2 = soapFault.getName();

    Assert.assertTrue("SOAP12Fault.getName() did not return " +
                      "the same name that was set using " +
                      "SOAP12Fault.setName(...).",
                      name.equals(name2));
  }

  /**
   * Test SOAP12Fault.setNamespaceURI(...) and SOAP12Fault.getNamespaceURI().
   */
  public void testSetGetNamespaceURI()
  {
    String namespaceURI = "urn:abcdef";

    soapFault.setNamespaceURI(namespaceURI);

    String namespaceURI2 = soapFault.getNamespaceURI();

    Assert.assertTrue("SOAP12Fault.getNamespaceURI() did not return " +
                      "the same namespace URI that was set using " +
                      "SOAP12Fault.setNamespaceURI(...).",
                      namespaceURI.equals(namespaceURI2));
  }

  /**
   * Test SOAP12Fault.setUse(...) and SOAP12Fault.getUse().
   */
  public void testSetGetUse()
  {
    String use = "encoded";

    soapFault.setUse(use);

    String use2 = soapFault.getUse();

    Assert.assertTrue("SOAP12Fault.getUse() did not return " +
                      "the same use that was set using " +
                      "SOAP12Fault.setUse(...).",
                      use.equals(use2));
  }
}