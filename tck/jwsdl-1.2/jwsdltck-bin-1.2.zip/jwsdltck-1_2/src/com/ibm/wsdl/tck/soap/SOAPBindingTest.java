/*
 * (c) Copyright IBM Corp 2001, 2006 
 */

package com.ibm.wsdl.tck.soap;

import com.ibm.wsdl.tck.util.*;
import java.io.*;
import javax.wsdl.*;
import javax.wsdl.extensions.*;
import javax.wsdl.extensions.soap.*;
import javax.wsdl.factory.*;
import javax.xml.namespace.*;
import junit.framework.*;

/**
 * This class implements a series of tests used to check
 * javax.wsdl.extensions.soap.SOAPBinding implementations
 * for compliance with the JWSDL specification.
 *
 * @author Matthew J. Duftler (duftler@us.ibm.com)
 */
public class SOAPBindingTest extends TestCase
{
  private static final String TEST_CANDIDATE_PROPERTY_NAME =
    "javax.wsdl.factory.WSDLFactoryCandidate";
  private static final String NS_URI_SOAP =
    "http://schemas.xmlsoap.org/wsdl/soap/";

  private WSDLFactory factory = null;
  private ExtensionRegistry extReg = null;
  private SOAPBinding soapBinding = null;

  protected void setUp() throws WSDLException, IOException
  {
    // Determine name of JWSDL factory implementation to test.
    String testCandidateName =
      System.getProperty(TEST_CANDIDATE_PROPERTY_NAME);

    if (testCandidateName == null)
    {
      throw new IllegalArgumentException("System property '" +
                                         TEST_CANDIDATE_PROPERTY_NAME +
                                         "' must be specified to run " +
                                         "test suite.");
    }

    factory = WSDLFactory.newInstance(testCandidateName);

    Assert.assertNotNull("WSDLFactory should not be null.", factory);

    extReg = factory.newPopulatedExtensionRegistry();

    Assert.assertNotNull("ExtensionRegistry should not be null.", extReg);

    QName soapBindingQName = new QName(NS_URI_SOAP, "binding");

    soapBinding = (SOAPBinding)TCKUtils.createExtension(extReg,
                                                        Binding.class,
                                                        soapBindingQName,
                                                        SOAPBinding.class);
  }

  /**
   * Test SOAPBinding.setStyle(...) and SOAPBinding.getStyle().
   */
  public void testSetGetStyle()
  {
    String style = "abcdef";

    soapBinding.setStyle(style);

    String style2 = soapBinding.getStyle();

    Assert.assertTrue("SOAPBinding.getStyle() did not return " +
                      "the same style that was set using " +
                      "SOAPBinding.setStyle(...).",
                      style.equals(style2));
  }

  /**
   * Test SOAPBinding.setTransportURI(...) and SOAPBinding.getTransportURI().
   */
  public void testSetGetTransportURI()
  {
    String transportURI = "urn:abcdef";

    soapBinding.setTransportURI(transportURI);

    String transportURI2 = soapBinding.getTransportURI();

    Assert.assertTrue("SOAPBinding.getTransportURI() did not return " +
                      "the same transport URI that was set using " +
                      "SOAPBinding.setTransportURI(...).",
                      transportURI.equals(transportURI2));
  }
}