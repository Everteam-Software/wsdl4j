/*
 * (c) Copyright IBM Corp 2001, 2006 
 */

package com.ibm.wsdl.tck;

import javax.wsdl.*;
import javax.wsdl.factory.*;
import javax.xml.parsers.*;
import junit.framework.*;
import org.w3c.dom.*;

/**
 * This class implements a series of tests used to check
 * javax.wsdl.BindingInput implementations for compliance
 * with the JWSDL specification.
 *
 * @author Matthew J. Duftler (duftler@us.ibm.com)
 */
public class BindingInputTest extends TestCase
{
  private static final String TEST_CANDIDATE_PROPERTY_NAME =
    "javax.wsdl.factory.WSDLFactoryCandidate";
  private static final String NS_URI_WSDL =
    "http://schemas.xmlsoap.org/wsdl/";

  private Definition definition = null;
  private BindingInput bindingInput = null;

  protected void setUp() throws WSDLException
  {
    // Determine name of JWSDL factory implementation to test.
    String testCandidateName =
      System.getProperty(TEST_CANDIDATE_PROPERTY_NAME);

    if (testCandidateName == null)
    {
      throw new IllegalArgumentException("System property '" +
                                         TEST_CANDIDATE_PROPERTY_NAME +
                                         "' must be specified to run " +
                                         "test suite.");
    }

    WSDLFactory factory = WSDLFactory.newInstance(testCandidateName);

    Assert.assertNotNull("WSDLFactory should not be null.", factory);

    definition = factory.newDefinition();

    Assert.assertNotNull("Definition should not be null.", definition);

    bindingInput = definition.createBindingInput();

    Assert.assertNotNull("BindingInput should not be null.", bindingInput);
  }

  /**
   * Test BindingInput.setDocumentationElement(...) and
   * BindingInput.getDocumentationElement().
   */
  public void testSetGetDocumentationElement()
    throws ParserConfigurationException
  {
    DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();

    factory.setNamespaceAware(true);
    factory.setValidating(false);

    DocumentBuilder builder = factory.newDocumentBuilder();
    Document doc = builder.newDocument();
    Element el = doc.createElementNS(NS_URI_WSDL,
                                     "wsdl:documentation");

    bindingInput.setDocumentationElement(el);

    Element el2 = bindingInput.getDocumentationElement();

    Assert.assertTrue("BindingInput.getDocumentationElement() did not " +
                      "return the same Element that was set using " +
                      "BindingInput.setDocumentationElement(...).",
                      el == el2);
  }

  /**
   * Test BindingInput.setName(...) and BindingInput.getName().
   */
  public void testSetGetName()
  {
    String name = "abcdef";

    bindingInput.setName(name);

    String name2 = bindingInput.getName();

    Assert.assertTrue("BindingInput.getName() did not return " +
                      "the same name that was set using " +
                      "BindingInput.setName(...).",
                      name.equals(name2));
  }
}