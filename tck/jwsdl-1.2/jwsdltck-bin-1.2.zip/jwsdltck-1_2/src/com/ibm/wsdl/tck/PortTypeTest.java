/*
 * (c) Copyright IBM Corp 2001, 2006 
 */

package com.ibm.wsdl.tck;

import javax.wsdl.*;
import javax.wsdl.factory.*;
import javax.xml.namespace.*;
import javax.xml.parsers.*;
import junit.framework.*;
import org.w3c.dom.*;

/**
 * This class implements a series of tests used to check
 * javax.wsdl.PortType implementations for compliance
 * with the JWSDL specification.
 *
 * @author Matthew J. Duftler (duftler@us.ibm.com)
 */
public class PortTypeTest extends TestCase
{
  private static final String TEST_CANDIDATE_PROPERTY_NAME =
    "javax.wsdl.factory.WSDLFactoryCandidate";
  private static final String NS_URI_WSDL =
    "http://schemas.xmlsoap.org/wsdl/";

  private Definition definition = null;
  private PortType portType = null;

  protected void setUp() throws WSDLException
  {
    // Determine name of JWSDL factory implementation to test.
    String testCandidateName =
      System.getProperty(TEST_CANDIDATE_PROPERTY_NAME);

    if (testCandidateName == null)
    {
      throw new IllegalArgumentException("System property '" +
                                         TEST_CANDIDATE_PROPERTY_NAME +
                                         "' must be specified to run " +
                                         "test suite.");
    }

    WSDLFactory factory = WSDLFactory.newInstance(testCandidateName);

    Assert.assertNotNull("WSDLFactory should not be null.", factory);

    definition = factory.newDefinition();

    Assert.assertNotNull("Definition should not be null.", definition);

    portType = definition.createPortType();

    Assert.assertNotNull("PortType should not be null.", portType);
  }

  /**
   * Test PortType.addOperation(...), PortType.getOperation(...)
   * and PortType.removeOperation(...) specifying the operation
   * name and null for the input and output message names.
   */
  public void testAddGetRemoveOperation()
  {
    Operation op = definition.createOperation();
    Assert.assertNotNull("Operation should not be null.", op);
    op.setName("abcdef");
    
    Input in = definition.createInput();
    Assert.assertNotNull("Input should not be null.", in);
    in.setName("inMsg");
    
    Output out = definition.createOutput();
    Assert.assertNotNull("Output should not be null.", out);
    out.setName("outMsg");
    
    op.setInput(in);
    op.setOutput(out);
    portType.addOperation(op);

    //Manipulate the named operation, ignoring the input and output message names.
    
    Operation op2 = portType.getOperation("abcdef", null, null);

    Assert.assertTrue("PortType.getOperation(...) did not return " +
                      "the same Operation that was added using " +
                      "PortType.addOperation(...).",
                      op == op2);
    
    Operation op3 = portType.removeOperation("abcdef", null, null);

    Assert.assertTrue("PortType.removeOperation(...) did not return " +
                      "the same Operation that was added using " +
                      "PortType.addOperation(...).",
                      op == op3);
    
    Assert.assertNull("PortType.removeOperation(...) did not remove " +
                      "the same Operation that was added using " +
                      "PortType.addOperation(...).",
                      portType.removeOperation("abcdef", null, null));
  }

  /**
   * Test PortType.addOperation(...), PortType.getOperation(...)
   * and PortType.removeOperation(...) specifying the operation
   * name and the input and output message names.
   */
  public void testAddGetRemoveOperation2()
  {
    //Create an operation with named input and output messages.
      
    Operation op = definition.createOperation();
    Assert.assertNotNull("Operation should not be null.", op);
    op.setName("abcdef");
    
    Input in = definition.createInput();
    Assert.assertNotNull("Input should not be null.", in);
    in.setName("inMsg");

    Output out = definition.createOutput();
    Assert.assertNotNull("Output should not be null.", out);
    out.setName("outMsg");
    
    op.setInput(in);
    op.setOutput(out);
    portType.addOperation(op);

    //Create an operation with unnamed input and output messages
    
    Operation op1 = definition.createOperation();
    Assert.assertNotNull("Operation should not be null.", op);
    op1.setName("abcdef");
    
    Input in1 = definition.createInput();
    Assert.assertNotNull("Input should not be null.", in1);
    
    Output out1 = definition.createOutput();
    Assert.assertNotNull("Output should not be null.", out1);

    op1.setInput(in1);
    op1.setOutput(out1);
    portType.addOperation(op1);

    //Manipulate the named operation with the named input and output messages
    
    Operation op2 = portType.getOperation("abcdef", "inMsg", "outMsg");

    Assert.assertTrue("PortType.getOperation(...) did not return " +
                      "the same Operation that was added using " +
                      "PortType.addOperation(...).",
                      op == op2);
    
    Operation op3 = portType.removeOperation("abcdef", "inMsg", "outMsg");

    Assert.assertTrue("PortType.removeOperation(...) did not return " +
                      "the same Operation that was added using " +
                      "PortType.addOperation(...).",
                      op == op3);
    
    Assert.assertNull("PortType.removeOperation(...) did not remove " +
                      "the same Operation that was added using " +
                      "PortType.addOperation(...).",
                      portType.getOperation("abcdef", "inMsg", "outMsg"));
  }

  /**
   * Test PortType.addOperation(...), PortType.getOperation(...)
   * and PortType.removeOperation(...) specifying the operation
   * name and ":none" for the input and output message names.
   */
  public void testAddGetRemoveOperation3()
  {
    //Create an operation with named input and output messages.
      
    Operation op = definition.createOperation();
    Assert.assertNotNull("Operation should not be null.", op);
    op.setName("abcdef");
    
    Input in = definition.createInput();
    Assert.assertNotNull("Input should not be null.", in);
    in.setName("inMsg");

    Output out = definition.createOutput();
    Assert.assertNotNull("Output should not be null.", out);
    out.setName("outMsg");
    
    op.setInput(in);
    op.setOutput(out);
    portType.addOperation(op);

    //Create an operation with unnamed input and output messages
    
    Operation op1 = definition.createOperation();
    Assert.assertNotNull("Operation should not be null.", op);
    op1.setName("abcdef");
    
    Input in1 = definition.createInput();
    Assert.assertNotNull("Input should not be null.", in1);
    
    Output out1 = definition.createOutput();
    Assert.assertNotNull("Output should not be null.", out1);

    op1.setInput(in1);
    op1.setOutput(out1);
    portType.addOperation(op1);

    //Manipulate the named operation with unnamed input and output messages
    
    Operation op2 = portType.getOperation("abcdef", ":none", ":none");

    Assert.assertTrue("PortType.getOperation(...) did not return " +
                      "the same Operation that was added using " +
                      "PortType.addOperation(...).",
                      op1 == op2);
    
    Operation op3 = portType.removeOperation("abcdef", ":none", ":none");

    Assert.assertTrue("PortType.removeOperation(...) did not return " +
                      "the same Operation that was added using " +
                      "PortType.addOperation(...).",
                      op1 == op3);
    
    Assert.assertNull("PortType.removeOperation(...) did not remove " +
                      "the same Operation that was added using " +
                      "PortType.addOperation(...).",
                      portType.getOperation("abcdef", ":none", ":none"));
  }

  /**
   * Test PortType.setDocumentationElement(...) and
   * PortType.getDocumentationElement().
   */
  public void testSetGetDocumentationElement()
    throws ParserConfigurationException
  {
    DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();

    factory.setNamespaceAware(true);
    factory.setValidating(false);

    DocumentBuilder builder = factory.newDocumentBuilder();
    Document doc = builder.newDocument();
    Element el = doc.createElementNS(NS_URI_WSDL,
                                     "wsdl:documentation");

    portType.setDocumentationElement(el);

    Element el2 = portType.getDocumentationElement();

    Assert.assertTrue("PortType.getDocumentationElement() did not return " +
                      "the same Element that was set using " +
                      "PortType.setDocumentationElement(...).",
                      el == el2);
  }

  /**
   * Test PortType.setQName(...) and PortType.getQName().
   */
  public void testSetGetQName()
  {
    QName qname = new QName("urn:abc", "def");

    portType.setQName(qname);

    QName qname2 = portType.getQName();

    Assert.assertTrue("PortType.getQName() did not return " +
                      "the same QName that was set using " +
                      "PortType.setQName(...).",
                      qname.equals(qname2));
  }

  /**
   * Test PortType.setUndefined(...) and PortType.isUndefined().
   */
  public void testIsSetUndefined()
  {
    Assert.assertTrue("The default value of the undefined property " +
                      "of a newly created PortType should be " +
                      "true.",
                      portType.isUndefined());

    portType.setUndefined(false);

    Assert.assertFalse("PortType.isUndefined() returned " +
                       "true even though PortType.setUndefined(false) " +
                       "was called.",
                       portType.isUndefined());
  } 
}