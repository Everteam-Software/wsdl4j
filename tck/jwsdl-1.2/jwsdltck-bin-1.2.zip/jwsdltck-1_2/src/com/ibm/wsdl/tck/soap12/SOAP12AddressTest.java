/*
 * (c) Copyright IBM Corp 2006 
 */

package com.ibm.wsdl.tck.soap12;

import java.io.IOException;

import javax.wsdl.Port;
import javax.wsdl.WSDLException;
import javax.wsdl.extensions.ExtensionRegistry;
import javax.wsdl.extensions.soap12.SOAP12Address;
import javax.wsdl.factory.WSDLFactory;
import javax.xml.namespace.QName;

import junit.framework.Assert;
import junit.framework.TestCase;

import com.ibm.wsdl.tck.util.TCKUtils;

/**
 * This class implements a series of tests used to check
 * javax.wsdl.extensions.soap12.SOAP12Address implementations
 * for compliance with the JWSDL specification.
 *
 * @author Matthew J. Duftler (duftler@us.ibm.com)
 */
public class SOAP12AddressTest extends TestCase
{
  private static final String TEST_CANDIDATE_PROPERTY_NAME =
    "javax.wsdl.factory.WSDLFactoryCandidate";
  private static final String NS_URI_SOAP12 =
    "http://schemas.xmlsoap.org/wsdl/soap12/";

  private WSDLFactory factory = null;
  private ExtensionRegistry extReg = null;
  private SOAP12Address soapAddress = null;

  protected void setUp() throws WSDLException, IOException
  {
    // Determine name of JWSDL factory implementation to test.
    String testCandidateName =
      System.getProperty(TEST_CANDIDATE_PROPERTY_NAME);

    if (testCandidateName == null)
    {
      throw new IllegalArgumentException("System property '" +
                                         TEST_CANDIDATE_PROPERTY_NAME +
                                         "' must be specified to run " +
                                         "test suite.");
    }

    factory = WSDLFactory.newInstance(testCandidateName);

    Assert.assertNotNull("WSDLFactory should not be null.", factory);

    extReg = factory.newPopulatedExtensionRegistry();

    Assert.assertNotNull("ExtensionRegistry should not be null.", extReg);

    QName soapAddressQName = new QName(NS_URI_SOAP12, "address");

    soapAddress = (SOAP12Address)TCKUtils.createExtension(extReg,
                                                        Port.class,
                                                        soapAddressQName,
                                                        SOAP12Address.class);
  }

  /**
   * Test SOAP12Address.setLocationURI(...) and SOAP12Address.getLocationURI().
   */
  public void testSetGetLocationURI()
  {
    String locationURI = "urn:abcdef";

    soapAddress.setLocationURI(locationURI);

    String locationURI2 = soapAddress.getLocationURI();

    Assert.assertTrue("SOAP12Address.getLocationURI() did not return " +
                      "the same location URI that was set using " +
                      "SOAP12Address.setLocationURI(...).",
                      locationURI.equals(locationURI2));
  }
}