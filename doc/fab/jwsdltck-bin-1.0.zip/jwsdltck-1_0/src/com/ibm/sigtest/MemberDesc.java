package com.ibm.sigtest;

/**
 * This class stores the name and modifiers for a given member (class or
 * method).
 *
 * @author Matthew J. Duftler (duftler@us.ibm.com)
 */
public class MemberDesc
{
  protected String name = null;
  protected int modifiers = 0;

  public MemberDesc(String name, int modifiers)
  {
    this.name = name;
    this.modifiers = modifiers;
  }

  public void setName(String name)
  {
    this.name = name;
  }

  public String getName()
  {
    return name;
  }

  public void setModifiers(int modifiers)
  {
    this.modifiers = modifiers;
  }

  public int getModifiers()
  {
    return modifiers;
  }
}