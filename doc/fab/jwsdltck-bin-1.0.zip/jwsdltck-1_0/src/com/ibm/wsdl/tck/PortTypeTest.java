package com.ibm.wsdl.tck;

import javax.wsdl.*;
import javax.wsdl.extensions.*;
import javax.wsdl.factory.*;
import javax.wsdl.xml.*;
import javax.xml.namespace.*;
import javax.xml.parsers.*;
import junit.framework.*;
import org.w3c.dom.*;

/**
 * This class implements a series of tests used to check
 * javax.wsdl.PortType implementations for compliance
 * with the JWSDL specification.
 *
 * @author Matthew J. Duftler (duftler@us.ibm.com)
 */
public class PortTypeTest extends TestCase
{
  private static final String TEST_CANDIDATE_PROPERTY_NAME =
    "javax.wsdl.factory.WSDLFactoryCandidate";
  private static final String NS_URI_WSDL =
    "http://schemas.xmlsoap.org/wsdl/";

  private Definition definition = null;
  private PortType portType = null;

  protected void setUp() throws WSDLException
  {
    // Determine name of JWSDL factory implementation to test.
    String testCandidateName =
      System.getProperty(TEST_CANDIDATE_PROPERTY_NAME);

    if (testCandidateName == null)
    {
      throw new IllegalArgumentException("System property '" +
                                         TEST_CANDIDATE_PROPERTY_NAME +
                                         "' must be specified to run " +
                                         "test suite.");
    }

    WSDLFactory factory = WSDLFactory.newInstance(testCandidateName);

    Assert.assertNotNull("WSDLFactory should not be null.", factory);

    definition = factory.newDefinition();

    Assert.assertNotNull("Definition should not be null.", definition);

    portType = definition.createPortType();

    Assert.assertNotNull("PortType should not be null.", portType);
  }

  /**
   * Test PortType.addOperation(...) and PortType.getOperation(...).
   */
  public void testAddGetOperation()
  {
    Operation op = definition.createOperation();

    Assert.assertNotNull("Operation should not be null.", op);

    op.setName("abcdef");
    portType.addOperation(op);

    Operation op2 = portType.getOperation("abcdef", null, null);

    Assert.assertTrue("PortType.getOperation(...) did not return " +
                      "the same Operation that was added using " +
                      "PortType.addOperation(...).",
                      op == op2);
  }

  /**
   * Test PortType.setDocumentationElement(...) and
   * PortType.getDocumentationElement().
   */
  public void testSetGetDocumentationElement()
    throws ParserConfigurationException
  {
    DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();

    factory.setNamespaceAware(true);
    factory.setValidating(false);

    DocumentBuilder builder = factory.newDocumentBuilder();
    Document doc = builder.newDocument();
    Element el = doc.createElementNS(NS_URI_WSDL,
                                     "wsdl:documentation");

    portType.setDocumentationElement(el);

    Element el2 = portType.getDocumentationElement();

    Assert.assertTrue("PortType.getDocumentationElement() did not return " +
                      "the same Element that was set using " +
                      "PortType.setDocumentationElement(...).",
                      el == el2);
  }

  /**
   * Test PortType.setQName(...) and PortType.getQName().
   */
  public void testSetGetQName()
  {
    QName qname = new QName("urn:abc", "def");

    portType.setQName(qname);

    QName qname2 = portType.getQName();

    Assert.assertTrue("PortType.getQName() did not return " +
                      "the same QName that was set using " +
                      "PortType.setQName(...).",
                      qname.equals(qname2));
  }

  /**
   * Test PortType.setUndefined(...) and PortType.isUndefined().
   */
  public void testIsSetUndefined()
  {
    Assert.assertTrue("The default value of the undefined property " +
                      "of a newly created PortType should be " +
                      "true.",
                      portType.isUndefined());

    portType.setUndefined(false);

    Assert.assertFalse("PortType.isUndefined() returned " +
                       "true even though PortType.setUndefined(false) " +
                       "was called.",
                       portType.isUndefined());
  } 
}