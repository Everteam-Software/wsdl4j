package com.ibm.wsdl.tck.soap;

import com.ibm.wsdl.tck.util.*;
import java.io.*;
import java.util.*;
import javax.wsdl.*;
import javax.wsdl.extensions.*;
import javax.wsdl.extensions.soap.*;
import javax.wsdl.factory.*;
import javax.wsdl.xml.*;
import javax.xml.namespace.*;
import junit.framework.*;

/**
 * This class implements a series of tests used to check
 * javax.wsdl.extensions.soap.SOAPFault implementations
 * for compliance with the JWSDL specification.
 *
 * @author Matthew J. Duftler (duftler@us.ibm.com)
 */
public class SOAPFaultTest extends TestCase
{
  private static final String TEST_CANDIDATE_PROPERTY_NAME =
    "javax.wsdl.factory.WSDLFactoryCandidate";
  private static final String NS_URI_SOAP =
    "http://schemas.xmlsoap.org/wsdl/soap/";

  private WSDLFactory factory = null;
  private ExtensionRegistry extReg = null;
  private SOAPFault soapFault = null;

  protected void setUp() throws WSDLException, IOException
  {
    // Determine name of JWSDL factory implementation to test.
    String testCandidateName =
      System.getProperty(TEST_CANDIDATE_PROPERTY_NAME);

    if (testCandidateName == null)
    {
      throw new IllegalArgumentException("System property '" +
                                         TEST_CANDIDATE_PROPERTY_NAME +
                                         "' must be specified to run " +
                                         "test suite.");
    }

    factory = WSDLFactory.newInstance(testCandidateName);

    Assert.assertNotNull("WSDLFactory should not be null.", factory);

    extReg = factory.newPopulatedExtensionRegistry();

    Assert.assertNotNull("ExtensionRegistry should not be null.", extReg);

    QName soapFaultQName = new QName(NS_URI_SOAP, "fault");

    soapFault = (SOAPFault)TCKUtils.createExtension(extReg,
                                                    BindingFault.class,
                                                    soapFaultQName,
                                                    SOAPFault.class);
  }

  /**
   * Test SOAPFault.setEncodingStyles(...) and SOAPFault.getEncodingStyles().
   */
  public void testSetGetEncodingStyles()
  {
    List encodingStyles = new Vector();

    soapFault.setEncodingStyles(encodingStyles);

    List encodingStyles2 = soapFault.getEncodingStyles();

    Assert.assertTrue("SOAPFault.getEncodingStyles() did not return " +
                      "the same list that was set using " +
                      "SOAPFault.setEncodingStyles(...).",
                      encodingStyles == encodingStyles2);
  }

  /**
   * Test SOAPFault.setName(...) and SOAPFault.getName().
   */
  public void testSetGetName()
  {
    String name = "abcdef";

    soapFault.setName(name);

    String name2 = soapFault.getName();

    Assert.assertTrue("SOAPFault.getName() did not return " +
                      "the same name that was set using " +
                      "SOAPFault.setName(...).",
                      name.equals(name2));
  }

  /**
   * Test SOAPFault.setNamespaceURI(...) and SOAPFault.getNamespaceURI().
   */
  public void testSetGetNamespaceURI()
  {
    String namespaceURI = "urn:abcdef";

    soapFault.setNamespaceURI(namespaceURI);

    String namespaceURI2 = soapFault.getNamespaceURI();

    Assert.assertTrue("SOAPFault.getNamespaceURI() did not return " +
                      "the same namespace URI that was set using " +
                      "SOAPFault.setNamespaceURI(...).",
                      namespaceURI.equals(namespaceURI2));
  }

  /**
   * Test SOAPFault.setUse(...) and SOAPFault.getUse().
   */
  public void testSetGetUse()
  {
    String use = "encoded";

    soapFault.setUse(use);

    String use2 = soapFault.getUse();

    Assert.assertTrue("SOAPFault.getUse() did not return " +
                      "the same use that was set using " +
                      "SOAPFault.setUse(...).",
                      use.equals(use2));
  }
}