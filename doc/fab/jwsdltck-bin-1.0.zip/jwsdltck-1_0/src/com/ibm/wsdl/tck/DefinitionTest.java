package com.ibm.wsdl.tck;

import java.io.*;
import java.util.*;
import javax.wsdl.*;
import javax.wsdl.extensions.*;
import javax.wsdl.factory.*;
import javax.wsdl.xml.*;
import javax.xml.namespace.*;
import javax.xml.parsers.*;
import junit.framework.*;
import org.w3c.dom.*;

/**
 * This class implements a series of tests used to check
 * javax.wsdl.Definition implementations for compliance
 * with the JWSDL specification.
 *
 * @author Matthew J. Duftler (duftler@us.ibm.com)
 */
public class DefinitionTest extends TestCase
{
  private static final String TEST_CANDIDATE_PROPERTY_NAME =
    "javax.wsdl.factory.WSDLFactoryCandidate";
  private static final String NS_URI_WSDL =
    "http://schemas.xmlsoap.org/wsdl/";

  private WSDLFactory factory = null;
  private Definition definition = null;

  protected void setUp() throws WSDLException
  {
    // Determine name of JWSDL factory implementation to test.
    String testCandidateName =
      System.getProperty(TEST_CANDIDATE_PROPERTY_NAME);

    if (testCandidateName == null)
    {
      throw new IllegalArgumentException("System property '" +
                                         TEST_CANDIDATE_PROPERTY_NAME +
                                         "' must be specified to run " +
                                         "test suite.");
    }

    factory = WSDLFactory.newInstance(testCandidateName);

    Assert.assertNotNull("WSDLFactory should not be null.", factory);

    definition = factory.newDefinition();

    Assert.assertNotNull("Definition should not be null.", definition);
  }

  /**
   * Test Definition.createBinding(), Definition.addBinding(...),
   * Definition.getBinding(...), and Definition.removeBinding(...).
   */
  public void testCreateAddGetRemoveBinding()
  {
    Binding binding = definition.createBinding();

    Assert.assertNotNull("Binding should not be null.", binding);

    QName bindingQName = new QName("urn:abc", "def");

    binding.setQName(bindingQName);
    binding.setUndefined(false);
    definition.addBinding(binding);

    Binding binding2 = definition.getBinding(bindingQName);

    Assert.assertTrue("Definition.getBinding(...) did not return " +
                      "the same Binding that was added using " +
                      "Definition.addBinding(...).",
                      binding == binding2);

    Binding binding3 = definition.removeBinding(bindingQName);

    Assert.assertTrue("Definition.removeBinding(...) did not return " +
                      "the same Binding that was added using " +
                      "Definition.addBinding(...).",
                      binding == binding3);

    Binding binding4 = definition.getBinding(bindingQName);

    Assert.assertNull("Definition.getBinding(...) returned " +
                      "the Binding that was added using " +
                      "Definition.addBinding(...), even though " +
                      "Definition.removeBinding(...) was called.",
                      binding4);
  }

  /**
   * Test Definition.createMessage(), Definition.addMessage(...),
   * Definition.getMessage(...), and Definition.removeMessage(...).
   */
  public void testCreateAddGetRemoveMessage()
  {
    Message message = definition.createMessage();

    Assert.assertNotNull("Message should not be null.", message);

    QName messageQName = new QName("urn:abc", "def");

    message.setQName(messageQName);
    message.setUndefined(false);
    definition.addMessage(message);

    Message message2 = definition.getMessage(messageQName);

    Assert.assertTrue("Definition.getMessage(...) did not return " +
                      "the same Message that was added using " +
                      "Definition.addMessage(...).",
                      message == message2);

    Message message3 = definition.removeMessage(messageQName);

    Assert.assertTrue("Definition.removeMessage(...) did not return " +
                      "the same Message that was added using " +
                      "Definition.addMessage(...).",
                      message == message3);

    Message message4 = definition.getMessage(messageQName);

    Assert.assertNull("Definition.getMessage(...) returned " +
                      "the Message that was added using " +
                      "Definition.addMessage(...), even though " +
                      "Definition.removeMessage(...) was called.",
                      message4);
  }

  /**
   * Test Definition.createPortType(), Definition.addPortType(...),
   * Definition.getPortType(...), and Definition.removePortType(...).
   */
  public void testCreateAddGetRemovePortType()
  {
    PortType portType = definition.createPortType();

    Assert.assertNotNull("PortType should not be null.", portType);

    QName portTypeQName = new QName("urn:abc", "def");

    portType.setQName(portTypeQName);
    definition.addPortType(portType);

    PortType portType2 = definition.getPortType(portTypeQName);

    Assert.assertTrue("Definition.getPortType(...) did not return " +
                      "the same PortType that was added using " +
                      "Definition.addPortType(...).",
                      portType == portType2);

    PortType portType3 = definition.removePortType(portTypeQName);

    Assert.assertTrue("Definition.removePortType(...) did not return " +
                      "the same PortType that was added using " +
                      "Definition.addPortType(...).",
                      portType == portType3);

    PortType portType4 = definition.getPortType(portTypeQName);

    Assert.assertNull("Definition.getPortType(...) returned " +
                      "the PortType that was added using " +
                      "Definition.addPortType(...), even though " +
                      "Definition.removePortType(...) was called.",
                      portType4);
  }

  /**
   * Test Definition.createService(), Definition.addService(...),
   * Definition.getService(...), and Definition.removeService(...).
   */
  public void testCreateAddGetRemoveService()
  {
    Service service = definition.createService();

    Assert.assertNotNull("Service should not be null.", service);

    QName serviceQName = new QName("urn:abc", "def");

    service.setQName(serviceQName);
    definition.addService(service);

    Service service2 = definition.getService(serviceQName);

    Assert.assertTrue("Definition.getService(...) did not return " +
                      "the same Service that was added using " +
                      "Definition.addService(...).",
                      service == service2);

    Service service3 = definition.removeService(serviceQName);

    Assert.assertTrue("Definition.removeService(...) did not return " +
                      "the same Service that was added using " +
                      "Definition.addService(...).",
                      service == service3);

    Service service4 = definition.getService(serviceQName);

    Assert.assertNull("Definition.getService(...) returned " +
                      "the Service that was added using " +
                      "Definition.addService(...), even though " +
                      "Definition.removeService(...) was called.",
                      service4);
  }

  /**
   * Test Definition.createTypes(), Definition.setTypes(...),
   * and Definition.getTypes().
   */
  public void testCreateSetGetTypes()
  {
    Types types = definition.createTypes();

    Assert.assertNotNull("Types should not be null.", types);

    definition.setTypes(types);

    Types types2 = definition.getTypes();

    Assert.assertTrue("Definition.getTypes() did not return " +
                      "the same Types that was set using " +
                      "Definition.setTypes(...).",
                      types == types2);
  }

  /**
   * Test Definition.createImport(), Definition.addImport(...),
   * and Definition.getImports(...).
   */
  public void testCreateAddGetImport()
  {
    Import testImport = definition.createImport();

    Assert.assertNotNull("Import should not be null.", testImport);

    String namespaceURI = "urn:abc";

    testImport.setNamespaceURI(namespaceURI);
    definition.addImport(testImport);

    List imports = definition.getImports(namespaceURI);

    Assert.assertNotNull("Imports list should not be null.", imports);

    Assert.assertTrue("Definition.getImports(...) returned a list " +
                      "that did not contain the Import added using " +
                      "Definition.addImport(...).",
                      imports.contains(testImport));
  }

  /**
   * Test Definition.createBindingFault().
   */
  public void testCreateBindingFault()
  {
    BindingFault bindingFault = definition.createBindingFault();

    Assert.assertNotNull("BindingFault should not be null.", bindingFault);
  }

  /**
   * Test Definition.createBindingInput().
   */
  public void testCreateBindingInput()
  {
    BindingInput bindingInput = definition.createBindingInput();

    Assert.assertNotNull("BindingInput should not be null.", bindingInput);
  }

  /**
   * Test Definition.createBindingOperation().
   */
  public void testCreateBindingOperation()
  {
    BindingOperation bindingOperation = definition.createBindingOperation();

    Assert.assertNotNull("BindingOperation should not be null.",
                         bindingOperation);
  }

  /**
   * Test Definition.createBindingOutput().
   */
  public void testCreateBindingOutput()
  {
    BindingOutput bindingOutput = definition.createBindingOutput();

    Assert.assertNotNull("BindingOutput should not be null.", bindingOutput);
  }

  /**
   * Test Definition.createFault().
   */
  public void testCreateFault()
  {
    Fault fault = definition.createFault();

    Assert.assertNotNull("Fault should not be null.", fault);
  }

  /**
   * Test Definition.createInput().
   */
  public void testCreateInput()
  {
    Input input = definition.createInput();

    Assert.assertNotNull("Input should not be null.", input);
  }

  /**
   * Test Definition.createOperation().
   */
  public void testCreateOperation()
  {
    Operation operation = definition.createOperation();

    Assert.assertNotNull("Operation should not be null.", operation);
  }

  /**
   * Test Definition.createOutput().
   */
  public void testCreateOutput()
  {
    Output output = definition.createOutput();

    Assert.assertNotNull("Output should not be null.", output);
  }

  /**
   * Test Definition.createPart().
   */
  public void testCreatePart()
  {
    Part part = definition.createPart();

    Assert.assertNotNull("Part should not be null.", part);
  }

  /**
   * Test Definition.createPort().
   */
  public void testCreatePort()
  {
    Port port = definition.createPort();

    Assert.assertNotNull("Port should not be null.", port);
  }

  /**
   * Test Definition.addNamespace(...), Definition.getNamespace(...),
   * and Definition.getPrefix(...). Test support for default namespace
   * declarations.
   */
  public void testAddGetNamespaceAndPrefix()
  {
    String prefix = "abc";
    String namespaceURI = "urn:def";

    definition.addNamespace(prefix, namespaceURI);

    String namespaceURI2 = definition.getNamespace(prefix);

    Assert.assertTrue("Definition.getNamespace(...) did not return " +
                      "the same namespace URI that was added using " +
                      "Definition.addNamespace(...).",
                      namespaceURI.equals(namespaceURI2));

    String defaultNamespaceURI = definition.getNamespace(null);

    Assert.assertTrue("Definition.getNamespace(null) returned '" +
                      defaultNamespaceURI + "', instead of the expected '" +
                      NS_URI_WSDL + "'.",
                      NS_URI_WSDL.equals(defaultNamespaceURI));

    String namespaceURI3 = "abcdef";

    definition.addNamespace(null, namespaceURI3);

    String namespaceURI4 = definition.getNamespace(null);

    Assert.assertTrue("Definition.getNamespace(null) did not return " +
                      "the same namespace URI that was added using " +
                      "Definition.addNamespace(null, ...).",
                      namespaceURI3.equals(namespaceURI4));

    String prefix2 = definition.getPrefix(namespaceURI);

    Assert.assertTrue("Definition.getPrefix(...) did not return " +
                      "the same prefix that was added using " +
                      "Definition.addNamespace(...).",
                      prefix.equals(prefix2));
  }

  /**
   * Test Definition.setQName(...) and Definition.getQName().
   */
  public void testSetGetQName()
  {
    QName qname = new QName("urn:abc", "def");

    definition.setQName(qname);

    QName qname2 = definition.getQName();

    Assert.assertTrue("Definition.getQName() did not return " +
                      "the same QName that was set using " +
                      "Definition.setQName(...).",
                      qname.equals(qname2));
  }

  /**
   * Test Definition.setTargetNamespace(...) and
   * Definition.getTargetNamespace().
   */
  public void testSetGetTargetNamespace()
  {
    String targetNamespace = "urn:abceefghi";

    definition.setTargetNamespace(targetNamespace);

    String targetNamespace2 = definition.getTargetNamespace();

    Assert.assertTrue("Definition.getTargetNamespace() did not return " +
                      "the same namespace URI that was set using " +
                      "Definition.setTargetNamespace(...).",
                      targetNamespace.equals(targetNamespace2));
  }

  /**
   * Test Definition.setDocumentBaseURI(...) and
   * Definition.getDocumentBaseURI().
   */
  public void testSetGetDocumentBaseURI()
  {
    String documentBaseURI = "urn:abceefghi";

    definition.setDocumentBaseURI(documentBaseURI);

    String documentBaseURI2 = definition.getDocumentBaseURI();

    Assert.assertTrue("Definition.getDocumentBaseURI() did not return " +
                      "the same document base URI that was set using " +
                      "Definition.setDocumentBaseURI(...).",
                      documentBaseURI.equals(documentBaseURI2));
  }

  /**
   * Test Definition.setDocumentationElement(...) and
   * Definition.getDocumentationElement().
   */
  public void testSetGetDocumentationElement()
    throws ParserConfigurationException
  {
    DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();

    factory.setNamespaceAware(true);
    factory.setValidating(false);

    DocumentBuilder builder = factory.newDocumentBuilder();
    Document doc = builder.newDocument();
    Element el = doc.createElementNS(NS_URI_WSDL,
                                     "wsdl:documentation");

    definition.setDocumentationElement(el);

    Element el2 = definition.getDocumentationElement();

    Assert.assertTrue("Definition.getDocumentationElement() did not return " +
                      "the same Element that was set using " +
                      "Definition.setDocumentationElement(...).",
                      el == el2);
  }

  /**
   * Test Definition.setExtensionRegistry(...) and
   * Definition.getExtensionRegistry().
   */
  public void testSetGetExtensionRegistry()
  {
    ExtensionRegistry extReg = factory.newPopulatedExtensionRegistry();

    Assert.assertNotNull("ExtensionRegistry should not be null.", extReg);

    definition.setExtensionRegistry(extReg);

    ExtensionRegistry extReg2 = definition.getExtensionRegistry();

    Assert.assertTrue("Definition.getExtensionRegistry() did not return " +
                      "the same ExtensionRegistry that was set using " +
                      "Definition.setExtensionRegistry(...).",
                      extReg == extReg2);
  }
}