package com.ibm.wsdl.tck.soap;

import com.ibm.wsdl.tck.util.*;
import java.io.*;
import java.util.*;
import javax.wsdl.*;
import javax.wsdl.extensions.*;
import javax.wsdl.extensions.soap.*;
import javax.wsdl.factory.*;
import javax.wsdl.xml.*;
import javax.xml.namespace.*;
import junit.framework.*;

/**
 * This class implements a series of tests used to check
 * javax.wsdl.extensions.soap.SOAPBody implementations
 * for compliance with the JWSDL specification.
 *
 * @author Matthew J. Duftler (duftler@us.ibm.com)
 */
public class SOAPBodyTest extends TestCase
{
  private static final String TEST_CANDIDATE_PROPERTY_NAME =
    "javax.wsdl.factory.WSDLFactoryCandidate";
  private static final String NS_URI_SOAP =
    "http://schemas.xmlsoap.org/wsdl/soap/";

  private WSDLFactory factory = null;
  private ExtensionRegistry extReg = null;
  private SOAPBody soapBody = null;

  protected void setUp() throws WSDLException, IOException
  {
    // Determine name of JWSDL factory implementation to test.
    String testCandidateName =
      System.getProperty(TEST_CANDIDATE_PROPERTY_NAME);

    if (testCandidateName == null)
    {
      throw new IllegalArgumentException("System property '" +
                                         TEST_CANDIDATE_PROPERTY_NAME +
                                         "' must be specified to run " +
                                         "test suite.");
    }

    factory = WSDLFactory.newInstance(testCandidateName);

    Assert.assertNotNull("WSDLFactory should not be null.", factory);

    extReg = factory.newPopulatedExtensionRegistry();

    Assert.assertNotNull("ExtensionRegistry should not be null.", extReg);

    QName soapBodyQName = new QName(NS_URI_SOAP, "body");

    soapBody = (SOAPBody)TCKUtils.createExtension(extReg,
                                                  BindingInput.class,
                                                  soapBodyQName,
                                                  SOAPBody.class);
  }

  /**
   * Test SOAPBody.setEncodingStyles(...) and SOAPBody.getEncodingStyles().
   */
  public void testSetGetEncodingStyles()
  {
    List encodingStyles = new Vector();

    soapBody.setEncodingStyles(encodingStyles);

    List encodingStyles2 = soapBody.getEncodingStyles();

    Assert.assertTrue("SOAPBody.getEncodingStyles() did not return " +
                      "the same list that was set using " +
                      "SOAPBody.setEncodingStyles(...).",
                      encodingStyles == encodingStyles2);
  }

  /**
   * Test SOAPBody.setNamespaceURI(...) and SOAPBody.getNamespaceURI().
   */
  public void testSetGetNamespaceURI()
  {
    String namespaceURI = "urn:abcdef";

    soapBody.setNamespaceURI(namespaceURI);

    String namespaceURI2 = soapBody.getNamespaceURI();

    Assert.assertTrue("SOAPBody.getNamespaceURI() did not return " +
                      "the same namespace URI that was set using " +
                      "SOAPBody.setNamespaceURI(...).",
                      namespaceURI.equals(namespaceURI2));
  }

  /**
   * Test SOAPBody.setParts(...) and SOAPBody.getParts().
   */
  public void testSetGetParts()
  {
    List parts = new Vector();

    soapBody.setParts(parts);

    List parts2 = soapBody.getParts();

    Assert.assertTrue("SOAPBody.getParts() did not return " +
                      "the same list that was set using " +
                      "SOAPBody.setParts(...).",
                      parts == parts2);
  }

  /**
   * Test SOAPBody.setUse(...) and SOAPBody.getUse().
   */
  public void testSetGetUse()
  {
    String use = "encoded";

    soapBody.setUse(use);

    String use2 = soapBody.getUse();

    Assert.assertTrue("SOAPBody.getUse() did not return " +
                      "the same use that was set using " +
                      "SOAPBody.setUse(...).",
                      use.equals(use2));
  }
}