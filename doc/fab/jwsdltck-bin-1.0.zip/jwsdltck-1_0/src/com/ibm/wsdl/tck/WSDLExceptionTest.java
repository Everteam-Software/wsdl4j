package com.ibm.wsdl.tck;

import javax.wsdl.*;
import javax.wsdl.extensions.*;
import javax.wsdl.factory.*;
import javax.wsdl.xml.*;
import javax.xml.namespace.*;
import javax.xml.parsers.*;
import junit.framework.*;
import org.w3c.dom.*;

/**
 * This class implements a series of tests used to check
 * javax.wsdl.WSDLException implementations for compliance
 * with the JWSDL specification.
 *
 * @author Matthew J. Duftler (duftler@us.ibm.com)
 */
public class WSDLExceptionTest extends TestCase
{
  private static final String TEST_CANDIDATE_PROPERTY_NAME =
    "javax.wsdl.factory.WSDLFactoryCandidate";
  private static final String NS_URI_WSDL =
    "http://schemas.xmlsoap.org/wsdl/";

  private Definition definition = null;
  private WSDLException wsdlException = null;

  protected void setUp() throws WSDLException
  {
    // Determine name of JWSDL factory implementation to test.
    String testCandidateName =
      System.getProperty(TEST_CANDIDATE_PROPERTY_NAME);

    if (testCandidateName == null)
    {
      throw new IllegalArgumentException("System property '" +
                                         TEST_CANDIDATE_PROPERTY_NAME +
                                         "' must be specified to run " +
                                         "test suite.");
    }

    WSDLFactory factory = WSDLFactory.newInstance(testCandidateName);

    Assert.assertNotNull("WSDLFactory should not be null.", factory);

    definition = factory.newDefinition();

    Assert.assertNotNull("Definition should not be null.", definition);

    wsdlException = new WSDLException(WSDLException.OTHER_ERROR,
                                      "Testing...");
  }

  /**
   * Test WSDLException.setFaultCode(...) and WSDLException.getFaultCode().
   */
  public void testSetGetFaultCode()
  {
    String faultCode = WSDLException.CONFIGURATION_ERROR;

    wsdlException.setFaultCode(faultCode);

    String faultCode2 = wsdlException.getFaultCode();

    Assert.assertTrue("WSDLException.getFaultCode() did not return " +
                      "the same fault code that was set using " +
                      "WSDLException.setFaultCode(...).",
                      faultCode.equals(faultCode2));
  }

  /**
   * Test WSDLException.setLocation(...) and WSDLException.getLocation().
   */
  public void testSetGetLocation()
  {
    String location = "/wsdl:definitions";

    wsdlException.setLocation(location);

    String location2 = wsdlException.getLocation();

    Assert.assertTrue("WSDLException.getLocation() did not return " +
                      "the same location that was set using " +
                      "WSDLException.setLocation(...).",
                      location.equals(location2));
  }

  /**
   * Test WSDLException.setTargetException(...) and
   * WSDLException.getTargetException().
   */
  public void testSetGetTargetException()
  {
    Throwable targetException =
      new IllegalArgumentException("More testing...");

    wsdlException.setTargetException(targetException);

    Throwable targetException2 = wsdlException.getTargetException();

    Assert.assertTrue("WSDLException.getTargetException() did not return " +
                      "the same throwable that was set using " +
                      "WSDLException.setTargetException(...).",
                      targetException == targetException2);
  }
}