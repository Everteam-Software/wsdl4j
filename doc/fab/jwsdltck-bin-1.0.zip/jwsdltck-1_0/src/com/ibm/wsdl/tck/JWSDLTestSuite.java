package com.ibm.wsdl.tck;

import com.ibm.wsdl.tck.http.*;
import com.ibm.wsdl.tck.mime.*;
import com.ibm.wsdl.tck.soap.*;
import junit.framework.*;
import junit.textui.*;

/**
 * This class combines all the tests contained in the JWSDL TCK
 * into one JUnit test suite.
 *
 * @author Matthew J. Duftler (duftler@us.ibm.com)
 */
public class JWSDLTestSuite extends TestCase
{
  public static Test suite()
  {
    TestSuite testSuite = new TestSuite();

    testSuite.addTestSuite(SignatureTest.class);
    testSuite.addTestSuite(FactoryTest.class);
    testSuite.addTestSuite(FactoryTest2.class);
    testSuite.addTestSuite(DefinitionTest.class);
    testSuite.addTestSuite(ExtensionRegistryTest.class);
    testSuite.addTestSuite(BindingTest.class);
    testSuite.addTestSuite(BindingFaultTest.class);
    testSuite.addTestSuite(BindingInputTest.class);
    testSuite.addTestSuite(BindingOperationTest.class);
    testSuite.addTestSuite(BindingOutputTest.class);
    testSuite.addTestSuite(FaultTest.class);
    testSuite.addTestSuite(ImportTest.class);
    testSuite.addTestSuite(InputTest.class);
    testSuite.addTestSuite(MessageTest.class);
    testSuite.addTestSuite(OperationTest.class);
    testSuite.addTestSuite(OutputTest.class);
    testSuite.addTestSuite(PartTest.class);
    testSuite.addTestSuite(PortTest.class);
    testSuite.addTestSuite(PortTypeTest.class);
    testSuite.addTestSuite(ServiceTest.class);
    testSuite.addTestSuite(TypesTest.class);
    testSuite.addTestSuite(WSDLExceptionTest.class);
    testSuite.addTestSuite(WSDLReaderTest.class);
    testSuite.addTestSuite(WSDLWriterTest.class);
    testSuite.addTestSuite(HTTPAddressTest.class);
    testSuite.addTestSuite(HTTPBindingTest.class);
    testSuite.addTestSuite(HTTPOperationTest.class);
    testSuite.addTestSuite(MIMEContentTest.class);
    testSuite.addTestSuite(MIMEMimeXmlTest.class);
    testSuite.addTestSuite(MIMEMultipartRelatedTest.class);
    testSuite.addTestSuite(SOAPAddressTest.class);
    testSuite.addTestSuite(SOAPBindingTest.class);
    testSuite.addTestSuite(SOAPBodyTest.class);
    testSuite.addTestSuite(SOAPFaultTest.class);
    testSuite.addTestSuite(SOAPHeaderTest.class);
    testSuite.addTestSuite(SOAPHeaderFaultTest.class);
    testSuite.addTestSuite(SOAPOperationTest.class);

    return testSuite;
  }

  public static void main(String[] argv)
  {
    TestResult testResult = new TestResult();
    TestSuite suite1 = new TestSuite(FactoryTest.class);

    suite1.run(testResult);

    if (testResult.errorCount() > 0)
    {
      TestFailure testFailure =
        (TestFailure)testResult.errors().nextElement();

      System.err.println("Error: " + testFailure.failedTest() + ": " +
                         testFailure.thrownException());
    }
    else if (testResult.failureCount() > 0)
    {
      TestFailure testFailure =
        (TestFailure)testResult.failures().nextElement();

      System.err.println("Failure: " + testResult.failures().nextElement());
    }
    else
    {
      TestRunner.run(suite());
    }
  }
}