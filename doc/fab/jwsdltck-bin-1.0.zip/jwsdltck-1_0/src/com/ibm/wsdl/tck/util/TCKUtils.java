package com.ibm.wsdl.tck.util;

import java.io.*;
import java.util.*;
import javax.wsdl.*;
import javax.wsdl.extensions.*;
import javax.wsdl.extensions.soap.*;
import javax.xml.namespace.*;
import javax.xml.parsers.*;
import junit.framework.*;
import org.w3c.dom.*;
import org.xml.sax.*;

/**
 * This class implements static utility methods for use by the various
 * TCK tests.
 *
 * @author Matthew J. Duftler (duftler@us.ibm.com)
 */
public class TCKUtils
{
  public static void walkDefinition(Definition definition) throws WSDLException
  {
    String targetNamespace = "http://www.ibm.com/namespace/wsif/samples/ab";

    Assert.assertTrue("Definition.getTargetNamespace() did not return '" +
                      targetNamespace + "'.",
                      targetNamespace.equals(definition.getTargetNamespace()));

    Service service = definition.getService(new QName(targetNamespace,
                                                      "AddressBookService"));

    Assert.assertNotNull("Definition.getService(new QName(\"" +
                         targetNamespace + "\", \"AddressBookService\")) " +
                         "should not return null.",
                         service);

    Port port = service.getPort("SOAPPort");

    Assert.assertNotNull("Service.getPort(\"SOAPPort\") should not " +
                         "return null.",
                         port);

    SOAPAddress soapAddress =
      (SOAPAddress)checkExtensibilityElements(
        "Port",
        port.getExtensibilityElements());
    Binding binding = port.getBinding();

    Assert.assertNotNull("Port.getBinding() should not return null.",
                         binding);

    Assert.assertFalse("Binding.isUndefined() should return false.",
                       binding.isUndefined());

    Binding binding2 = definition.getBinding(new QName(targetNamespace,
                                                       "SOAPBinding"));

    Assert.assertTrue("Definition.getBinding(new QName(\"" +
                      targetNamespace + "\", \"SOAPBinding\")) did not " +
                      "return the same binding as port.getBinding().",
                      binding == binding2);

    SOAPBinding soapBinding =
      (SOAPBinding)checkExtensibilityElements(
        "Binding",
        binding.getExtensibilityElements());
    BindingOperation bindingOperation =
      binding.getBindingOperation("addEntry", null, null);

    Assert.assertNotNull("Binding.getBindingOperation(\"addEntry\", " +
                         "null, null) should not return null.",
                         bindingOperation);

    SOAPOperation soapOperation =
      (SOAPOperation)checkExtensibilityElements(
        "BindingOperation",
        bindingOperation.getExtensibilityElements());

    BindingInput bindingInput = bindingOperation.getBindingInput();

    Assert.assertNotNull("BindingOperation.getBindingInput() should not " +
                         "return null.",
                         bindingInput);

    SOAPBody soapBody =
      (SOAPBody)checkExtensibilityElements(
        "BindingInput",
        bindingInput.getExtensibilityElements());

    BindingOutput bindingOutput = bindingOperation.getBindingOutput();

    Assert.assertNotNull("BindingOperation.getBindingOutput() should not " +
                         "return null.",
                         bindingOutput);

    soapBody =
      (SOAPBody)checkExtensibilityElements(
        "BindingOutput",
        bindingOutput.getExtensibilityElements());

    BindingOperation bindingOperation2 =
      binding.getBindingOperation("getAddressFromName", null, null);

    Assert.assertNotNull("Binding.getBindingOperation(" +
                         "\"getAddressFromName\", null, null) " +
                         "should not return null.",
                         bindingOperation2);

    SOAPOperation soapOperation2 =
      (SOAPOperation)checkExtensibilityElements(
        "BindingOperation",
        bindingOperation2.getExtensibilityElements());

    BindingInput bindingInput2 = bindingOperation2.getBindingInput();

    Assert.assertNotNull("BindingOperation.getBindingInput() should not " +
                         "return null.",
                         bindingInput2);

    SOAPBody soapBody2 =
      (SOAPBody)checkExtensibilityElements(
        "BindingInput",
        bindingInput2.getExtensibilityElements());

    BindingOutput bindingOutput2 = bindingOperation2.getBindingOutput();

    Assert.assertNotNull("BindingOperation.getBindingOutput() should not " +
                         "return null.",
                         bindingOutput2);

    soapBody2 =
      (SOAPBody)checkExtensibilityElements(
        "BindingOutput",
        bindingOutput2.getExtensibilityElements());

    PortType portType = binding.getPortType();

    Assert.assertNotNull("Binding.getPortType() should not return null.",
                         portType);

    Assert.assertFalse("PortType.isUndefined() should return false.",
                       portType.isUndefined());

    PortType portType2 = definition.getPortType(new QName(targetNamespace,
                                                          "AddressBook"));

    Assert.assertTrue("Definition.getPortType(new QName(\"" +
                      targetNamespace + "\", \"AddressBook\")) did not " +
                      "return the same portType as binding.getPortType().",
                      portType == portType2);

    Operation operation = portType.getOperation("addEntry", null, null);

    Assert.assertNotNull("PortType.getOperation(\"addEntry\", null, null) " +
                         "should not return null.",
                         operation);

    Assert.assertFalse("Operation.isUndefined() should return false.",
                       operation.isUndefined());

    Assert.assertTrue("PortType.getOperation(\"addEntry\", null, null) " +
                      "did not return the same operation as " +
                      "bindingOperation.getOperation().",
                      operation == bindingOperation.getOperation());

    OperationType style = operation.getStyle();

    Assert.assertTrue("Operation.getStyle() did not return " +
                      "OperationType.REQUEST_RESPONSE.",
                      style == OperationType.REQUEST_RESPONSE);

    Input input = operation.getInput();

    Assert.assertNotNull("Operation.getInput() should not return null.",
                         input);

    Message message = input.getMessage();

    Assert.assertNotNull("Input.getMessage() should not return null.",
                         message);

    Assert.assertFalse("Message.isUndefined() should return false.",
                       message.isUndefined());

    Message message2 = definition.getMessage(new QName(targetNamespace,
                                                       "AddEntryRequest"));

    Assert.assertTrue("Definition.getMessage(new QName(\"" +
                      targetNamespace + "\", \"AddEntryRequest\")) did not " +
                      "return the same message as input.getMessage().",
                      message == message2);

    Part part = message.getPart("name");

    Assert.assertNotNull("Message.getPart(\"name\") should not return null.",
                         part);

    part = message.getPart("address");

    Assert.assertNotNull("Message.getPart(\"address\") should not return " +
                         "null.",
                         part);

    Output output = operation.getOutput();

    Assert.assertNotNull("Operation.getOutput() should not return null.",
                         output);

    message = output.getMessage();

    Assert.assertNotNull("Output.getMessage() should not return null.",
                         message);

    Assert.assertFalse("Message.isUndefined() should return false.",
                       message.isUndefined());

    message2 = definition.getMessage(new QName(targetNamespace,
                                               "AddEntryResponse"));

    Assert.assertTrue("Definition.getMessage(new QName(\"" +
                      targetNamespace + "\", \"AddEntryResponse\")) did not " +
                      "return the same message as output.getMessage().",
                      message == message2);

    Operation operation2 = portType.getOperation("getAddressFromName",
                                                 null,
                                                 null);

    Assert.assertNotNull("PortType.getOperation(\"getAddressFromName\", " +
                         "null, null) should not return null.",
                         operation2);

    Assert.assertFalse("Operation.isUndefined() should return false.",
                       operation2.isUndefined());

    Assert.assertTrue("PortType.getOperation(\"getAddressFromName\", " +
                      "null, null) did not return the same operation as " +
                      "bindingOperation.getOperation().",
                      operation2 == bindingOperation2.getOperation());

    OperationType style2 = operation2.getStyle();

    Assert.assertTrue("Operation.getStyle() did not return " +
                      "OperationType.REQUEST_RESPONSE.",
                      style2 == OperationType.REQUEST_RESPONSE);

    Input input2 = operation2.getInput();

    Assert.assertNotNull("Operation.getInput() should not return null.",
                         input2);

    message = input2.getMessage();

    Assert.assertNotNull("Input.getMessage() should not return null.",
                         message);

    Assert.assertFalse("Message.isUndefined() should return false.",
                       message.isUndefined());

    message2 = definition.getMessage(new QName(targetNamespace,
                                               "GetAddressFromNameRequest"));

    Assert.assertTrue("Definition.getMessage(new QName(\"" + targetNamespace +
                      "\", \"GetAddressFromNameRequest\")) did not " +
                      "return the same message as input.getMessage().",
                      message == message2);

    part = message.getPart("name");

    Assert.assertNotNull("Message.getPart(\"name\") should not return null.",
                         part);

    Output output2 = operation2.getOutput();

    Assert.assertNotNull("Operation.getOutput() should not return null.",
                         output2);

    message = output2.getMessage();

    Assert.assertNotNull("Output.getMessage() should not return null.",
                         message);

    Assert.assertFalse("Message.isUndefined() should return false.",
                       message.isUndefined());

    message2 = definition.getMessage(new QName(targetNamespace,
                                               "GetAddressFromNameResponse"));

    Assert.assertTrue("Definition.getMessage(new QName(\"" +
                      targetNamespace + "\", \"GetAddressFromNameResponse\")) did not " +
                      "return the same message as output.getMessage().",
                      message == message2);

    part = message.getPart("address");

    Assert.assertNotNull("Message.getPart(\"address\") should not return " +
                         "null.",
                         part);

    Types types = definition.getTypes();

    if (types == null)
    {
      List imports = definition.getImports(targetNamespace);

      if (imports != null && imports.size() == 1)
      {
        Import theImport = (Import)imports.get(0);

        Assert.assertNotNull("imports.get(0) should not return null.",
                             theImport);

        Definition importedDef = theImport.getDefinition();

        Assert.assertNotNull("theImport.getDefinition() should not return " +
                             "null.",
                             importedDef);

        types = importedDef.getTypes();

        Assert.assertNotNull("importedDefinition.getTypes() should not " +
                             "return null.",
                             types);
      }
    }

    Assert.assertNotNull("Definition.getTypes() should not return null.",
                         types);

    ExtensibilityElement extElement =
      checkExtensibilityElements("Types", types.getExtensibilityElements());
    QName schemaQName = new QName("http://www.w3.org/2001/XMLSchema",
                                  "schema");

    Assert.assertTrue("The extensibility element contained within the " +
                      "types should return '" + schemaQName + "' when " +
                      "ExtensibilityElement.getElementType() is called.",
                      schemaQName.equals(extElement.getElementType()));

    if (extElement instanceof UnknownExtensibilityElement)
    {
      UnknownExtensibilityElement unkExtElment =
        (UnknownExtensibilityElement)extElement;
      Element schemaEl = unkExtElment.getElement();

      Assert.assertNotNull("UnknownExtensibilityElement.getElement() should " +
                           "not return null.",
                           schemaEl);

      QName schemaQName2 = new QName(schemaEl.getNamespaceURI(),
                                     schemaEl.getLocalName());
      Assert.assertTrue("The unknown extensibility element contained within " +
                        "the types should return a '" + schemaQName +
                        "' Element when " +
                        "UnknownExtensibilityElement.getElement() is called.",
                        schemaQName.equals(schemaQName2));
    }
  }

  private static ExtensibilityElement checkExtensibilityElements(
    String parentTypeName,
    List extElements)
  {
    Assert.assertNotNull(parentTypeName + ".getExtensibilityElements() " +
                         "should not return null.",
                         extElements);

    int size = extElements.size();

    Assert.assertTrue(parentTypeName + ".getExtensibilityElements() " +
                      "returned a list containing " + size +
                      " items, instead of 1.",
                      size == 1);

    return (ExtensibilityElement)extElements.get(0);
  }

  public static Document getDocument(String fileName)
    throws IOException,
           ParserConfigurationException,
           SAXException
  {
    FileReader fileReader = new FileReader(fileName);
    InputSource inputSource = new InputSource(fileReader);
    DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();

    factory.setNamespaceAware(true);
    factory.setValidating(false);

    DocumentBuilder builder = factory.newDocumentBuilder();
    Document doc = builder.parse(inputSource);

    fileReader.close();

    return doc;
  }

  public static ExtensibilityElement createExtension(ExtensionRegistry extReg,
                                                     Class parentType,
                                                     QName elementType,
                                                     Class extType)
  {
    try
    {
      ExtensibilityElement ext = extReg.createExtension(parentType,
                                                        elementType);

      Assert.assertNotNull("No Java extensionType found " +
                           "to represent a '" + elementType +
                           "' element in the context of a '" +
                           parentType.getName() + "'.",
                           ext);

      Assert.assertTrue("The Java extensionType '" +
                        ext.getClass().getName() + "' does " +
                        "not implement the '" + extType.getName() +
                        "' interface.",
                        extType.isAssignableFrom(ext.getClass()));

      Assert.assertTrue("The extensibility element should return '" +
                        elementType + "' when " +
                        "ExtensibilityElement.getElementType() is called.",
                        elementType.equals(ext.getElementType()));

      return ext;
    }
    catch (WSDLException e)
    {
      Assert.fail(e.getMessage());

      return null;
    }
  }
}