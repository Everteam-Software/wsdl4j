package com.ibm.wsdl.tck.soap;

import com.ibm.wsdl.tck.util.*;
import java.io.*;
import java.util.*;
import javax.wsdl.*;
import javax.wsdl.extensions.*;
import javax.wsdl.extensions.soap.*;
import javax.wsdl.factory.*;
import javax.wsdl.xml.*;
import javax.xml.namespace.*;
import junit.framework.*;

/**
 * This class implements a series of tests used to check
 * javax.wsdl.extensions.soap.SOAPOperation implementations
 * for compliance with the JWSDL specification.
 *
 * @author Matthew J. Duftler (duftler@us.ibm.com)
 */
public class SOAPOperationTest extends TestCase
{
  private static final String TEST_CANDIDATE_PROPERTY_NAME =
    "javax.wsdl.factory.WSDLFactoryCandidate";
  private static final String NS_URI_SOAP =
    "http://schemas.xmlsoap.org/wsdl/soap/";

  private WSDLFactory factory = null;
  private ExtensionRegistry extReg = null;
  private SOAPOperation soapOperation = null;

  protected void setUp() throws WSDLException, IOException
  {
    // Determine name of JWSDL factory implementation to test.
    String testCandidateName =
      System.getProperty(TEST_CANDIDATE_PROPERTY_NAME);

    if (testCandidateName == null)
    {
      throw new IllegalArgumentException("System property '" +
                                         TEST_CANDIDATE_PROPERTY_NAME +
                                         "' must be specified to run " +
                                         "test suite.");
    }

    factory = WSDLFactory.newInstance(testCandidateName);

    Assert.assertNotNull("WSDLFactory should not be null.", factory);

    extReg = factory.newPopulatedExtensionRegistry();

    Assert.assertNotNull("ExtensionRegistry should not be null.", extReg);

    QName soapOperationQName = new QName(NS_URI_SOAP, "operation");

    soapOperation =
      (SOAPOperation)TCKUtils.createExtension(extReg,
                                              BindingOperation.class,
                                              soapOperationQName,
                                              SOAPOperation.class);
  }

  /**
   * Test SOAPOperation.addSoapActionURI(...) and
   * SOAPOperation.getSoapActionURI(...).
   */
  public void testSetGetSoapActionURI()
  {
    String soapActionURI = "urn:abcdef";

    soapOperation.setSoapActionURI(soapActionURI);

    String soapActionURI2 = soapOperation.getSoapActionURI();

    Assert.assertTrue("SOAPOperation.getSoapActionURI() did not return " +
                      "the same soapAction URI that was set using " +
                      "SOAPOperation.setSoapActionURI(...).",
                      soapActionURI.equals(soapActionURI2));
  }

  /**
   * Test SOAPOperation.setStyle(...) and SOAPOperation.getStyle(...).
   */
  public void testSetGetStyle()
  {
    String style = "abcdef";

    soapOperation.setStyle(style);

    String style2 = soapOperation.getStyle();

    Assert.assertTrue("SOAPOperation.getStyle() did not return " +
                      "the same style that was set using " +
                      "SOAPOperation.setStyle(...).",
                      style.equals(style2));
  }
}