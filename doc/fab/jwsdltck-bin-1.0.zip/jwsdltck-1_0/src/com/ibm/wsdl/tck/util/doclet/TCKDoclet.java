package com.ibm.wsdl.tck.util.doclet;

import com.sun.javadoc.*;
import java.io.*;
import java.util.*;

/**
 * This class implements a Doclet that is used to generate TCK documentation
 * from JavaDoc comments.
 *
 * @author Matthew J. Duftler (duftler@us.ibm.com)
 */
public class TCKDoclet
{
  public static boolean start(RootDoc root) throws IOException
  {
    FileWriter fw = new FileWriter("doc/test_descriptions.html");
    PrintWriter pw = new PrintWriter(fw);
    ClassDoc[] classes = root.classes();
    Comparator comparator =
    new Comparator()
    {
      public int compare(Object o1, Object o2)
      {
        return ((ClassDoc)o1).typeName().compareTo(((ClassDoc)o2).typeName());
      }
    };

    Arrays.sort(classes, comparator);

    List missingCommentList = new Vector();

    pw.println("<html>");
    pw.println("  <head>");
    pw.println("    <style type=\"text/css\">");
    pw.println("      <!--");
    pw.println("        .javaClassName  " +
               "{ font-family: monospace; text-align: center }");
    pw.println("       -->");
    pw.println("    </style>");
    pw.println("  </head>");
    pw.println("  <body>");
    pw.println("  <title>JWSDL TCK Tests</title>");
    pw.println("    <div align=center>");
    pw.println("      <table border=1>");
    pw.println("        <caption " +
               "style=\"font-size: large; font-weight: bold\">" +
               "JWSDL TCK Tests</caption>");
    pw.println("        <tr>");
    pw.println("          <th>Test Class</th>");
    pw.println("          <th>Performs Tests</th>");
    pw.println("        </tr>");

    for (int i = 0; i < classes.length; i++)
    {
      String qTypeName = classes[i].qualifiedTypeName();
      boolean foundMethodComments = false;

      if (qTypeName.indexOf(".tck.") != -1)
      {
        String typeName = classes[i].typeName();

        pw.println("        <tr>");
        pw.println("          <td " +
                   "class=\"javaClassName\">" +
                   typeName + "</td>");
        pw.println("          <td>");
        pw.println("            <ul>");

        MethodDoc[] methods = classes[i].methods();

        for (int j = 0; j < methods.length; j++)
        {
          String methodName = methods[j].name();
          String commentText = methods[j].commentText();

          if (methods[j].isPublic() && methodName.startsWith("test"))
          {
            foundMethodComments = true;

            if (commentText.length() > 0)
            {
              pw.println("              <li>" + commentText + "</li>");
            }
            else
            {
              missingCommentList.add(typeName + "." + methodName + "()");
            }
          }
        }

        if (!foundMethodComments)
        {
          String commentText = classes[i].commentText();

          if (commentText.length() > 0)
          {
            pw.println("              <li>" + commentText + "</li>");
          }
          else
          {
            missingCommentList.add(typeName);
          }
        }

        pw.println("            </ul>");
        pw.println("          </td>");
        pw.println("        </tr>");
      }
    }

    pw.println("      </table>");
    pw.println("      <br>");
    pw.println("    </div>");
    pw.println("    <p>Author: <a href=\"mailto:duftler@us.ibm.com\">" +
               "Matthew J. Duftler</a></p>");
    pw.println("    <div align=center>");
    pw.println("      <hr>");
    pw.println("      <br>");
    pw.println("      <a href=\"index.html\">Introduction</a>" +
               "&nbsp;&nbsp;|&nbsp;&nbsp;");
    pw.println("      <a href=\"install.html\">Installation Instructions</a>" +
               "&nbsp;&nbsp;|&nbsp;&nbsp;");
    pw.println("      <a href=\"running.html\">Running the Tests</a>" +
               "&nbsp;&nbsp;|&nbsp;&nbsp;");
    pw.println("      Test Descriptions&nbsp;&nbsp;|&nbsp;&nbsp;");
    pw.println("      <a href=\"appeals.pdf\">Appeals Process</a>" +
               "&nbsp;&nbsp;|&nbsp;&nbsp;");
    pw.println("      <a href=\"changes.html\">Change History</a>");
    pw.println("    </div>");
    pw.println("  </body>");
    pw.println("</html>");
    pw.flush();
    fw.close();

    if (missingCommentList.size() > 0)
    {
      System.out.println("Missing comments for: ");

      Iterator methodList = missingCommentList.iterator();

      while (methodList.hasNext())
      {
        System.out.println("  " + methodList.next());
      }
    }

    return true;
  }
}