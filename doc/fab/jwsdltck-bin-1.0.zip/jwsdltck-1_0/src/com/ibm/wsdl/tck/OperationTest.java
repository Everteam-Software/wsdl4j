package com.ibm.wsdl.tck;

import java.util.*;
import javax.wsdl.*;
import javax.wsdl.extensions.*;
import javax.wsdl.factory.*;
import javax.wsdl.xml.*;
import javax.xml.namespace.*;
import javax.xml.parsers.*;
import junit.framework.*;
import org.w3c.dom.*;

/**
 * This class implements a series of tests used to check
 * javax.wsdl.Operation implementations for compliance
 * with the JWSDL specification.
 *
 * @author Matthew J. Duftler (duftler@us.ibm.com)
 */
public class OperationTest extends TestCase
{
  private static final String TEST_CANDIDATE_PROPERTY_NAME =
    "javax.wsdl.factory.WSDLFactoryCandidate";
  private static final String NS_URI_WSDL =
    "http://schemas.xmlsoap.org/wsdl/";

  private Definition definition = null;
  private Operation operation = null;

  protected void setUp() throws WSDLException
  {
    // Determine name of JWSDL factory implementation to test.
    String testCandidateName =
      System.getProperty(TEST_CANDIDATE_PROPERTY_NAME);

    if (testCandidateName == null)
    {
      throw new IllegalArgumentException("System property '" +
                                         TEST_CANDIDATE_PROPERTY_NAME +
                                         "' must be specified to run " +
                                         "test suite.");
    }

    WSDLFactory factory = WSDLFactory.newInstance(testCandidateName);

    Assert.assertNotNull("WSDLFactory should not be null.", factory);

    definition = factory.newDefinition();

    Assert.assertNotNull("Definition should not be null.", definition);

    operation = definition.createOperation();

    Assert.assertNotNull("Operation should not be null.", operation);
  }

  /**
   * Test Operation.addFault(...) and Operation.getFault(...).
   */
  public void testAddGetFault()
  {
    Fault fault = definition.createFault();

    Assert.assertNotNull("Fault should not be null.", fault);

    fault.setName("abcdef");
    operation.addFault(fault);

    Fault fault2 = operation.getFault("abcdef");

    Assert.assertTrue("Operation.getFault(...) did not return " +
                      "the same Fault that was added using " +
                      "Operation.addFault(...).",
                      fault == fault2);
  }

  /**
   * Test Operation.setDocumentationElement(...) and
   * Operation.getDocumentationElement().
   */
  public void testSetGetDocumentationElement()
    throws ParserConfigurationException
  {
    DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();

    factory.setNamespaceAware(true);
    factory.setValidating(false);

    DocumentBuilder builder = factory.newDocumentBuilder();
    Document doc = builder.newDocument();
    Element el = doc.createElementNS(NS_URI_WSDL,
                                     "wsdl:documentation");

    operation.setDocumentationElement(el);

    Element el2 = operation.getDocumentationElement();

    Assert.assertTrue("Operation.getDocumentationElement() did not " +
                      "return the same Element that was set using " +
                      "Operation.setDocumentationElement(...).",
                      el == el2);
  }

  /**
   * Test Operation.setInput(...) and Operation.getInput().
   */
  public void testSetGetInput()
  {
    Input input = definition.createInput();

    Assert.assertNotNull("Input should not be null.", input);

    operation.setInput(input);

    Input input2 = operation.getInput();

    Assert.assertTrue("Operation.getInput() did not return " +
                      "the same Input that was set using " +
                      "Operation.setInput(...).",
                      input == input2);
  }

  /**
   * Test Operation.setName(...) and Operation.getName().
   */
  public void testSetGetName()
  {
    String name = "abcdef";

    operation.setName(name);

    String name2 = operation.getName();

    Assert.assertTrue("Operation.getName() did not return " +
                      "the same name that was set using " +
                      "Operation.setName(...).",
                      name.equals(name2));
  }

  /**
   * Test Operation.setOutput(...) and Operation.getOutput().
   */
  public void testSetGetOutput()
  {
    Output output = definition.createOutput();

    Assert.assertNotNull("Output should not be null.", output);

    operation.setOutput(output);

    Output output2 = operation.getOutput();

    Assert.assertTrue("Operation.getOutput() did not return " +
                      "the same Output that was set using " +
                      "Operation.setOutput(...).",
                      output == output2);
  }

  /**
   * Test Operation.setParameterOrdering(...) and
   * Operation.getParameterOrdering().
   */
  public void testSetGetParameterOrdering()
  {
    List paramOrdering =
      Arrays.asList(new String[]{"abc", "def", "ghi"});

    operation.setParameterOrdering(paramOrdering);

    List paramOrdering2 = operation.getParameterOrdering();

    Assert.assertTrue("Operation.getParameterOrdering() did not return " +
                      "the same list of parameter names that was set using " +
                      "Operation.setParameterOrdering(...).",
                      paramOrdering.equals(paramOrdering2));
  }

  /**
   * Test Operation.setStyle(...) and Operation.getStyle().
   */
  public void testSetGetStyle()
  {
    OperationType opType = OperationType.REQUEST_RESPONSE;

    operation.setStyle(opType);

    OperationType opType2 = operation.getStyle();

    Assert.assertTrue("Operation.getStyle() did not return " +
                      "the same OperationType that was set using " +
                      "Operation.setStyle(...).",
                      opType.equals(opType2));
  }

  /**
   * Test Operation.setUndefined(...) and Operation.isUndefined().
   */
  public void testIsSetUndefined()
  {
    Assert.assertTrue("The default value of the undefined property " +
                      "of a newly created Operation should be " +
                      "true.",
                      operation.isUndefined());

    operation.setUndefined(false);

    Assert.assertFalse("Operation.isUndefined() returned " +
                       "true even though Operation.setUndefined(false) " +
                       "was called.",
                       operation.isUndefined());
  } 
}